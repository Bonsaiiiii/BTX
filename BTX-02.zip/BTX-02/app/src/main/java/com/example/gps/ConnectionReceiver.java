package com.example.gps;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

public class ConnectionReceiver extends BroadcastReceiver {

    @SuppressLint("UnsafeProtectedBroadcastReceiver")
    @Override
    public void onReceive(Context context, Intent intent) {
        boolean isConnected = isConnected(context);

        Intent localIntent = new Intent("com.example.gps.CONNECTION_STATUS");
        localIntent.putExtra("isConnected", isConnected);
        LocalBroadcastManager.getInstance(context).sendBroadcast(localIntent);
    }

    public boolean isConnected(Context context) {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();
            return (networkInfo != null && networkInfo.isConnectedOrConnecting());
        } catch (NullPointerException e) {
            e.printStackTrace();
            return false;
        }
    }
}
