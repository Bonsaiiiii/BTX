package com.example.gps;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.text.TextUtils;

public class NetworkSpecifier2 {

    public static boolean isConnectedToEspNetwork(Context context, String ESP_SSID) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);

        // Check for Wi-Fi connection
        NetworkCapabilities capabilities = cm.getNetworkCapabilities(cm.getActiveNetwork());
        if (capabilities != null && capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
            // Check the connected Wi-Fi SSID
            String currentSSID = wifiManager.getConnectionInfo().getSSID();
            return !TextUtils.isEmpty(currentSSID) && currentSSID.equals("\"" + ESP_SSID + "\"");
        }
        return false;
    }
}