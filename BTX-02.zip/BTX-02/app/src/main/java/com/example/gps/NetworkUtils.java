package com.example.gps;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.text.TextUtils;

public class NetworkUtils {

    // Method to check if connected to a specific SSID
    public static boolean isConnectedToEspNetwork(Context context, String espSsid) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo != null && networkInfo.isConnectedOrConnecting() && networkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
            WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
            String currentSsid = wifiManager.getConnectionInfo().getSSID();

            // Remove quotes from SSID if needed
            if (currentSsid != null) {
                currentSsid = currentSsid.replace("\"", "");
            }

            return !TextUtils.isEmpty(currentSsid) && currentSsid.equals(espSsid);
        }

        return false;
    }
}