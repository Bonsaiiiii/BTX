package com.example.gps;


import androidx.appcompat.app.AlertDialog;

public class GlobalVariables {
    public static String locJson = "";
    public static AlertDialog alertDialog;
}