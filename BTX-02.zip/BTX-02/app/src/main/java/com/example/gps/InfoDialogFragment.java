package com.example.gps;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import pl.droidsonroids.gif.GifDrawable;
import pl.droidsonroids.gif.GifImageView;

public class InfoDialogFragment extends DialogFragment {

    private LinearLayout content1, content2, content3, content4;
    private ScrollView scrollView;
    private Button header1, header2, header3, header4;

    private void setGifSpeed(GifImageView gifImageView) {
        GifDrawable gifDrawable = (GifDrawable) gifImageView.getDrawable();
        if (gifDrawable != null) {
            gifDrawable.setSpeed((float) 1.0);
        }
    }

    public void initializeGifViews(View view) {
        int[] gifImageViewIds = {
                R.id.btx_ligado,
                R.id.modo_config,
                R.id.modo_lpwr,
                R.id.erro_radio,
                R.id.erro_spiffs,
                R.id.botao_reset,
                R.id.botao_potencia1,
                R.id.botao_potencia2,
                R.id.botao_potencia3,
                R.id.modo_serial,
                R.id.modo_serial1,
                R.id.modo_cliente_erro1,
                R.id.modo_cliente_erro2,
                R.id.modo_cliente_erro3,
                R.id.modo_cliente_erro4,
                R.id.modo_cliente_erro5,
                R.id.modo_cliente_erro6,
                R.id.modo_cliente_erro7
        };

        for (int id : gifImageViewIds) {
            GifImageView gifImageView = view.findViewById(id);
            setGifSpeed(gifImageView);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.dialog_info, container, false);
    }

    @SuppressLint("ResourceType")
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        scrollView = view.findViewById(R.id.scrollview);

        // Initialize UI components
        header1 = view.findViewById(R.id.accordionHeader1);
        header1.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.right_arrow2, 0);
        header2 = view.findViewById(R.id.accordionHeader2);
        header2.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.right_arrow2, 0);
        header3 = view.findViewById(R.id.accordionHeader3);
        header3.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.right_arrow2, 0);
        header4 = view.findViewById(R.id.accordionHeader4);
        header4.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.right_arrow2, 0);

        content1 = view.findViewById(R.id.accordionContent1);
        content2 = view.findViewById(R.id.accordionContent2);
        content3 = view.findViewById(R.id.accordionContent3);
        content4 = view.findViewById(R.id.accordionContent4);

        initializeGifViews(view);

        // Set up click listeners for headers
        header1.setOnClickListener(view1 -> {
            toggleAccordion(content1);
            // Optionally close other accordions
            closeAccordion(content2);
            closeAccordion(content3);
            closeAccordion(content4);
            pageTop();
        });

        header2.setOnClickListener(view2-> {
            toggleAccordion(content2);
            // Optionally close other accordions
            closeAccordion(content1);
            closeAccordion(content3);
            closeAccordion(content4);
            pageTop();
        });

        header3.setOnClickListener(view3 -> {
            toggleAccordion(content3);
            // Optionally close other accordions
            closeAccordion(content1);
            closeAccordion(content2);
            closeAccordion(content4);
            pageTop();
        });

        header4.setOnClickListener(view4 -> {
            toggleAccordion(content4);
            // Optionally close other accordions
            closeAccordion(content1);
            closeAccordion(content2);
            closeAccordion(content3);
            pageTop();
        });

        // Close button
        Button closeButton = view.findViewById(R.id.dialog_close_button);
        closeButton.setOnClickListener(v -> dismiss());
    }

    @Override
    public void onStart() {
        super.onStart();
        if (getDialog() != null) {
            Window window = getDialog().getWindow();
            if (window != null) {
                WindowManager.LayoutParams params = window.getAttributes();
                params.width = WindowManager.LayoutParams.MATCH_PARENT; // Adjust width as needed
                params.height = WindowManager.LayoutParams.WRAP_CONTENT; // Adjust height if needed
                window.setAttributes(params);
            }
        }
    }

    private void pageTop(){
        new Handler().post(() -> scrollView.scrollTo(0, 0));
    }

    private void toggleAccordion(LinearLayout content) {
        if (content.getVisibility() == View.GONE) {
            content.setVisibility(View.VISIBLE);
        } else {
            content.setVisibility(View.GONE);
        }
    }

    private void closeAccordion(LinearLayout content) {
        content.setVisibility(View.GONE);
        if (content1.getVisibility() == View.GONE) {
            header1.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.right_arrow, 0);
        }
        else {
            header1.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.right_arrow2, 0);
        }
        if (content2.getVisibility() == View.GONE) {
            header2.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.right_arrow, 0);
        }
        else {
            header2.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.right_arrow2, 0);
        }
        if (content3.getVisibility() == View.GONE) {
            header3.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.right_arrow, 0);
        }
        else {
            header3.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.right_arrow2, 0);
        }
        if (content4.getVisibility() == View.GONE) {
            header4.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.right_arrow, 0);
        }
        else {
            header4.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.right_arrow2, 0);
        }
    }
}