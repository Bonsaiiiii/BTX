package com.example.gps;

import android.content.Context;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.ConnectivityManager;
import android.net.NetworkRequest;
import android.net.wifi.WifiNetworkSpecifier;
import android.widget.Toast;

import androidx.annotation.NonNull;

public class NetworkSpecifier {

    String ESP_SSID = "HugenPLUS-RADIO";
    public static void requestNetworkForSpecificSSID(Context context, String ESP_SSID) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        WifiNetworkSpecifier wifiNetworkSpecifier = new WifiNetworkSpecifier.Builder()
                .setSsid(ESP_SSID)
                .build();

        NetworkRequest networkRequest = new NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .setNetworkSpecifier(wifiNetworkSpecifier)
                .build();

        connectivityManager.requestNetwork(networkRequest, new ConnectivityManager.NetworkCallback() {
            @Override
            public void onAvailable(@NonNull Network network) {
                super.onAvailable(network);
                Toast.makeText(context, "Connected to " + ESP_SSID, Toast.LENGTH_SHORT).show();
                // Handle network connection here
            }

            @Override
            public void onUnavailable() {
                super.onUnavailable();
                Toast.makeText(context, "Unable to connect to " + ESP_SSID, Toast.LENGTH_SHORT).show();
                // Handle network unavailability here
            }

            @Override
            public void onLost(@NonNull Network network) {
                super.onLost(network);
                Toast.makeText(context, "Lost connection to " + ESP_SSID, Toast.LENGTH_SHORT).show();
                // Handle loss of network connection here
            }
        });
    }
}