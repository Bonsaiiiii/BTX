package com.example.gps;

import static com.example.gps.GlobalVariables.alertDialog;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.StrictMode;
import android.provider.Settings;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.Priority;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    BroadcastReceiver broadcastReceiver;
    private AlertDialog connectionDialog;
    private static final int REQUEST_LOCATION = 1;
    public FusedLocationProviderClient fusedLocationClient;
    LocationManager locationManager;
    private final Handler handler = new Handler();

    private final BroadcastReceiver connectionStatusReceiver = new BroadcastReceiver() {
        @SuppressLint("SetTextI18n")
        @Override
        public void onReceive(Context context, Intent intent) {
            onResume();
            boolean isConnected = intent.getBooleanExtra("isConnected", false);
            TextView textView2 = findViewById(R.id.textView2);
            TextView textView3 = findViewById(R.id.textView3);
            View blankView = findViewById(R.id.blankPage);
            if (!isConnected) {
                blankView.setVisibility(View.VISIBLE);
                textView3.setText(" ");
                textView2.setText("Status: Desconectado");
                textView2.setTextColor(Color.parseColor("#d3302c"));
                connectionDialog.show();
            }
        }
    };

    private void showConnectionDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Aviso")
                .setMessage("Por favor conecte-se à rede HugenPLUS-RADIO")
                .setCancelable(false)
                .setPositiveButton("OK", (dialog, which) -> {
                    // Optional: Handle button click if needed
                });

        connectionDialog = builder.create();
        connectionDialog.show();
    }

    public String serializeLocation(double latitude, double longitude, double altitude, float precisao) {
        JSONObject loc = new JSONObject();
        try {
            loc.put("latitude", latitude);
            loc.put("longitude", longitude);
            loc.put("altitude", altitude);
            loc.put("precisao", precisao);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return loc.toString();
    }

    @SuppressLint("SetTextI18n")
    private void checkServerConnection() {
        new Thread(() -> {
            try {
                URL url = new URL("http://192.168.0.1/apprequest");
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setDoOutput(true);

                String requestBody = "{}";
                try (OutputStream os = connection.getOutputStream()) {
                    os.write(requestBody.getBytes());
                    os.flush();
                }

                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    runOnUiThread(() -> {
                        View blankView = findViewById(R.id.blankPage);
                        handler.postDelayed(() -> blankView.setVisibility(View.INVISIBLE), 200);
                        TextView textView3 = findViewById(R.id.textView3);
                        textView3.setText("MAC: " + response);
                        TextView textView2 = findViewById(R.id.textView2);
                        textView2.setText("Status: Conectado");
                        textView2.setTextColor(Color.parseColor("#1fe04c"));
                        connectionDialog.dismiss();
                    });
                }
            } catch (Exception ignored) {
            }
        }).start();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void WebView () {
        WebView myWeb = findViewById(R.id.myWeb);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        myWeb.setWebViewClient(new WebViewClient() {
            @SuppressLint("MissingPermission")
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (Objects.requireNonNull(request.getUrl().getPath()).endsWith("/requestL")) {
                    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        // Request fine location permission if not granted
                        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
                            InputStream inputStream = new ByteArrayInputStream((GlobalVariables.locJson).getBytes());
                            return new WebResourceResponse("application/json", "UTF-8", inputStream);
                        }
                    }
                    fusedLocationClient.getLastLocation()
                            .addOnSuccessListener(MainActivity.this, location -> {
                                LocationCallback locationCallback = new LocationCallback() {
                                    @Override
                                    public void onLocationResult(@NonNull LocationResult locationResult) {
                                        super.onLocationResult(locationResult);
                                    }
                                };
                                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                                    return;
                                }
                                LocationRequest.Builder locationRequest = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000);
                                locationRequest.build();
                                fusedLocationClient.requestLocationUpdates(locationRequest.build(), locationCallback, Looper.getMainLooper());
                                locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                                // Got last known location. In some rare cases you might get null.
                                if (location != null) {
                                    double latitude = location.getLatitude();
                                    double longitude = location.getLongitude();
                                    double altitude = location.getAltitude();
                                    float precisao = location.getAccuracy();
                                    // Serialize location data
                                    GlobalVariables.locJson = serializeLocation(latitude, longitude, altitude, precisao);
                                } else {
                                    if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                        builder.setMessage("Habilitar GPS?")
                                                .setCancelable(false)
                                                .setPositiveButton("Sim", (dialog, which) -> {
                                                    startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                                                    dialog.dismiss();
                                                    locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
                                                    dialog.dismiss(); // Dismiss the dialog after starting the activity
                                                })
                                                .setNegativeButton("Não", (dialog, which) -> {
                                                    dialog.cancel(); // Cancel (dismiss) the dialog if "Não" (No) is pressed
                                                });
                                        alertDialog = builder.create();
                                        alertDialog.show();
                                        if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                                            alertDialog.cancel();
                                        }
                                    } else {
                                        if (ActivityCompat.checkSelfPermission(
                                                MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                                                MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                                            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
                                        } else {
                                            Toast.makeText(MainActivity.this, "Unable to find location.", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                }
                            });
                    InputStream inputStream = new ByteArrayInputStream((GlobalVariables.locJson).getBytes());
                    return new WebResourceResponse("application/json", "UTF-8", inputStream);
                }
                if (Objects.requireNonNull(request.getUrl().getPath()).endsWith("/bootstrap.min.css")) {
                    AssetManager assetManager = getAssets();
                    try {
                        InputStream inputStream1 = assetManager.open("bootstrap.min.css");
                        return new WebResourceResponse("text/css", "UTF-8", inputStream1);
                    } catch (IOException e) {
                        e.printStackTrace();
                        return null;
                    }
                }
                if (Objects.requireNonNull(request.getUrl().getPath()).endsWith("/bootstrap.min.js")) {
                    AssetManager assetManager1 = getAssets();
                    try {
                        InputStream inputStream1 = assetManager1.open("bootstrap.min.js");
                        return new WebResourceResponse("text/javascript", "UTF-8", inputStream1);
                    } catch (IOException e) {
                        e.printStackTrace();
                        return null;
                    }
                }
                if (Objects.requireNonNull(request.getUrl().getPath()).endsWith("/jquery-ui.css")) {
                    AssetManager assetManager = getAssets();
                    try {
                        InputStream inputStream1 = assetManager.open("jquery-ui.css");
                        return new WebResourceResponse("text/css", "UTF-8", inputStream1);
                    } catch (IOException e) {
                        e.printStackTrace();
                        return null;
                    }
                }
                if (Objects.requireNonNull(request.getUrl().getPath()).endsWith("/jquery-ui.js")) {
                    AssetManager assetManager1 = getAssets();
                    try {
                        InputStream inputStream1 = assetManager1.open("jquery-ui.js");
                        return new WebResourceResponse("text/javascript", "UTF-8", inputStream1);
                    } catch (IOException e) {
                        e.printStackTrace();
                        return null;
                    }
                }
                if (Objects.requireNonNull(request.getUrl().getPath()).endsWith("/jquery.min.js")) {
                    AssetManager assetManager2 = getAssets();
                    try {
                        InputStream inputStream2 = assetManager2.open("jquery.min.js");
                        return new WebResourceResponse("text/javascript", "UTF-8", inputStream2);
                    } catch (IOException e) {
                        e.printStackTrace();
                        return null;
                    }
                }
                if (Objects.requireNonNull(request.getUrl().getPath()).endsWith("/index.html")) {
                    AssetManager assetManager = getAssets();
                    try {
                        InputStream inputStream1 = assetManager.open("index.html");
                        return new WebResourceResponse("text/javascript", "UTF-8", inputStream1);
                    } catch (IOException e) {
                        e.printStackTrace();
                        return null;
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }
        });

        WebSettings webSettings = myWeb.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        myWeb.getSettings().setBuiltInZoomControls(true);
        myWeb.getSettings().setDisplayZoomControls(false);
        myWeb.getSettings().setUseWideViewPort(true);
        myWeb.getSettings().setLoadWithOverviewMode(true);
        myWeb.setWebChromeClient(new WebChromeClient());
        myWeb.loadUrl("http://192.168.0.1/");
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onResume() {
        runOnUiThread(() -> {
            View blankView = findViewById(R.id.blankPage);
            blankView.setVisibility(View.VISIBLE);
            TextView textView3 = findViewById(R.id.textView3);
            textView3.setText(" ");
            TextView textView2 = findViewById(R.id.textView2);
            textView2.setText("Status: Desconectado");
            connectionDialog.show();
            textView2.setTextColor(Color.parseColor("#d3302c"));
        });
        super.onResume();
        checkServerConnection();
        //startActivity(new Intent(Settings.ACTION_DATA_ROAMING_SETTINGS));
        WebView();
    }

    @SuppressLint({"MissingInflatedId", "SetTextI18n", "SetJavaScriptEnabled"})
    @Override
    public void onCreate(Bundle savedInstanceState) {

        LocalBroadcastManager.getInstance(this).registerReceiver(connectionStatusReceiver,
                new IntentFilter("com.example.gps.CONNECTION_STATUS"));
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        broadcastReceiver = new ConnectionReceiver();
        registoreNetworkBroadcast();

        showConnectionDialog();
        WebView();

        Button showLocationButton = findViewById(R.id.showLocationButton);

        WebView myWeb = findViewById(R.id.myWeb);

        showLocationButton.setOnClickListener(v -> {
            showLocationButton.setEnabled(false);
            checkServerConnection();
            myWeb.getSettings().setBuiltInZoomControls(true);
            myWeb.getSettings().setDisplayZoomControls(false);
            myWeb.getSettings().setUseWideViewPort(true);
            myWeb.getSettings().setLoadWithOverviewMode(true);
            myWeb.reload();
            handler.postDelayed(() -> showLocationButton.setEnabled(true), 1000);
            handler.postDelayed(this::onResume, 200);
        });
    }

    protected void registoreNetworkBroadcast(){
        registerReceiver(broadcastReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
    }

    protected void unregistorNetwork() {
        try {
            unregisterReceiver(broadcastReceiver);
        }catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregistorNetwork();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(connectionStatusReceiver);
    }
}