package com.mycompany.bdr01copy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
