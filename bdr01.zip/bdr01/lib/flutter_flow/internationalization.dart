import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['en', 'pt', 'es'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? enText = '',
    String? ptText = '',
    String? esText = '',
  }) =>
      [enText, ptText, esText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) {
    final language = locale.toString();
    return FFLocalizations.languages().contains(
      language.endsWith('_')
          ? language.substring(0, language.length - 1)
          : language,
    );
  }

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // HomePage
  {
    'gyudvsq4': {
      'en': 'BDR_01',
      'es': 'BDR_01',
      'pt': 'BDR_01',
    },
    'qy4eih1c': {
      'en': 'Current Configuration',
      'es': 'Configuración actual',
      'pt': 'Configuração Atual',
    },
    't9r91jbx': {
      'en': 'Profile: ',
      'es': 'Perfil: ',
      'pt': 'Perfil: ',
    },
    '746iqvv8': {
      'en': 'Mode: ',
      'es': 'Modo: ',
      'pt': 'Modo: ',
    },
    'rsiwhxdj': {
      'en': 'Output Voltage:\n(Powers the GPS)',
      'es': 'Tensão de Saída: \n(Alimenta o GPS)',
      'pt': 'Tensão de Saída: \n(Alimenta o GPS)',
    },
    't6usvmcf': {
      'en': 'Baudrate:',
      'es': 'Velocidad en baudios:',
      'pt': 'Taxa de transmissão:',
    },
    '8vcf4vp9': {
      'en': 'Parity:',
      'es': 'Paridad:',
      'pt': 'Paridade:',
    },
    'ab9osa3k': {
      'en': 'Stop Bits:',
      'es': 'Bits de Parada:',
      'pt': 'Bits de Parada:',
    },
    '0sccvmqd': {
      'en': 'Flux Control:',
      'es': 'Control de flujo:',
      'pt': 'Controle de Fluxo:',
    },
    'ivn7h0me': {
      'en': 'Databits:',
      'es': 'Bits de datos:',
      'pt': 'Bits de dados:',
    },
    'xc8oaaa4': {
      'en': 'WiFi Network:',
      'es': 'Red WiFi:',
      'pt': 'Rede WiFi:',
    },
    '1gdvct3s': {
      'en': 'WiFi Password:',
      'es': 'Señal WiFi:',
      'pt': 'Senha WiFi:',
    },
    '8fq4ypxw': {
      'en': 'Host IP:',
      'es': 'Dirección IP del host:',
      'pt': 'IP do host:',
    },
    '5atqgwqb': {
      'en': 'Port:',
      'es': 'Puerta:',
      'pt': 'Porta:',
    },
    'kt0mbmow': {
      'en': 'MountPoint:',
      'es': 'MountPoint:',
      'pt': 'MountPoint:',
    },
    'l3ck99bf': {
      'en': 'User:',
      'es': 'Usuario:',
      'pt': 'Usuário:',
    },
    'g7sduusi': {
      'en': 'Password:',
      'es': 'Señal:',
      'pt': 'Senha:',
    },
    'y4af5l1z': {
      'en': 'Mode: ',
      'es': 'Modo:',
      'pt': 'Modo:',
    },
    'uaa86uga': {
      'en': 'Output Voltage:\n(Powers the GPS)',
      'es': 'Tensão de Saída: \n(Alimenta o GPS)',
      'pt': 'Tensão de Saída: \n(Alimenta o GPS)',
    },
    'injcjd21': {
      'en': 'Baudrate:',
      'es': 'Velocidad en baudios:',
      'pt': 'Taxa de transmissão:',
    },
    'wr95v5q1': {
      'en': 'Parity:',
      'es': 'Paridad:',
      'pt': 'Paridade:',
    },
    'dsf08e65': {
      'en': 'Stop Bits:',
      'es': 'Bits de Parada:',
      'pt': 'Bits de Parada:',
    },
    'no8zmqh8': {
      'en': 'Flux Control:',
      'es': 'Control de flujo:',
      'pt': 'Controle de Fluxo:',
    },
    'xbf5vrd3': {
      'en': 'Databits:',
      'es': 'Bits de datos:',
      'pt': 'Bits de dados:',
    },
    '62f8j7ue': {
      'en': 'WiFi Network:',
      'es': 'Red WiFi:',
      'pt': 'Rede WiFi:',
    },
    'kv8pgei5': {
      'en': 'WiFi Passwordi:',
      'es': 'Señal WiFi:',
      'pt': 'Senha WiFi:',
    },
    'kxjghlfc': {
      'en': 'Host IP:',
      'es': 'Dirección IP del host:',
      'pt': 'IP do host:',
    },
    'j98nsprq': {
      'en': 'Port:',
      'es': 'Puerta:',
      'pt': 'Porta:',
    },
    'gk9ldt5p': {
      'en': 'MountPoint:',
      'es': 'MountPoint:',
      'pt': 'MountPoint:',
    },
    'h2bk3uys': {
      'en': 'User:',
      'es': 'Usuario:',
      'pt': 'Usuário:',
    },
    'c1k98w68': {
      'en': 'Password:',
      'es': 'Señal:',
      'pt': 'Senha:',
    },
    '3xe1odfu': {
      'en': 'Send location to the NTRIP server?',
      'es': '¿Mandar localización para el servidor NTRIP?',
      'pt': 'Mandar localização para o servidor NTRIP?',
    },
    '4737wbpn': {
      'en': 'Latitude:',
      'es': 'Latitud:',
      'pt': 'Latitude:',
    },
    'vragu3c2': {
      'en': 'Longitude:',
      'es': 'Longitud:',
      'pt': 'Longitude:',
    },
    'jx6e0mdq': {
      'en': 'Height:',
      'es': 'Altitud:',
      'pt': 'Altitude:',
    },
    'h9zq6lpp': {
      'en': 'Precision:',
      'es': 'Precisión:',
      'pt': 'Precisão:',
    },
    '7pjwj3vp': {
      'en': 'Time in UTC:',
      'es': 'Tiempo UTC:',
      'pt': 'Tempo UTC:',
    },
    'lp97l5ft': {
      'en': 'Mode: ',
      'es': 'Modo:',
      'pt': 'Modo:',
    },
    'wfft2nmy': {
      'en': 'Tensão de Saída:\n(Alimenta o GPS)',
      'es': 'Tensão de Saída: \n(Alimenta o GPS)',
      'pt': 'Tensão de Saída: \n(Alimenta o GPS)',
    },
    'esf5ekyk': {
      'en': 'Baudrate:',
      'es': 'Velocidad en baudios:',
      'pt': 'Taxa de transmissão:',
    },
    'pv4fotuj': {
      'en': 'Parity:',
      'es': 'Paridad:',
      'pt': 'Paridade:',
    },
    'o99ctt55': {
      'en': 'Stop Bits:',
      'es': 'Bits de Parada:',
      'pt': 'Bits de Parada:',
    },
    'ystsx0gk': {
      'en': 'Flux Control:',
      'es': 'Control de flujo:',
      'pt': 'Controle de Fluxo:',
    },
    '1qkek1nr': {
      'en': 'Databits:',
      'es': 'Bits de datos:',
      'pt': 'Bits de dados:',
    },
    'yt6c42e9': {
      'en': ' WiFi Network:',
      'es': 'Red WiFi:',
      'pt': 'Rede WiFi:',
    },
    'xqp7up3a': {
      'en': 'WiFi Password:',
      'es': 'Señal WiFi:',
      'pt': 'Senha WiFi:',
    },
    'iubr1d1n': {
      'en': 'Host IP:',
      'es': 'Dirección IP del host:',
      'pt': 'IP do host:',
    },
    'l43a85xw': {
      'en': 'Port:',
      'es': 'Puerta:',
      'pt': 'Porta:',
    },
    'k8apu8ll': {
      'en': 'MountPoint:',
      'es': 'MountPoint:',
      'pt': 'MountPoint:',
    },
    'rfzt6h00': {
      'en': 'NTRIP revision 1.0 (altentification password/ user',
      'es': 'NTRIP revisión 1.0 (autentificação senha/ usuário',
      'pt': 'NTRIP revisão 1.0 (autentificação senha/ usuário',
    },
    'irkxincp': {
      'en': 'User:',
      'es': 'Usuario:',
      'pt': 'Usuário:',
    },
    'w9609qk2': {
      'en': 'Password:',
      'es': 'Señal:',
      'pt': 'Senha:',
    },
    '5w7ne4ct': {
      'en': 'Quick Reconfiguration: ',
      'es': 'Reconfiguración rápida:',
      'pt': 'Reconfiguração rápida:',
    },
    'mpvjxiua': {
      'en': 'Padrao',
      'es': 'Padrão',
      'pt': 'Padrão',
    },
    'j42wc1fc': {
      'en': 'P1',
      'es': 'P1',
      'pt': 'P1',
    },
    'undjycrv': {
      'en': 'P2',
      'es': 'P2',
      'pt': 'P2',
    },
    '3ja4cq1x': {
      'en': 'P3',
      'es': 'P3',
      'pt': 'P3',
    },
    'mrvehnvq': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    't0293dja': {
      'en': 'Manage Profiles',
      'es': 'Gerenciar Perfis',
      'pt': 'Gerenciar Perfis',
    },
    'hwy94m5x': {
      'en': 'Program',
      'es': 'Programar',
      'pt': 'Programar',
    },
    'i3v2o4l1': {
      'en': 'Home',
      'es': 'Home',
      'pt': 'Home',
    },
  },
  // ModoLocal
  {
    'zhfq8r8e': {
      'en': 'BDR_01',
      'es': 'BDR_01',
      'pt': 'BDR_01',
    },
    '56u1j7vm': {
      'en': 'Configurações Local',
      'es': 'Configuraciones locales',
      'pt': 'Configurações locais',
    },
    'ghzwlhfx': {
      'en': 'Configurações de Porta Superior (Serial)',
      'es': 'Configuraciones de Porta Superior (Serie)',
      'pt': 'Configurações da Porta Superior (Serial)',
    },
    'ge56ub0y': {
      'en': 'Tensão de Saída:\n(Alimenta o GPS)',
      'es': 'Tensão de Saída: (Alimenta o GPS)',
      'pt': 'Tensão de Saída: (Alimentação ou GPS)',
    },
    'ow8dz2ng': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    'dvjr7g41': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    's36i2o51': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    'l1atx7hd': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    '8fermlwd': {
      'en': 'Baudrate:',
      'es': 'Velocidad en baudios:',
      'pt': 'Taxa de transmissão:',
    },
    'yes99hlr': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    'f2ooad3c': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    'imqvxlny': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    '66hg1u8k': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'o458oz2r': {
      'en': 'Paridade:',
      'es': 'Paridad:',
      'pt': 'Paridade:',
    },
    'ev729vvm': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    '1ahzq1bg': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    'vkfloom9': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    'p6l71py4': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'mp7orn38': {
      'en': 'Bits de Parada:',
      'es': 'Bits de Parada:',
      'pt': 'Bits de Parada:',
    },
    'vt31uzjp': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    'd1y8oh31': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    'prik8zvz': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    'dgipi3cn': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'uzrgamws': {
      'en': 'Controle de Fluxo:',
      'es': 'Control de flujo:',
      'pt': 'Controle de Fluxo:',
    },
    'tfeaivyi': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    'sixt8uog': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    'pliohdh7': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    'a3mydhso': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'tdvi5d92': {
      'en': 'Databits:',
      'es': 'Bits de datos:',
      'pt': 'Bits de dados:',
    },
    'b0vjn13c': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    '786y2w36': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    'kzamzm82': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    'jw8e6vo4': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'tq5v1gex': {
      'en': 'Configurações WiFi',
      'es': 'Configuraciones WiFi',
      'pt': 'Configurações WiFi',
    },
    'gtc8yg6q': {
      'en': 'Configurações para gerar uma rede WiFi no modo AP.',
      'es': 'Configuraciones para generar una red WiFi en modo AP.',
      'pt': 'Configurações para gerar uma rede WiFi no modo AP.',
    },
    '05d9x506': {
      'en': 'Rede WiFi:',
      'es': 'Red WiFi:',
      'pt': 'Rede WiFi:',
    },
    'pwj733ah': {
      'en': 'Senha WiFi:',
      'es': 'Señal WiFi:',
      'pt': 'Senha WiFi:',
    },
    'f44ki32i': {
      'en': 'Configurações NTRIP',
      'es': 'Configuraciones NTRIP',
      'pt': 'Configurações NTRIP',
    },
    '59ayvmnc': {
      'en':
          'Configurações responsáveis por configurar e gerar um caster local de NTRIP.',
      'es':
          'Las configuraciones son responsables de configurar y administrar un lanzador local de NTRIP.',
      'pt':
          'Configurações responsáveis por configurar e gerar um caster local de NTRIP.',
    },
    'g0wtt3kq': {
      'en': 'Host IP:',
      'es': 'Dirección IP del host:',
      'pt': 'IP do host:',
    },
    '9gqjruzj': {
      'en': 'Porta:',
      'es': 'Puerta:',
      'pt': 'Porta:',
    },
    'wyzeokkn': {
      'en': 'MountPoint:',
      'es': 'Punto de montaje:',
      'pt': 'Ponto de montagem:',
    },
    '8efjps11': {
      'en': 'Usuário:',
      'es': 'Usuario:',
      'pt': 'Usuário:',
    },
    'nodmrl4i': {
      'en': 'Senha:',
      'es': 'Señal:',
      'pt': 'Senha:',
    },
    't6mpuag9': {
      'en': 'Programar Configurações',
      'es': 'Configuraciones del programador',
      'pt': 'Configurações do programa',
    },
    '5jj9f1ec': {
      'en': 'Sair do Modo de Configuração',
      'es': 'Sair do Modo de Configuración',
      'pt': 'Sair do Modo de Configuração',
    },
    'fybhi2ch': {
      'en': 'Home',
      'es': 'Hogar',
      'pt': 'Lar',
    },
  },
  // ModoCliente
  {
    'rx1despt': {
      'en': 'BDR_01',
      'es': 'BDR_01',
      'pt': 'BDR_01',
    },
    'ng581mre': {
      'en': 'Configurações Cliente',
      'es': 'Configuraciones del cliente',
      'pt': 'Configurações do cliente',
    },
    'yst8zt1p': {
      'en': 'Configurações de Porta Superior (Serial)',
      'es': 'Configuraciones de Porta Superior (Serie)',
      'pt': 'Configurações da Porta Superior (Serial)',
    },
    'r35rahy7': {
      'en': 'Tensão de Saída:\n(Alimenta o GPS)',
      'es': 'Tensão de Saída: (Alimenta o GPS)',
      'pt': 'Tensão de Saída: (Alimentação ou GPS)',
    },
    'tufxjx8m': {
      'en': '5V',
      'es': '5 V',
      'pt': '5V',
    },
    'lyrzbjsj': {
      'en': '9V',
      'es': '9 V',
      'pt': '9V',
    },
    'nd4s8j4v': {
      'en': '12V',
      'es': '12 V',
      'pt': '12V',
    },
    'eg3xtvlb': {
      'en': '15V',
      'es': '15 V',
      'pt': '15V',
    },
    'up9j4nah': {
      'en': '20V',
      'es': '20 V',
      'pt': '20V',
    },
    'qqrbjnt4': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'khrh3wyg': {
      'en': 'Baudrate:',
      'es': 'Velocidad en baudios:',
      'pt': 'Taxa de transmissão:',
    },
    '173d3hmo': {
      'en': '9600',
      'es': '9600',
      'pt': '9600',
    },
    '7ymu6mrx': {
      'en': '19200',
      'es': '19200',
      'pt': '19200',
    },
    'j6u66ydt': {
      'en': '38400',
      'es': '38400',
      'pt': '38400',
    },
    'iyrmgmps': {
      'en': '57600',
      'es': '57600',
      'pt': '57600',
    },
    '5sh2gytm': {
      'en': '115200',
      'es': '115200',
      'pt': '115200',
    },
    'xzjq2w4c': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    '1c24erxr': {
      'en': 'Paridade:',
      'es': 'Paridad:',
      'pt': 'Paridade:',
    },
    'h29czbm2': {
      'en': 'Nenhum',
      'es': 'No me gusta',
      'pt': 'Nenhum',
    },
    'hmm0n5v9': {
      'en': 'Even',
      'es': 'Incluso',
      'pt': 'Até',
    },
    '5cgwoc4t': {
      'en': 'Odd',
      'es': 'Extraño',
      'pt': 'Chance',
    },
    'gginhecb': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    '0f73do1u': {
      'en': 'Bits de Parada:',
      'es': 'Bits de Parada:',
      'pt': 'Bits de Parada:',
    },
    '35wd620x': {
      'en': '1',
      'es': '1',
      'pt': '1',
    },
    '6azwtufw': {
      'en': '1.5',
      'es': '1.5',
      'pt': '1.5',
    },
    'gapb9d11': {
      'en': '2',
      'es': '2',
      'pt': '2',
    },
    'l9j5f8bt': {
      'en': '3',
      'es': '3',
      'pt': '3',
    },
    '8a6tlldf': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'gerzptkb': {
      'en': 'Controle de Fluxo:',
      'es': 'Control de flujo:',
      'pt': 'Controle de Fluxo:',
    },
    '6b5439h0': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    '3qup6c3s': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    'do68j7gq': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    'gii76n5v': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'a92vrl1l': {
      'en': 'Databits:',
      'es': 'Bits de datos:',
      'pt': 'Bits de dados:',
    },
    '6hme3izu': {
      'en': '5',
      'es': '5',
      'pt': '5',
    },
    'hpl8eyv6': {
      'en': '6',
      'es': '6',
      'pt': '6',
    },
    '6po2crdb': {
      'en': '7',
      'es': '7',
      'pt': '7',
    },
    '57cidzdq': {
      'en': '8',
      'es': '8',
      'pt': '8',
    },
    '6m6af8gc': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'z5zzl041': {
      'en': 'Configurações WiFi',
      'es': 'Configuraciones WiFi',
      'pt': 'Configurações WiFi',
    },
    '7kk34y9t': {
      'en': 'Selecione a rede na qual você deseja conectar-se.',
      'es': 'Seleccione una red en la que desee conectarse.',
      'pt': 'Selecione a rede onde você deseja se conectar.',
    },
    '4py8j4sc': {
      'en': 'Rede WiFi:',
      'es': 'Red WiFi:',
      'pt': 'Rede WiFi:',
    },
    'xo3w28ic': {
      'en': 'Senha WiFi:',
      'es': 'Señal WiFi:',
      'pt': 'Senha WiFi:',
    },
    'xzheh3hh': {
      'en': 'Configurações NTRIP',
      'es': 'Configuraciones NTRIP',
      'pt': 'Configurações NTRIP',
    },
    'rbm9vu98': {
      'en':
          'Digite as credenciais do servidor NTRIP que você deseja se conectar.',
      'es': 'Digite as credenciais do server NTRIP que usted desea se conecta.',
      'pt': 'Digite as credenciais do servidor NTRIP que você deseja conectar.',
    },
    'gpwolq8b': {
      'en': 'Host IP:',
      'es': 'Dirección IP del host:',
      'pt': 'IP do host:',
    },
    'jxfhzhlj': {
      'en': 'Porta:',
      'es': 'Puerta:',
      'pt': 'Porta:',
    },
    '0pqnicik': {
      'en': 'MountPoint:',
      'es': 'Punto de montaje:',
      'pt': 'Ponto de montagem:',
    },
    '1biv4c27': {
      'en': 'Usuário:',
      'es': 'Usuario:',
      'pt': 'Usuário:',
    },
    'm3jy2iwa': {
      'en': 'Senha:',
      'es': 'Señal:',
      'pt': 'Senha:',
    },
    'o22oasxf': {
      'en': 'Localização',
      'es': 'Localización',
      'pt': 'Localização',
    },
    '35eu3fxm': {
      'en':
          'Você pode selecionar enviar e buscar a localização , caso a checkbox abaixo não estiver marcada a localização será irrelevada.',
      'es':
          'Puedes seleccionar enviar y buscar una localización, en caso de que la casilla de verificación no esté marcada, la localización será irrelevada.',
      'pt':
          'Você pode selecionar enviar e buscar a localização, caso a caixa de seleção abaixo não esteja marcada a localização será irrelevada.',
    },
    '9icocak3': {
      'en': 'Mandar localização para o servidor NTRIP?',
      'es': '¿Mandar localización para el servidor NTRIP?',
      'pt': 'Mandar localização para o servidor NTRIP?',
    },
    'bs66ysh5': {
      'en': 'S',
      'es': 'S',
      'pt': 'S',
    },
    'xmkl7jfd': {
      'en': 'N',
      'es': 'norte',
      'pt': 'Não',
    },
    'ciq92ntr': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'g3ts9iid': {
      'en': 'Latitude:',
      'es': 'Latitud:',
      'pt': 'Latitude:',
    },
    'j03usrbs': {
      'en': 'Longitude:',
      'es': 'Longitud:',
      'pt': 'Longitude:',
    },
    'gw8dnyvm': {
      'en': 'Altitude:',
      'es': 'Altitud:',
      'pt': 'Altitude:',
    },
    'n3a27wzv': {
      'en': 'Precisão:',
      'es': 'Precisión:',
      'pt': 'Precisão:',
    },
    'bz6pq1ba': {
      'en': 'Tempo UTC:',
      'es': 'Tiempo UTC:',
      'pt': 'Tempo UTC:',
    },
    'z1akx9du': {
      'en': 'Buscar Localização',
      'es': 'Buscar Localización',
      'pt': 'Pesquisar Localização',
    },
    'tbom07xj': {
      'en': 'Programar Configurações',
      'es': 'Configuraciones del programador',
      'pt': 'Configurações do programa',
    },
    'fetygow8': {
      'en': 'Sair do Modo de Configuração',
      'es': 'Sair do Modo de Configuración',
      'pt': 'Sair do Modo de Configuração',
    },
    'p5ov8ai1': {
      'en': 'Home',
      'es': 'Hogar',
      'pt': 'Lar',
    },
  },
  // ModoSource
  {
    'y37x905r': {
      'en': 'BDR_01',
      'es': 'BDR_01',
      'pt': 'BDR_01',
    },
    'mneclajt': {
      'en': 'Configurações Source',
      'es': 'Configuraciones Fuente',
      'pt': 'Configurações Fonte',
    },
    '5ptpu0e6': {
      'en': 'Configurações de Porta Superior (Serial)',
      'es': 'Configuraciones de Porta Superior (Serie)',
      'pt': 'Configurações da Porta Superior (Serial)',
    },
    'kyvd3r7u': {
      'en': 'Tensão de Saída:\n(Alimenta o GPS)',
      'es': 'Tensão de Saída: (Alimenta o GPS)',
      'pt': 'Tensão de Saída: (Alimentação ou GPS)',
    },
    'i85xutqg': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    '3v7xsn3f': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    'lgoip8zy': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    'uccws3kr': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'gxvby4zf': {
      'en': 'Baudrate:',
      'es': 'Velocidad en baudios:',
      'pt': 'Taxa de transmissão:',
    },
    'ab3o2tcp': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    '28y3smlm': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    'yl1qelgs': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    'ao887rej': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'bv3noslc': {
      'en': 'Paridade:',
      'es': 'Paridad:',
      'pt': 'Paridade:',
    },
    'ak1dw6x8': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    '2pgwen0k': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    'iv9v4nw6': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    '0iaph3nf': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'dampsmax': {
      'en': 'Bits de Parada:',
      'es': 'Bits de Parada:',
      'pt': 'Bits de Parada:',
    },
    'm0uiuwa7': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    'kjtftbp1': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    'beodvcvd': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    'nzpjzyfk': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'stfz45qj': {
      'en': 'Controle de Fluxo:',
      'es': 'Control de flujo:',
      'pt': 'Controle de Fluxo:',
    },
    'rjeffjiv': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    '6qykdonp': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    '98zxtvfs': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    't3jutlas': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'ibvbagk2': {
      'en': 'Databits:',
      'es': 'Bits de datos:',
      'pt': 'Bits de dados:',
    },
    'vt66jpyt': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    '3xg15beu': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    '4zs837ww': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    'rex8m3dz': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'djkf9au0': {
      'en': 'Configurações WiFi',
      'es': 'Configuraciones WiFi',
      'pt': 'Configurações WiFi',
    },
    'wvrfep3o': {
      'en': 'Selecione a rede na qual você deseja conectar-se.',
      'es': 'Seleccione una red en la que desee conectarse.',
      'pt': 'Selecione a rede onde você deseja se conectar.',
    },
    'ukuqfr0t': {
      'en': 'Rede WiFi:',
      'es': 'Red WiFi:',
      'pt': 'Rede WiFi:',
    },
    'r0qb4o11': {
      'en': 'Senha WiFi:',
      'es': 'Señal WiFi:',
      'pt': 'Senha WiFi:',
    },
    '8dh4r4zi': {
      'en': 'Configurações NTRIP',
      'es': 'Configuraciones NTRIP',
      'pt': 'Configurações NTRIP',
    },
    'awu8wvrt': {
      'en':
          'Digite as credenciais do servidor NTRIP que você deseja se conectar.',
      'es': 'Digite as credenciais do server NTRIP que usted desea se conecta.',
      'pt': 'Digite as credenciais do servidor NTRIP que você deseja conectar.',
    },
    'u0aht63x': {
      'en': 'Host IP:',
      'es': 'Dirección IP del host:',
      'pt': 'IP do host:',
    },
    'zjkqgxsp': {
      'en': 'Porta:',
      'es': 'Puerta:',
      'pt': 'Porta:',
    },
    'nc6m1vml': {
      'en': 'MountPoint:',
      'es': 'Punto de montaje:',
      'pt': 'Ponto de montagem:',
    },
    'isu8gpkf': {
      'en': 'NTRIP revisão 1.0 (autentificação senha/ usuário',
      'es': 'NTRIP revisión 1.0 (autentificação senha/ usuário',
      'pt': 'NTRIP revisão 1.0 (autentificação senha/ usuário',
    },
    'l7f5z26u': {
      'en': 'S',
      'es': 'S',
      'pt': 'S',
    },
    '2uoyu780': {
      'en': 'N',
      'es': 'norte',
      'pt': 'Não',
    },
    'd9ihn9ss': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'h4klu7k1': {
      'en': 'Usuário:',
      'es': 'Usuario:',
      'pt': 'Usuário:',
    },
    '3ol0lubh': {
      'en': 'Senha:',
      'es': 'Señal:',
      'pt': 'Senha:',
    },
    'xep08wt4': {
      'en': 'Programar Configurações',
      'es': 'Configuraciones del programador',
      'pt': 'Configurações do programa',
    },
    'hd6vfv93': {
      'en': 'Sair do Modo de Configuração',
      'es': 'Sair do Modo de Configuración',
      'pt': 'Sair do Modo de Configuração',
    },
    '89k593qn': {
      'en': 'Home',
      'es': 'Hogar',
      'pt': 'Lar',
    },
  },
  // Info
  {
    '77b5vq4z': {
      'en': 'BDR_01',
      'es': 'BDR_01',
      'pt': 'BDR_01',
    },
    'acuvx6xw': {
      'en': 'Information',
      'es': 'Información',
      'pt': 'Informações',
    },
    'ul2gxqgq': {
      'en': 'Model\nFirmware Version\nMac\nAvailable Tension Outputs',
      'es':
          'Modelo Versión de Firmware \nMac \nTensiones de alimentación disponibles 5 9 12 15 20',
      'pt':
          'Modelo\nVersão de Firmware\nMac \nTensões de alimentação disponíveis 5 9 12 15 20',
    },
    '0p7v3l4e': {
      'en': 'Home',
      'es': 'Home',
      'pt': 'Home',
    },
  },
  // ModeSelection
  {
    'pildhibu': {
      'en': 'BDR_01',
      'es': 'BDR_01',
      'pt': 'BDR_01',
    },
    'cqdd9lmr': {
      'en': 'Modo Local',
      'es': 'Modo local',
      'pt': 'Modo Local',
    },
    'aipj7tzd': {
      'en':
          '- In Local mode, Serial, WiFi and NTRIP port information is entered, where when configured it generates an NTRIP server and its credentials can be registered in a drone control.',
      'es':
          '- No se pueden insertar en el modo local informaciones de puerto serie, WiFi y NTRIP, cuando se haya configurado un servidor NTRIP y sus credenciales puedan ser registradas en un control de drone.',
      'pt':
          '- No modo Local são inseridas as informações de porta Serial, WiFi e NTRIP, onde quando configurado gera um servidor NTRIP e suas credenciais podem ser registradas em um controle de drone.',
    },
    'x2uxi65m': {
      'en': 'Modo Local',
      'es': 'Modo local',
      'pt': 'Modo Local',
    },
    '6696q3ck': {
      'en': 'Modo Cliente',
      'es': 'Modo Cliente',
      'pt': 'Modo Cliente',
    },
    '67r84xr6': {
      'en':
          '- In Client Mode, the BDR connects to an existing NTRIP server, choosing whether or not to use the location depending on the server and using a Serial cable it is connected from a BDR to an endpoint (computer, radio, GNSS, etc.).\n',
      'es':
          '- No Modo Cliente o BDR se conecta a un servidor NTRIP existente, escogiendo o no utilizar una localización dependiendo del servidor y a través de un cabo Serial ele está conectado de un BDR a un punto final (computadora, radio, gnss, etc.).',
      'pt':
          '- No Modo Cliente o BDR se conecta em um servidor NTRIP existente, escolhendo ou não utilizar a localização dependendo do servidor e através de um cabo Serial ele é conectado de um BDR até um endpoint (computador, rádio, gnss, etc).',
    },
    'e0utvz4y': {
      'en': 'Client Mode',
      'es': 'Modo Cliente',
      'pt': 'Modo Cliente',
    },
    '3rtq1u1c': {
      'en': 'Source Mode',
      'es': 'Modo Source',
      'pt': 'Modo Source',
    },
    'fhr7kgth': {
      'en':
          '- In Source mode, the BDR connects directly to an NTRIP server via Wi-Fi.',
      'es':
          '- No hay modo Source o BDR que se conecta directamente a un servidor NTRIP mediante Wi-Fi.',
      'pt':
          '- No modo Source o BDR se conecta diretamente em um servidor NTRIP via Wi-Fi.',
    },
    '6azrt5p4': {
      'en': 'Source Mode',
      'es': 'Modo Source',
      'pt': 'Modo Source',
    },
    'hc8pwps1': {
      'en': 'Help',
      'es': 'Ayuda',
      'pt': 'Ajuda',
    },
    '4s0dfqnu': {
      'en': 'Home',
      'es': 'Home',
      'pt': 'Home',
    },
  },
  // ConnectionPage
  {
    'nuveu9sq': {
      'en': 'BDR_01',
      'es': 'BDR_01',
      'pt': 'BDR_01',
    },
    'm0bhwnfw': {
      'en': 'Find  a WiFi',
      'es': 'Buscar WiFi',
      'pt': 'Buscar WiFi',
    },
    'jypoxzqk': {
      'en': 'Disable Roaming',
      'es': 'Deshabilitar el roaming',
      'pt': 'Desabilitar Roaming',
    },
    'k4m23tax': {
      'en': '\n',
      'es': '',
      'pt': '',
    },
    'wg3gee0f': {
      'en':
          'For correct operation\nof the application is necessary\nconnect to your network\nBDR and disable data\nroaming',
      'es':
          'Para el funcionamiento correcto de la aplicación es necesario conectarse a la red de su BDR y desabilitar datos móviles',
      'pt':
          'Para o funcionamento correto\ndo aplicativo é necessário\nconectar-se na rede de seu\nBDR e desabilitar dados\nmóveis',
    },
    'heuie0bc': {
      'en': 'Home',
      'es': 'Home',
      'pt': 'Home',
    },
  },
  // GerenciarPerfil
  {
    'xxs3qfhp': {
      'en': 'BDR_01',
      'es': 'BDR_01',
      'pt': 'BDR_01',
    },
    'e2hewrk2': {
      'en': 'Active Profile: ',
      'es': 'Perfil Activo:',
      'pt': 'Perfil Ativo:',
    },
    'wzm22ugf': {
      'en': 'Reconfigure Profile',
      'es': 'Reconfigurar perfil',
      'pt': 'Reconfigurar Perfil',
    },
    'rzl1ype2': {
      'en':
          'Select below which profile you want to choose as active and press \"switch profile\".',
      'es':
          'Seleccione abajo el perfil que desee seleccionar como activo y presione \"trocar perfil\".',
      'pt':
          'Selecione abaixo qual perfil deseja escolher como ativo e pressione \"trocar perfil\".',
    },
    'rmgd4bwf': {
      'en': 'Padrao',
      'es': 'Padrão',
      'pt': 'Padrão',
    },
    'jxusmq0g': {
      'en': 'P1',
      'es': 'P1',
      'pt': 'P1',
    },
    'rwbaij5k': {
      'en': 'P2',
      'es': 'P2',
      'pt': 'P2',
    },
    '7uhfwu2f': {
      'en': 'P3',
      'es': 'P3',
      'pt': 'P3',
    },
    'ir48g7u7': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'xdb62pif': {
      'en': 'Change Profile',
      'es': 'Perfil del trocar',
      'pt': 'Trocar Perfil',
    },
    'zfa6jxmb': {
      'en': 'Home',
      'es': 'Home',
      'pt': 'Home',
    },
  },
  // ModoLocalWifi
  {
    'hiudi2at': {
      'en': 'BDR_01',
      'es': 'BDR_01',
      'pt': 'BDR_01',
    },
    '2rr2uzmr': {
      'en': 'Local Configuration',
      'es': 'Configuraciones Locales',
      'pt': 'Configurações Locais',
    },
    '597frplz': {
      'en': 'WiFi Configuration',
      'es': 'Configuraciones WiFi',
      'pt': 'Configurações WiFi',
    },
    'tle0tlm1': {
      'en': 'Configurations to generate a WiFi network in AP mode.',
      'es': 'Configuraciones para generar una red WiFi en modo AP.',
      'pt': 'Configurações para gerar uma rede WiFi no modo AP.',
    },
    'nectknb9': {
      'en': 'WiFi Network:',
      'es': 'Red WiFi:',
      'pt': 'Rede WiFi:',
    },
    '32q1il3b': {
      'en': 'WiFi Password:',
      'es': 'Señal WiFi:',
      'pt': 'Senha WiFi:',
    },
    '3majz0mb': {
      'en': 'Test Configurations',
      'es': 'Probar configuraciones',
      'pt': 'Testar Configurações',
    },
    '2h6kr0xh': {
      'en': 'Next Page',
      'es': 'Próxima página',
      'pt': 'Próxima página',
    },
    '5lhtesla': {
      'en': 'Home',
      'es': 'Home',
      'pt': 'Home',
    },
  },
  // ModoLocalNtp
  {
    'bvda51wb': {
      'en': 'BDR_01',
      'es': 'BDR_01',
      'pt': 'BDR_01',
    },
    '2j1c7umt': {
      'en': 'Local Configuration',
      'es': 'Configuraciones Locales',
      'pt': 'Configurações Locais',
    },
    '7p82nhzr': {
      'en': 'NTRIP Configuration',
      'es': 'Configuraciones NTRIP',
      'pt': 'Configurações NTRIP',
    },
    'axnb6a2i': {
      'en':
          'Settings responsible for configuring and generating a local NTRIP caster.',
      'es':
          'Las configuraciones son responsables de configurar y administrar un lanzador local de NTRIP.',
      'pt':
          'Configurações responsáveis por configurar e gerar um caster local de NTRIP.',
    },
    '3qvfjoh5': {
      'en': 'Host IP:',
      'es': 'Dirección IP del host:',
      'pt': 'IP do host:',
    },
    '5u363rbv': {
      'en': 'Port:',
      'es': 'Puerta:',
      'pt': 'Porta:',
    },
    '71w2num5': {
      'en': 'MountPoint:',
      'es': 'MountPoint:',
      'pt': 'MountPoint:',
    },
    'fsgz50vl': {
      'en': 'User:',
      'es': 'Usuario:',
      'pt': 'Usuário:',
    },
    'jmxxhgkw': {
      'en': 'Password:',
      'es': 'Señal:',
      'pt': 'Senha:',
    },
    'nul6bgoy': {
      'en': 'Test Configuration',
      'es': 'Probar configuraciones',
      'pt': 'Testar Configurações',
    },
    'gnh7iv1y': {
      'en': 'Next page',
      'es': 'Próxima página',
      'pt': 'Próxima página',
    },
    'iztmz84f': {
      'en': 'Home',
      'es': 'Home',
      'pt': 'Home',
    },
  },
  // ModoLocalSaida
  {
    'pyyyuzpx': {
      'en': 'BDR_01',
      'es': 'BDR_01',
      'pt': 'BDR_01',
    },
    'xrg5grp4': {
      'en': 'Local Configuration',
      'es': 'Configuraciones Locales',
      'pt': 'Configurações Locais',
    },
    'q0cjsodz': {
      'en': 'Superior Port Configuration (Serial)',
      'es': 'Configuraciones de Porta Superior (Serie)',
      'pt': 'Configurações da Porta Superior (Serial)',
    },
    'on829mgg': {
      'en': 'Output Voltage: \n(Powers the GPS)',
      'es': 'Tensão de Saída:\n(Alimenta o GPS)',
      'pt': 'Tensão de Saída: \n(Alimenta o GPS)',
    },
    'rxhs1309': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    '1vsqdvxq': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    'xwa0gsbf': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    '6plmf8ar': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'pez4x89r': {
      'en': 'Baudrate:',
      'es': 'Velocidad en baudios:',
      'pt': 'Taxa de transmissão:',
    },
    'cp6rfbp3': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    'dill485g': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    '0xano4wr': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    'v7ys4c1d': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'g5swhzh1': {
      'en': 'Paridade:',
      'es': 'Paridad:',
      'pt': 'Paridade:',
    },
    'rqlyy46e': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    'up48jzdv': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    'iu3z1dq5': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    'bfiniqhz': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'g8k7llx8': {
      'en': 'Bits de Parada:',
      'es': 'Bits de Parada:',
      'pt': 'Bits de Parada:',
    },
    '1482ev03': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    'le3pgdu8': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    'k8cx5il3': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    'tytmf2oj': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'kbq0kqth': {
      'en': 'Controle de Fluxo:',
      'es': 'Control de flujo:',
      'pt': 'Controle de Fluxo:',
    },
    'e87em38o': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    '4v1lbd1n': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    'z7354xgw': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    'vt5vthc5': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    '3uj1ixbh': {
      'en': 'Databits:',
      'es': 'Bits de datos:',
      'pt': 'Bits de dados:',
    },
    'o27xe4u3': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    '26qv4rsd': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    'eyo6tgen': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    'b42kje3x': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'x8hursuh': {
      'en': 'Test Configuration',
      'es': 'Probar configuraciones',
      'pt': 'Testar Configurações',
    },
    'k9dsf24l': {
      'en': 'Next page',
      'es': 'Próxima página',
      'pt': 'Próxima página',
    },
    'rgswdet3': {
      'en': 'Home',
      'es': 'Home',
      'pt': 'Home',
    },
  },
  // ModoSourceWifi
  {
    '99xhauvf': {
      'en': 'BDR_01',
      'es': 'BDR_01',
      'pt': 'BDR_01',
    },
    'g0d0rdve': {
      'en': 'Source Configuration',
      'es': 'Configuraciones Source',
      'pt': 'Configurações Source',
    },
    'u7gzchax': {
      'en': 'WiFi Configuration',
      'es': 'Configuraciones WiFi',
      'pt': 'Configurações WiFi',
    },
    'nof3p4pv': {
      'en': 'Select the network you want to connect to.',
      'es': 'Seleccione una red en la que desee conectarse.',
      'pt': 'Selecione a rede onde você deseja se conectar.',
    },
    'akoqdkhf': {
      'en': 'WiFi Network:',
      'es': 'Red WiFi:',
      'pt': 'Rede WiFi:',
    },
    'lbugz3g4': {
      'en': 'WiFi Password:',
      'es': 'Señal WiFi:',
      'pt': 'Senha WiFi:',
    },
    'nwzx3rlr': {
      'en': 'Test Configurations',
      'es': 'Probar configuraciones',
      'pt': 'Testar Configurações',
    },
    'akmm4l9k': {
      'en': 'Next page',
      'es': 'Próxima página',
      'pt': 'Próxima página',
    },
    '1gcfoi7m': {
      'en': 'Home',
      'es': 'Home',
      'pt': 'Home',
    },
  },
  // ModoSourceNtp
  {
    'dziqyk7x': {
      'en': 'BDR_01',
      'es': 'BDR_01',
      'pt': 'BDR_01',
    },
    '4e2rk98k': {
      'en': 'Source Configuration',
      'es': 'Configuraciones Source',
      'pt': 'Configurações Source',
    },
    'tzxohbeq': {
      'en': 'NTRIP Configuration',
      'es': 'Configuraciones NTRIP',
      'pt': 'Configurações NTRIP',
    },
    'qcjtf944': {
      'en': 'Enter the credentials of the NTRIP server you want to connect to.',
      'es': 'Digite as credenciais do server NTRIP que usted desea se conecta.',
      'pt':
          'Digite as credenciais do servidor NTRIP que você deseja se conectar.',
    },
    'upeq54q9': {
      'en': 'Host IP:',
      'es': 'Dirección IP del host:',
      'pt': 'IP do host:',
    },
    '3pkoqc15': {
      'en': 'Port:',
      'es': 'Puerta:',
      'pt': 'Porta:',
    },
    'y6q4hn7j': {
      'en': 'MountPoint:',
      'es': 'MountPoint:',
      'pt': 'MountPoint:',
    },
    'bf9h77ca': {
      'en': 'NTRIP revision 1.0 (password/user authentication',
      'es': 'NTRIP revisión 1.0 (autentificação senha/ usuário',
      'pt': 'NTRIP revisão 1.0 (autentificação senha/ usuário',
    },
    'el547wlj': {
      'en': 'Y',
      'es': 'S',
      'pt': 'S',
    },
    'c2br9l63': {
      'en': 'N',
      'es': 'N',
      'pt': 'N',
    },
    'jj80wewg': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'ull4aign': {
      'en': 'User:',
      'es': 'Usuario:',
      'pt': 'Usuário:',
    },
    'yuk7f9mb': {
      'en': 'Password:',
      'es': 'Señal:',
      'pt': 'Senha:',
    },
    'nwzmbmsj': {
      'en': 'Test Configuration',
      'es': 'Probar configuraciones',
      'pt': 'Testar Configurações',
    },
    '21kprbvf': {
      'en': 'Next Page',
      'es': 'Próxima página',
      'pt': 'Próxima página',
    },
    'ui1p9fon': {
      'en': 'Home',
      'es': 'Home',
      'pt': 'Home',
    },
  },
  // ModoSourceSaida
  {
    'n4dvojzv': {
      'en': 'BDR_01',
      'es': 'BDR_01',
      'pt': 'BDR_01',
    },
    '9zjkogg5': {
      'en': 'Source Configuration',
      'es': 'Configuraciones Source',
      'pt': 'Configurações Source',
    },
    'gyogmacm': {
      'en': 'Upper Port Settings (Serial)',
      'es': 'Configuraciones de Porta Superior (Serie)',
      'pt': 'Configurações da Porta Superior (Serial)',
    },
    'kv6pbsw2': {
      'en': 'Output Voltage:\n(Powers the GPS)',
      'es': 'Tensão de Saída: \n(Alimenta o GPS)',
      'pt': 'Tensão de Saída:\n(Alimenta o GPS)',
    },
    '36xdwdar': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    'idk7uba7': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    'gwwqa9ah': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    'jf1jnn7q': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'kbykevtd': {
      'en': 'Baudrate:',
      'es': 'Velocidad en baudios:',
      'pt': 'Taxa de transmissão:',
    },
    'bqwrc8qd': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    'vwfoy1ws': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    '30sttetu': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    '4ycffg7b': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'm2j5bbta': {
      'en': 'Parity:',
      'es': 'Paridad:',
      'pt': 'Paridade:',
    },
    'k6n7ttrh': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    'pybm62oc': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    'jkxgu0eo': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    'zym925ku': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'rvzwbxbk': {
      'en': 'Stop Bits:',
      'es': 'Bits de Parada:',
      'pt': 'Bits de Parada:',
    },
    'yh4zx1s6': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    'g3buz1qt': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    '5q3rp61y': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    'k706ob8r': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'zbii5cq0': {
      'en': 'Flux Control:',
      'es': 'Control de flujo:',
      'pt': 'Controle de Fluxo:',
    },
    'pr36d5kj': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    'oohji8ku': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    'l07jf81p': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    'ao3qklr9': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'gwr21zmq': {
      'en': 'Databits:',
      'es': 'Bits de datos:',
      'pt': 'Bits de dados:',
    },
    'lh4d29im': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    'yu0pdnvj': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    '2426c286': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    'zhavz2iq': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    '8yzoi50i': {
      'en': 'Test Configuration',
      'es': 'Probar configuraciones',
      'pt': 'Testar Configurações',
    },
    'eo4llmpn': {
      'en': 'Next page',
      'es': 'Próxima página',
      'pt': 'Próxima página',
    },
    '9iw8h807': {
      'en': 'Home',
      'es': 'Home',
      'pt': 'Home',
    },
  },
  // ModoClienteWifi
  {
    'gm0swgwf': {
      'en': 'BDR_01',
      'es': 'BDR_01',
      'pt': 'BDR_01',
    },
    'fxur7jjy': {
      'en': 'Client Configuration',
      'es': 'Configuraciones Cliente',
      'pt': 'Configurações Cliente',
    },
    'hj42y90n': {
      'en': 'WiFi Configuration',
      'es': 'Configuraciones WiFi',
      'pt': 'Configurações WiFi',
    },
    '531e9s2e': {
      'en': 'Select the network you want to connect to.',
      'es': 'Seleccione una red en la que desee conectarse.',
      'pt': 'Selecione a rede onde você deseja se conectar.',
    },
    '16sha65q': {
      'en': 'WiFi Network:',
      'es': 'Red WiFi:',
      'pt': 'Rede WiFi:',
    },
    'pswim2wl': {
      'en': 'WiFi Password:',
      'es': 'Señal WiFi:',
      'pt': 'Senha WiFi:',
    },
    'cwzobkve': {
      'en': 'Test Configuration',
      'es': 'Probar configuraciones',
      'pt': 'Testar Configurações',
    },
    'vnxgc12f': {
      'en': 'Next Page',
      'es': 'Próxima página',
      'pt': 'Próxima página',
    },
    'g66z9gyf': {
      'en': 'Home',
      'es': 'Home',
      'pt': 'Home',
    },
  },
  // ModoClienteNtp
  {
    'l6owadir': {
      'en': 'BDR_01',
      'es': 'BDR_01',
      'pt': 'BDR_01',
    },
    'ffgyrscz': {
      'en': 'Client Configuration',
      'es': 'Configuraciones Cliente',
      'pt': 'Configurações Cliente',
    },
    '5udqrgka': {
      'en': 'NTRIP Configuration',
      'es': 'Configuraciones NTRIP',
      'pt': 'Configurações NTRIP',
    },
    '3tcqptbu': {
      'en': 'Enter the credentials of the NTRIP server you want to connect to.',
      'es': 'Digite as credenciais do server NTRIP que usted desea se conecta.',
      'pt': 'Digite as credenciais do servidor NTRIP que você deseja conectar.',
    },
    'c35ijav8': {
      'en': 'Host IP:',
      'es': 'Dirección IP del host:',
      'pt': 'IP do host:',
    },
    'x4oqy7bd': {
      'en': 'Port:',
      'es': 'Puerta:',
      'pt': 'Porta:',
    },
    '31a1060v': {
      'en': 'MountPoint:',
      'es': 'MountPoint:',
      'pt': 'MountPoint:',
    },
    'pbk9megv': {
      'en': 'User:',
      'es': 'Usuario:',
      'pt': 'Usuário:',
    },
    '0u5xt6vu': {
      'en': 'Password:',
      'es': 'Señal:',
      'pt': 'Senha:',
    },
    '1e0hhwx4': {
      'en': 'Location',
      'es': 'Localización',
      'pt': 'Localização',
    },
    'ii9mjcr6': {
      'en':
          'You can select send and fetch the location, if the box below is not checked the location will be ignored.',
      'es':
          'Puede seleccionar enviar y recuperar la ubicación; si la casilla de verificación a continuación no está seleccionada, no se hará referencia a la ubicación.',
      'pt':
          'Você pode selecionar enviar e buscar a localização , caso a checkbox abaixo não estiver marcada a localização será irrelevada.',
    },
    'dd3wak59': {
      'en': 'Find Location',
      'es': 'Buscar Localización',
      'pt': 'Pesquisar Localização',
    },
    '8gsnhngw': {
      'en': 'Test Configuration',
      'es': 'Probar configuraciones',
      'pt': 'Testar Configurações',
    },
    'dwkjw4gl': {
      'en': 'Next Page',
      'es': 'Próxima página',
      'pt': 'Próxima página',
    },
    'v12pe17e': {
      'en': 'Home',
      'es': 'Home',
      'pt': 'Home',
    },
  },
  // ModoClienteSaida
  {
    'l9t5du7l': {
      'en': 'BDR_01',
      'es': 'BDR_01',
      'pt': 'BDR_01',
    },
    '6jznvzaq': {
      'en': 'Configurações Cliente',
      'es': 'Configuraciones Cliente',
      'pt': 'Configurações Cliente',
    },
    'xi0ccxgp': {
      'en': 'Upper Port Settings (Serial)',
      'es': 'Configuraciones de Porta Superior (Serie)',
      'pt': 'Configurações da Porta Superior (Serial)',
    },
    'k6nsjp9z': {
      'en': 'Output Voltage:\n(Powers the GPS)',
      'es': 'Tensão de Saída: \n(Alimenta o GPS)',
      'pt': 'Tensão de Saída:\n(Alimenta o GPS)',
    },
    'xlitqobk': {
      'en': '5V',
      'es': '5 V',
      'pt': '5V',
    },
    'y8lvx72t': {
      'en': '9V',
      'es': '9 V',
      'pt': '9V',
    },
    'a8twqog3': {
      'en': '12V',
      'es': '12 V',
      'pt': '12V',
    },
    'v064kslm': {
      'en': '15V',
      'es': '15 V',
      'pt': '15V',
    },
    '61v3xhs7': {
      'en': '20V',
      'es': '20 V',
      'pt': '20V',
    },
    'he5kif5r': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'stsl8s4k': {
      'en': 'Baudrate:',
      'es': 'Velocidad en baudios:',
      'pt': 'Taxa de transmissão:',
    },
    'go1i2gbd': {
      'en': '9600',
      'es': '9600',
      'pt': '9600',
    },
    'vj1x0xfs': {
      'en': '19200',
      'es': '19200',
      'pt': '19200',
    },
    'w0w736e1': {
      'en': '38400',
      'es': '38400',
      'pt': '38400',
    },
    'c4oqtgh4': {
      'en': '57600',
      'es': '57600',
      'pt': '57600',
    },
    '3z0qxg7e': {
      'en': '115200',
      'es': '115200',
      'pt': '115200',
    },
    '4vo96nhs': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    '251j2dfu': {
      'en': 'Paridade:',
      'es': 'Paridad:',
      'pt': 'Paridade:',
    },
    'kl7mb0kb': {
      'en': 'None',
      'es': 'Ninguno',
      'pt': 'Nenhum',
    },
    '55bkp6wh': {
      'en': 'Even',
      'es': 'Incluso',
      'pt': 'Até',
    },
    'r7lfrkf6': {
      'en': 'Odd',
      'es': 'Extraño',
      'pt': 'Chance',
    },
    '8scqmr1p': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'dbqws6r5': {
      'en': 'Bits de Parada:',
      'es': 'Bits de Parada:',
      'pt': 'Bits de Parada:',
    },
    'oatweo1i': {
      'en': '1',
      'es': '1',
      'pt': '1',
    },
    'pds3mgpg': {
      'en': '1.5',
      'es': '1.5',
      'pt': '1.5',
    },
    'fis95yyk': {
      'en': '2',
      'es': '2',
      'pt': '2',
    },
    'houvtv56': {
      'en': '3',
      'es': '3',
      'pt': '3',
    },
    'i6obu6no': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'otvgrjvq': {
      'en': 'Flux Control:',
      'es': 'Control de flujo:',
      'pt': 'Controle de Fluxo:',
    },
    '9oe7jwxb': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'pt': 'Opção 1',
    },
    'nsbzcv1y': {
      'en': 'Option 2',
      'es': 'Opción 2',
      'pt': 'Opção 2',
    },
    '6zwur787': {
      'en': 'Option 3',
      'es': 'Opción 3',
      'pt': 'Opção 3',
    },
    'f8keih1k': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    'c9t9o141': {
      'en': 'Databits:',
      'es': 'Bits de datos:',
      'pt': 'Bits de dados:',
    },
    'rdprecgc': {
      'en': '5',
      'es': '5',
      'pt': '5',
    },
    'gprtm9qj': {
      'en': '6',
      'es': '6',
      'pt': '6',
    },
    'h9qv7lyz': {
      'en': '7',
      'es': '7',
      'pt': '7',
    },
    '9jrna0p7': {
      'en': '8',
      'es': '8',
      'pt': '8',
    },
    'lo8riqcq': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    '9lw7pn82': {
      'en': 'Test Configuration',
      'es': 'Probar configuraciones',
      'pt': 'Testar Configurações',
    },
    'n03mxxuh': {
      'en': 'Next page',
      'es': 'Próxima página',
      'pt': 'Próxima página',
    },
    'kuu94q4m': {
      'en': 'Home',
      'es': 'Home',
      'pt': 'Home',
    },
  },
  // ModoLocalSalvar
  {
    'mx5n3p45': {
      'en': 'BDR_01',
      'es': 'BDR_01',
      'pt': 'BDR_01',
    },
    '9nc1939o': {
      'en': 'Local Configuration',
      'es': 'Configuraciones locales',
      'pt': 'Configurações Locais',
    },
    '1hyuaxh3': {
      'en': 'Save Data',
      'es': 'Salvar Dados',
      'pt': 'Salvar dados',
    },
    'oi2pflld': {
      'en': 'Exit Configuration Mode',
      'es': 'Sair do Modo de Configuración',
      'pt': 'Sair do Modo de Configuração',
    },
    'j3jb1shv': {
      'en': 'Home',
      'es': 'Home',
      'pt': 'Home',
    },
  },
  // ModoClienteSalvar
  {
    'adpsc8e0': {
      'en': 'BDR_01',
      'es': 'BDR_01',
      'pt': 'BDR_01',
    },
    'bgwh5etg': {
      'en': 'Client Configuration',
      'es': 'Configuraciones Cliente',
      'pt': 'Configurações Cliente',
    },
    'oicxb4f1': {
      'en': 'Save Data',
      'es': 'Salvar Dados',
      'pt': 'Salvar dados',
    },
    'yw4apbkq': {
      'en': 'Exit Configuration Mode',
      'es': 'Sair do Modo de Configuración',
      'pt': 'Sair do Modo de Configuração',
    },
    'c1sao41s': {
      'en': 'Home',
      'es': 'Home',
      'pt': 'Home',
    },
  },
  // ModoSourceSalvar
  {
    'py2et1ax': {
      'en': 'BDR_01',
      'es': 'BDR_01',
      'pt': 'BDR_01',
    },
    'y2oin03a': {
      'en': 'Source Configuration',
      'es': 'Configuraciones Source',
      'pt': 'Configurações Source',
    },
    '307nl7sn': {
      'en': 'Save Data',
      'es': 'Salvar Dados',
      'pt': 'Salvar dados',
    },
    '036drg22': {
      'en': 'Exit Configuration Mode',
      'es': 'Sair do Modo de Configuración',
      'pt': 'Sair do Modo de Configuração',
    },
    'ws73ngf1': {
      'en': 'Home',
      'es': 'Home',
      'pt': 'Home',
    },
  },
  // Help
  {
    'qz3jfh0s': {
      'en': 'BDR_01',
      'es': '',
      'pt': '',
    },
    'v0qibq8k': {
      'en': 'Help',
      'es': '',
      'pt': '',
    },
    'g5mdd9rf': {
      'en': '1.0\n1.2\n1.3\n2.0',
      'es': '',
      'pt': '',
    },
    'nol48zmc': {
      'en': 'Home',
      'es': '',
      'pt': '',
    },
  },
  // AdvConf
  {
    't9lzrkhn': {
      'en': 'BDR_01',
      'es': '',
      'pt': '',
    },
    '02d30qpx': {
      'en': 'Advanced Settings',
      'es': '',
      'pt': '',
    },
    'efz95bkr': {
      'en': '\n',
      'es': '',
      'pt': '',
    },
    'bmuajh89': {
      'en': 'AAAAAAAAA',
      'es': '',
      'pt': '',
    },
    'tu3qj5rs': {
      'en': 'BBBBB',
      'es': '',
      'pt': '',
    },
    'ajbe5bcu': {
      'en': 'CCCCCCCCCCC',
      'es': '',
      'pt': '',
    },
    '2dlsfwiv': {
      'en': 'Home',
      'es': '',
      'pt': '',
    },
  },
  // Options
  {
    'tlnf0rpc': {
      'en': 'BDR_01',
      'es': 'BDR_01',
      'pt': 'BDR_01',
    },
    'b6q0zilb': {
      'en': 'Profile Configuration',
      'es': 'Perfíles de configuración',
      'pt': 'Perfís de configuração',
    },
    'k6sfouhl': {
      'en': 'Advanced Settings',
      'es': 'Configuraciones avanzadas',
      'pt': 'Configurações Avançadas',
    },
    '6gpz2nz5': {
      'en': 'Information',
      'es': 'Información',
      'pt': 'Informações',
    },
    'dnisega8': {
      'en': 'Help',
      'es': 'Ayuda',
      'pt': 'Ajuda',
    },
    'z8bx5w4b': {
      'en': 'Close',
      'es': 'Fechar',
      'pt': 'Fechar',
    },
  },
  // BuscarLoc
  {
    'ja343oyu': {
      'en': 'Send the location to the NTRIP server?',
      'es': '¿Mandar localización para el servidor NTRIP?',
      'pt': 'Mandar localização para o servidor NTRIP?',
    },
    'c09xszgm': {
      'en': 'Y',
      'es': 'S',
      'pt': 'S',
    },
    'wt8lhs4n': {
      'en': 'N',
      'es': 'N',
      'pt': 'N',
    },
    '86kdh0ie': {
      'en': 'Search...',
      'es': 'Buscar...',
      'pt': 'Procurar...',
    },
    '6ufqc3sm': {
      'en': 'Latitude:',
      'es': 'Latitud:',
      'pt': 'Latitude:',
    },
    '8t1wcz8o': {
      'en': 'Longitude:',
      'es': 'Longitud:',
      'pt': 'Longitude:',
    },
    'ft6a1ysv': {
      'en': 'Height:',
      'es': 'Altitud:',
      'pt': 'Altitude:',
    },
    'fy8bkgy2': {
      'en': 'Precision:',
      'es': 'Precisión:',
      'pt': 'Precisão:',
    },
    'd3jzxlqo': {
      'en': 'Tempo UTC:',
      'es': 'Tiempo UTC:',
      'pt': 'Tempo UTC:',
    },
    '4hei5kd5': {
      'en': 'Buscar Localização',
      'es': 'Buscar Localización',
      'pt': 'Buscar Localização',
    },
  },
  // Miscellaneous
  {
    'a4jroewp': {
      'en':
          'In order for the app to run correctly is necessary to turn on the location.',
      'es':
          'Es necesario un acceso a la localización para el funcionamiento correcto de la aplicación.',
      'pt':
          'É necessário acesso à localização para o funcionamento correto do aplicativo.',
    },
    'xl2zy7q9': {
      'en': 'coarse',
      'es': 'coarse',
      'pt': 'coarse',
    },
    '3rybiqwb': {
      'en': 'fine',
      'es': 'fine',
      'pt': 'fine',
    },
    'wh2on2us': {
      'en': 'background',
      'es': 'background',
      'pt': 'background',
    },
    'lym9u7bb': {
      'en': '',
      'es': '',
      'pt': '',
    },
    'a1onkb0v': {
      'en': '',
      'es': '',
      'pt': '',
    },
    'v39k9i7q': {
      'en': '',
      'es': '',
      'pt': '',
    },
    'jt9wtuak': {
      'en': '',
      'es': '',
      'pt': '',
    },
    't2ksp4r8': {
      'en': '',
      'es': '',
      'pt': '',
    },
    'mn6o4o2u': {
      'en': '',
      'es': '',
      'pt': '',
    },
    '1sm3om4i': {
      'en': '',
      'es': '',
      'pt': '',
    },
    'pvjzem2z': {
      'en': '',
      'es': '',
      'pt': '',
    },
    's6q2tjrm': {
      'en': '',
      'es': '',
      'pt': '',
    },
    'wmjm6ydq': {
      'en': '',
      'es': '',
      'pt': '',
    },
    'dsailz0w': {
      'en': '',
      'es': '',
      'pt': '',
    },
    'v4wjdjre': {
      'en': '',
      'es': '',
      'pt': '',
    },
    'mr97lm0g': {
      'en': '',
      'es': '',
      'pt': '',
    },
    'l67azrpl': {
      'en': '',
      'es': '',
      'pt': '',
    },
    'yt7b9m60': {
      'en': '',
      'es': '',
      'pt': '',
    },
    '60s0zdvu': {
      'en': '',
      'es': '',
      'pt': '',
    },
    '2x8vgm11': {
      'en': '',
      'es': '',
      'pt': '',
    },
    '2od4uf5c': {
      'en': '',
      'es': '',
      'pt': '',
    },
    '7qnggjdk': {
      'en': '',
      'es': '',
      'pt': '',
    },
    '42lt7kv8': {
      'en': '',
      'es': '',
      'pt': '',
    },
    'c5fzxx80': {
      'en': '',
      'es': '',
      'pt': '',
    },
    'ohz3ijg2': {
      'en': '',
      'es': '',
      'pt': '',
    },
    'igw39li8': {
      'en': '',
      'es': '',
      'pt': '',
    },
    'ygsa965x': {
      'en': '',
      'es': '',
      'pt': '',
    },
    'clprmyb0': {
      'en': '',
      'es': '',
      'pt': '',
    },
  },
].reduce((a, b) => a..addAll(b));
