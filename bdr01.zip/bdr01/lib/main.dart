import 'dart:async';
import 'package:bdr01copy/backend/connectivity/globals.dart' as globals;

import 'package:riverpod/riverpod.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/services.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'package:provider/provider.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_web_plugins/url_strategy.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import 'flutter_flow/flutter_flow_util.dart';
import 'flutter_flow/internationalization.dart';
import 'flutter_flow/nav/nav.dart';
import 'index.dart';
import 'dart:developer' as developer;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  GoRouter.optionURLReflectsImperativeAPIs = true;
  usePathUrlStrategy();

  await FlutterFlowTheme.initialize();

  final appState = FFAppState(); // Initialize FFAppState
  await appState.initializePersistedState();

  final info = NetworkInfo();
  String? ssid = await info.getWifiName();
  String? ip = await info.getWifiIP();
  print('Current SSID: $ssid');
  print('Current IP: $ip');
  String correctPrefix = "BDR";

  String initialRoute = '/homePage';

  //if (ssid != null && ssid.startsWith(correctPrefix)) {
    //initialRoute = '/homePage';
  //} else {
    //initialRoute = '/connectionPage';
  //}

  runApp(ChangeNotifierProvider(
    create: (context) => appState,
    child: MyApp(initialRoute: initialRoute),
  ));
}

class MyApp extends StatefulWidget {
  final String initialRoute;
  MyApp({required this.initialRoute});

  @override
  State<MyApp> createState() => _MyAppState();

  static _MyAppState of(BuildContext context) =>
      context.findAncestorStateOfType<_MyAppState>()!;
}

class _MyAppState extends State<MyApp> {
  Locale? _locale;
  List<ConnectivityResult> _connectionStatus = [ConnectivityResult.none];
  final Connectivity _connectivity = Connectivity();
  late StreamSubscription<List<ConnectivityResult>> _connectivitySubscription;

  ThemeMode _themeMode = FlutterFlowTheme.themeMode;

  late AppStateNotifier _appStateNotifier;
  late GoRouter _router;

  @override
  void initState() {
    super.initState();
    initConnectivity();

    _connectivitySubscription =
        _connectivity.onConnectivityChanged.listen(_updateConnectionStatus);

    _appStateNotifier = AppStateNotifier.instance;
    _router = createRouter(_appStateNotifier, initialRoute: widget.initialRoute);
  }

  @override
  void dispose() {
    _connectivitySubscription.cancel();
    super.dispose();
  }

  Future<void> initConnectivity() async {
    late List<ConnectivityResult> result;
    // Platform messages may fail, so we use a try/catch PlatformException.
    try {
      result = await _connectivity.checkConnectivity();
    } on PlatformException catch (e) {
      developer.log('Couldn\'t check connectivity status', error: e);
      return;
    }

    // If the widget was removed from the tree while the asynchronous platform
    // message was in flight, we want to discard the reply rather than calling
    // setState to update our non-existent appearance.
    if (!mounted) {
      return Future.value(null);
    }

    return _updateConnectionStatus(result);
  }

  Future<void> _updateConnectionStatus(List<ConnectivityResult> result) async {
    setState(() {
      _connectionStatus = result;
    });
    final info = NetworkInfo();
    String? ssid = await info.getWifiName();
    String? ip = await info.getWifiIP();
    print ('valor do ip é $ip');
    print ('valor do ssid é $ssid');

    //if (ssid != null && ssid.startsWith(correctPrefix)) {
    //initialRoute = '/homePage';
    //} else {
    //initialRoute = '/connectionPage';
    //}

    if ((result.contains(ConnectivityResult.wifi) || result.contains(ConnectivityResult.mobile))) {
      print('Connected to BDR');
      globals.bdr_avail = true;
      globals.check_connectivity = true;
      globals.check_internet = true;
    } else {
      print('Not Connected to BDR');
      globals.bdr_avail = false;
      globals.check_connectivity = true;
      globals.check_internet = true;
    }
    print('Connectivity changed: $_connectionStatus');
  }

      void setLocale(String language) {
    safeSetState(() => _locale = createLocale(language));
  }

  void setThemeMode(ThemeMode mode) => safeSetState(() {
        _themeMode = mode;
        FlutterFlowTheme.saveThemeMode(mode);
      });

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'BDR01COPY',
      localizationsDelegates: [
        FFLocalizationsDelegate(),
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      locale: _locale,
      supportedLocales: const [
        Locale('en'),
        Locale('pt'),
        Locale('es'),
      ],
      theme: ThemeData(
        brightness: Brightness.light,
        useMaterial3: false,
      ),
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: false,
      ),
      themeMode: _themeMode,
      routerConfig: _router,
    );
  }
}