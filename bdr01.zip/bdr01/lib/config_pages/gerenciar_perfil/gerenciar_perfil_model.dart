import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/menu/options/options_widget.dart';
import 'gerenciar_perfil_widget.dart' show GerenciarPerfilWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class GerenciarPerfilModel extends FlutterFlowModel<GerenciarPerfilWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for Perfil widget.
  String? perfilValue;
  FormFieldController<String>? perfilValueController;
  // Stores action output result for [Backend Call - API (SendPerfil)] action in Button widget.
  ApiCallResponse? sendPerfil;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
