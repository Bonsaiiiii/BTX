import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/menu/options/options_widget.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'gerenciar_perfil_model.dart';
import 'package:bdr01copy/backend/connectivity/globals.dart' as globals;
export 'gerenciar_perfil_model.dart';

class GerenciarPerfilWidget extends StatefulWidget {
  const GerenciarPerfilWidget({
    super.key,
    String? defaul,
    String? fabrica,
    String? padrao,
  })  : this.defaul = defaul ?? 'Default',
        this.fabrica = fabrica ?? 'Fábrica',
        this.padrao = padrao ?? 'Padrao';

  final String defaul;
  final String fabrica;
  final String padrao;

  @override
  State<GerenciarPerfilWidget> createState() => _GerenciarPerfilWidgetState();
}

class _GerenciarPerfilWidgetState extends State<GerenciarPerfilWidget> {
  late GerenciarPerfilModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GerenciarPerfilModel());
  }

  @override
  void dispose() {
    _model.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<ApiCallResponse>(
      future: RequestCall.call(
        saidaTenL: '\$.portaSupL[0].saidaTenL',
        baudrateL: '\$.portaSupL[0].baudrateL',
        paridadeL: '\$.portaSupL[0].paridadeL',
        bitsParaL: '\$.portaSupL[0].bitsParaL',
        contrFluxL: '\$.portaSupL[0].contrFluxL',
        datbitL: '\$.portaSupL[0].datbitL',
        ssidL: '\$.wifiL[0].ssidL',
        senwiL: '\$.wifiL[0].senwiL',
        hostNtpL: '\$.ntripConfL[0].hostNtpL',
        portNtpL: '\$.ntripConfLL[0].portNtpL',
        mtpntL: '\$.ntripConfL[0].mtpntL',
        userL: '\$.ntripConfL[0].userL',
        senL: '\$.ntripConfL[0].senL',
        modo: '\$.avancado[0].Modo',
        saidaTenC: '\$.portaSupC[0].saidaTenC',
        baudrateC: '\$.portaSupC[0].baudrateC',
        paridadeC: '\$.portaSupC[0].paridadeC',
        bitsParaC: '\$.portaSupC[0].bitsParaC',
        contrFluxC: '\$.portaSupC[0].contrFluxC',
        datbitC: '\$.portaSupC[0].datbitC',
        ssidC: '\$.wifiC[0].ssidC',
        senwiC: '\$.wifiC[0].senwiC',
        hostNtpC: '\$.ntripConfC[0].hostNtpC',
        portNtpC: '\$.ntripConfC[0].portNtpC',
        mtpntC: '\$.ntripConfC[0].mtpntC',
        userC: '\$.ntripConfC[0].userC',
        senC: '\$.ntripConfC[0].senC',
        sendLatLong: '\$.latLong[0].sendLatLong',
        lat: '\$.latLong[0].lat',
        lon: '\$.latLong[0].lon',
        alt: '\$.latLong[0].alt',
        pre: '\$.latLong[0].pre',
        utc: '\$.latLong[0].utc',
        saidaTenS: '\$.portaSupS[0].saidaTenS',
        baudrateS: '\$.portaSupS[0].baudrateS',
        paridadeS: '\$.portaSupS[0].paridadeS',
        bitsParaS: '\$.portaSupS[0].bitsParaS',
        contrFluxS: '\$.portaSupS[0].contrFluxS',
        datbitS: '\$.portaSupS[0].datbitS',
        ssidS: '\$.wifiS[0].ssidS',
        senwiS: '\$.wifiS[0].senwiS',
        hostNtpS: '\$.ntripConfS[0].hostNtpS',
        portNtpS: '\$.ntripConfS[0].portNtpS',
        mtpntS: '\$.ntripConfS[0].mtpntS',
        sendRev2: '\$.ntripConfS[0].sendRev2',
        userS: '\$.ntripConfS[0].userS',
        senS: '\$.ntripConfS[0].senS',
        perfil: '\$.avancado[0].Perfil',
      ),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: Colors.white,
            body: Center(
              child: SizedBox(
                width: 50.0,
                height: 50.0,
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(
                    FlutterFlowTheme.of(context).primary,
                  ),
                ),
              ),
            ),
          );
        }
        final gerenciarPerfilRequestResponse = snapshot.data!;

        return GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Scaffold(
            key: scaffoldKey,
            backgroundColor: Colors.white,
            body: SafeArea(
              top: true,
              child: Align(
                alignment: AlignmentDirectional(0.0, -1.0),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Align(
                        alignment: AlignmentDirectional(0.0, -1.0),
                        child: Container(
                          width: double.infinity,
                          height: 60.0,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(0.0),
                              bottomRight: Radius.circular(0.0),
                              topLeft: Radius.circular(0.0),
                              topRight: Radius.circular(0.0),
                            ),
                            border: Border.all(
                              color: Color(0xFFD5D3E3),
                              width: 2.0,
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Container(
                                width: 150.0,
                                height: 100.0,
                                decoration: BoxDecoration(),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  children: [
                                    Align(
                                      alignment:
                                          AlignmentDirectional(-1.0, 0.0),
                                      child: FFButtonWidget(
                                        onPressed: () async {
                                          context.safePop();
                                        },
                                        text: '',
                                        icon: Icon(
                                          Icons.arrow_back_rounded,
                                          color: Colors.black,
                                          size: 23.0,
                                        ),
                                        options: FFButtonOptions(
                                          width: 32.0,
                                          height: 30.0,
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 0.0, 0.0, 0.0),
                                          iconPadding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 0.0, 0.0, 0.0),
                                          color: Colors.white,
                                          textStyle:
                                              FlutterFlowTheme.of(context)
                                                  .titleSmall
                                                  .override(
                                                    fontFamily: 'Inter Tight',
                                                    color: Colors.white,
                                                    letterSpacing: 0.0,
                                                  ),
                                          elevation: 0.0,
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment:
                                          AlignmentDirectional(-1.0, 0.0),
                                      child: FFButtonWidget(
                                        onPressed: () async {
                                          context.pushNamed('HomePage');
                                        },
                                        text: '',
                                        icon: Icon(
                                          Icons.home_rounded,
                                          color: Colors.black,
                                          size: 23.0,
                                        ),
                                        options: FFButtonOptions(
                                          width: 32.0,
                                          height: 30.0,
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 0.0, 0.0, 0.0),
                                          iconPadding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 0.0, 0.0, 0.0),
                                          color: Colors.white,
                                          textStyle:
                                              FlutterFlowTheme.of(context)
                                                  .titleSmall
                                                  .override(
                                                    fontFamily: 'Inter Tight',
                                                    color: Colors.white,
                                                    letterSpacing: 0.0,
                                                  ),
                                          elevation: 0.0,
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                        ),
                                      ),
                                    ),
                                    Align(
                                      alignment:
                                          AlignmentDirectional(-1.0, 0.0),
                                      child: Text(
                                        FFLocalizations.of(context).getText(
                                          'xxs3qfhp' /* BDR_01 */,
                                        ),
                                        style: FlutterFlowTheme.of(context)
                                            .titleLarge
                                            .override(
                                              fontFamily: 'Montserrat',
                                              color: Color(0xFF14181B),
                                              letterSpacing: 0.0,
                                            ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Align(
                                alignment: AlignmentDirectional(1.0, 0.0),
                                child: FFButtonWidget(
                                  onPressed: () async {
                                    await showModalBottomSheet(
                                      isScrollControlled: true,
                                      backgroundColor: Colors.transparent,
                                      enableDrag: false,
                                      context: context,
                                      builder: (context) {
                                        return GestureDetector(
                                          onTap: () =>
                                              FocusScope.of(context).unfocus(),
                                          child: Padding(
                                            padding: MediaQuery.viewInsetsOf(
                                                context),
                                            child: OptionsWidget(),
                                          ),
                                        );
                                      },
                                    ).then((value) => safeSetState(() {}));
                                  },
                                  text: '',
                                  icon: Icon(
                                    Icons.menu_sharp,
                                    color: Colors.black,
                                    size: 23.0,
                                  ),
                                  options: FFButtonOptions(
                                    width: 32.0,
                                    height: 30.0,
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 0.0, 0.0, 0.0),
                                    iconPadding: EdgeInsets.all(0.0),
                                    color: Colors.white,
                                    textStyle: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .override(
                                          fontFamily: 'Inter Tight',
                                          color: Colors.white,
                                          letterSpacing: 0.0,
                                        ),
                                    elevation: 0.0,
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                ),
                              ),
                            ].divide(SizedBox(width: 200.0)),
                          ),
                        ),
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            FFLocalizations.of(context).getText(
                              'e2hewrk2' /* Active Profile:  */,
                            ),
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Montserrat',
                                  color: Color(0xFF14181B),
                                  fontSize: 30.0,
                                  letterSpacing: 0.0,
                                ),
                          ),
                          Text(
                            RequestCall.perfil(
                              gerenciarPerfilRequestResponse.jsonBody,
                            ).toString(),
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Montserrat',
                                  color: Color(0xFF14181B),
                                  fontSize: 30.0,
                                  letterSpacing: 0.0,
                                ),
                          ),
                        ],
                      ),
                      FFButtonWidget(
                        onPressed: () async {
                          if (_model.perfilValue == widget!.padrao
                              ? true
                              : false) {
                            await showDialog(
                              context: context,
                              builder: (alertDialogContext) {
                                return AlertDialog(
                                  title: Text('Alerta'),
                                  content: Text(
                                      'Não é possível alterar a configuração de Fábrica'),
                                  actions: [
                                    TextButton(
                                      onPressed: () =>
                                          Navigator.pop(alertDialogContext),
                                      child: Text('Ok'),
                                    ),
                                  ],
                                );
                              },
                            );
                          } else {
                            context.pushNamed('ModeSelection');
                          }
                        },
                        text: FFLocalizations.of(context).getText(
                          'wzm22ugf' /* Reconfigure Profile */,
                        ),
                        options: FFButtonOptions(
                          width: MediaQuery.sizeOf(context).width * 0.45,
                          height: 40.0,
                          padding: EdgeInsetsDirectional.fromSTEB(
                              16.0, 0.0, 16.0, 0.0),
                          iconPadding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          color: Color(0xFFE0E3E7),
                          textStyle:
                              FlutterFlowTheme.of(context).titleSmall.override(
                                    fontFamily: 'Montserrat',
                                    color: Color(0xFF14181B),
                                    letterSpacing: 0.0,
                                  ),
                          elevation: 0.0,
                          borderSide: BorderSide(
                            color: Color(0xFFD5D3E3),
                            width: 2.0,
                          ),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                      ),
                      Align(
                        alignment: AlignmentDirectional(-1.0, 0.0),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              5.0, 0.0, 0.0, 0.0),
                          child: Text(
                            FFLocalizations.of(context).getText(
                              'rzl1ype2' /* Select below which profile you... */,
                            ),
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Inter',
                                  color: Color(0xFF14181B),
                                  letterSpacing: 0.0,
                                ),
                          ),
                        ),
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Align(
                            alignment: AlignmentDirectional(0.0, -1.0),
                            child: FlutterFlowDropDown<String>(
                              controller: _model.perfilValueController ??=
                                  FormFieldController<String>(
                                _model.perfilValue ??= RequestCall.perfil(
                                  gerenciarPerfilRequestResponse.jsonBody,
                                ).toString(),
                              ),
                              options: [
                                FFLocalizations.of(context).getText(
                                  'rmgd4bwf' /* Padrao */,
                                ),
                                FFLocalizations.of(context).getText(
                                  'jxusmq0g' /* P1 */,
                                ),
                                FFLocalizations.of(context).getText(
                                  'rwbaij5k' /* P2 */,
                                ),
                                FFLocalizations.of(context).getText(
                                  '7uhfwu2f' /* P3 */,
                                )
                              ],
                              onChanged: (val) =>
                                  safeSetState(() => _model.perfilValue = val),
                              width: MediaQuery.sizeOf(context).width * 0.45,
                              height: 40.0,
                              textStyle: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Inter',
                                    letterSpacing: 0.0,
                                  ),
                              hintText: RequestCall.perfil(
                                gerenciarPerfilRequestResponse.jsonBody,
                              ).toString(),
                              icon: Icon(
                                Icons.keyboard_arrow_down_rounded,
                                color:
                                    FlutterFlowTheme.of(context).secondaryText,
                                size: 24.0,
                              ),
                              fillColor: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                              elevation: 2.0,
                              borderColor: Colors.transparent,
                              borderWidth: 0.0,
                              borderRadius: 8.0,
                              margin: EdgeInsetsDirectional.fromSTEB(
                                  12.0, 0.0, 12.0, 0.0),
                              hidesUnderline: true,
                              isOverButton: false,
                              isSearchable: false,
                              isMultiSelect: false,
                            ),
                          ),
                          FFButtonWidget(
                            onPressed: () async {
                              _model.sendPerfil = await SendPerfilCall.call(
                                perfil: _model.perfilValue,
                              );

                              if ((_model.sendPerfil?.succeeded ?? true)) {
                                await showDialog(
                                  context: context,
                                  builder: (alertDialogContext) {
                                    return AlertDialog(
                                      title: Text('Sucesso'),
                                      content: Text('Enviado'),
                                      actions: [
                                        TextButton(
                                          onPressed: () =>
                                              Navigator.pop(alertDialogContext),
                                          child: Text('Ok'),
                                        ),
                                      ],
                                    );
                                  },
                                );
                              }

                              safeSetState(() {});
                            },
                            text: FFLocalizations.of(context).getText(
                              'xdb62pif' /* Change Profile */,
                            ),
                            options: FFButtonOptions(
                              width: MediaQuery.sizeOf(context).width * 0.45,
                              height: 40.0,
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  16.0, 0.0, 16.0, 0.0),
                              iconPadding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 0.0),
                              color: Color(0xFFE0E3E7),
                              textStyle: FlutterFlowTheme.of(context)
                                  .titleSmall
                                  .override(
                                    fontFamily: 'Montserrat',
                                    color: Color(0xFF14181B),
                                    letterSpacing: 0.0,
                                  ),
                              elevation: 0.0,
                              borderSide: BorderSide(
                                color: Color(0xFFD5D3E3),
                                width: 2.0,
                              ),
                              borderRadius: BorderRadius.circular(8.0),
                            ),
                          ),
                        ],
                      ),
                    ]
                        .divide(SizedBox(height: 20.0))
                        .addToEnd(SizedBox(height: 20.0)),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
