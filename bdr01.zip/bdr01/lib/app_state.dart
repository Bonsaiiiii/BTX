import 'package:flutter/material.dart';
import 'backend/api_requests/api_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  String _Local = 'Local';
  String get Local => _Local;
  set Local(String value) {
    _Local = value;
  }

  String _Cliente = 'Cliente';
  String get Cliente => _Cliente;
  set Cliente(String value) {
    _Cliente = value;
  }

  String _Source = 'Source';
  String get Source => _Source;
  set Source(String value) {
    _Source = value;
  }
}
