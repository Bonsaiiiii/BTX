import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/menu/options/options_widget.dart';
import 'modo_cliente_widget.dart' show ModoClienteWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ModoClienteModel extends FlutterFlowModel<ModoClienteWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for inputsaidaTenC widget.
  String? inputsaidaTenCValue;
  FormFieldController<String>? inputsaidaTenCValueController;
  // State field(s) for inputbaudrateC widget.
  String? inputbaudrateCValue;
  FormFieldController<String>? inputbaudrateCValueController;
  // State field(s) for inputparidadeC widget.
  String? inputparidadeCValue;
  FormFieldController<String>? inputparidadeCValueController;
  // State field(s) for inputbitsParaC widget.
  String? inputbitsParaCValue;
  FormFieldController<String>? inputbitsParaCValueController;
  // State field(s) for inputcontrFluxC widget.
  String? inputcontrFluxCValue;
  FormFieldController<String>? inputcontrFluxCValueController;
  // State field(s) for inputdatbitC widget.
  String? inputdatbitCValue;
  FormFieldController<String>? inputdatbitCValueController;
  // State field(s) for inputssidC widget.
  FocusNode? inputssidCFocusNode;
  TextEditingController? inputssidCTextController;
  String? Function(BuildContext, String?)? inputssidCTextControllerValidator;
  // State field(s) for inputsenwiC widget.
  FocusNode? inputsenwiCFocusNode;
  TextEditingController? inputsenwiCTextController;
  String? Function(BuildContext, String?)? inputsenwiCTextControllerValidator;
  // State field(s) for inputhostNtpC widget.
  FocusNode? inputhostNtpCFocusNode;
  TextEditingController? inputhostNtpCTextController;
  String? Function(BuildContext, String?)? inputhostNtpCTextControllerValidator;
  // State field(s) for inputportNtpC widget.
  FocusNode? inputportNtpCFocusNode;
  TextEditingController? inputportNtpCTextController;
  String? Function(BuildContext, String?)? inputportNtpCTextControllerValidator;
  // State field(s) for inputmtpntC widget.
  FocusNode? inputmtpntCFocusNode;
  TextEditingController? inputmtpntCTextController;
  String? Function(BuildContext, String?)? inputmtpntCTextControllerValidator;
  // State field(s) for inputuserC widget.
  FocusNode? inputuserCFocusNode;
  TextEditingController? inputuserCTextController;
  String? Function(BuildContext, String?)? inputuserCTextControllerValidator;
  // State field(s) for inputsenC widget.
  FocusNode? inputsenCFocusNode;
  TextEditingController? inputsenCTextController;
  String? Function(BuildContext, String?)? inputsenCTextControllerValidator;
  // State field(s) for inputsendLatLong widget.
  String? inputsendLatLongValue;
  FormFieldController<String>? inputsendLatLongValueController;
  // State field(s) for inputlat widget.
  FocusNode? inputlatFocusNode;
  TextEditingController? inputlatTextController;
  String? Function(BuildContext, String?)? inputlatTextControllerValidator;
  // State field(s) for inputlon widget.
  FocusNode? inputlonFocusNode;
  TextEditingController? inputlonTextController;
  String? Function(BuildContext, String?)? inputlonTextControllerValidator;
  // State field(s) for inputalt widget.
  FocusNode? inputaltFocusNode;
  TextEditingController? inputaltTextController;
  String? Function(BuildContext, String?)? inputaltTextControllerValidator;
  // State field(s) for inputpre widget.
  FocusNode? inputpreFocusNode;
  TextEditingController? inputpreTextController;
  String? Function(BuildContext, String?)? inputpreTextControllerValidator;
  // State field(s) for inpututc widget.
  FocusNode? inpututcFocusNode;
  TextEditingController? inpututcTextController;
  String? Function(BuildContext, String?)? inpututcTextControllerValidator;
  // Stores action output result for [Backend Call - API (SendCliente)] action in Button widget.
  ApiCallResponse? sendCliente;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    inputssidCFocusNode?.dispose();
    inputssidCTextController?.dispose();

    inputsenwiCFocusNode?.dispose();
    inputsenwiCTextController?.dispose();

    inputhostNtpCFocusNode?.dispose();
    inputhostNtpCTextController?.dispose();

    inputportNtpCFocusNode?.dispose();
    inputportNtpCTextController?.dispose();

    inputmtpntCFocusNode?.dispose();
    inputmtpntCTextController?.dispose();

    inputuserCFocusNode?.dispose();
    inputuserCTextController?.dispose();

    inputsenCFocusNode?.dispose();
    inputsenCTextController?.dispose();

    inputlatFocusNode?.dispose();
    inputlatTextController?.dispose();

    inputlonFocusNode?.dispose();
    inputlonTextController?.dispose();

    inputaltFocusNode?.dispose();
    inputaltTextController?.dispose();

    inputpreFocusNode?.dispose();
    inputpreTextController?.dispose();

    inpututcFocusNode?.dispose();
    inpututcTextController?.dispose();
  }
}
