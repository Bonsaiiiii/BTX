import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/menu/options/options_widget.dart';
import 'modo_cliente_wifi_widget.dart' show ModoClienteWifiWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ModoClienteWifiModel extends FlutterFlowModel<ModoClienteWifiWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for inputssidC widget.
  FocusNode? inputssidCFocusNode;
  TextEditingController? inputssidCTextController;
  String? Function(BuildContext, String?)? inputssidCTextControllerValidator;
  // State field(s) for inputsenwiC widget.
  FocusNode? inputsenwiCFocusNode;
  TextEditingController? inputsenwiCTextController;
  String? Function(BuildContext, String?)? inputsenwiCTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    inputssidCFocusNode?.dispose();
    inputssidCTextController?.dispose();

    inputsenwiCFocusNode?.dispose();
    inputsenwiCTextController?.dispose();
  }
}
