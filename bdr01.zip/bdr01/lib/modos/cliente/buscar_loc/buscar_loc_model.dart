import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'buscar_loc_widget.dart' show BuscarLocWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class BuscarLocModel extends FlutterFlowModel<BuscarLocWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for inputsendLatLong widget.
  String? inputsendLatLongValue;
  FormFieldController<String>? inputsendLatLongValueController;
  // State field(s) for inputlat widget.
  FocusNode? inputlatFocusNode;
  TextEditingController? inputlatTextController;
  String? Function(BuildContext, String?)? inputlatTextControllerValidator;
  // State field(s) for inputlon widget.
  FocusNode? inputlonFocusNode;
  TextEditingController? inputlonTextController;
  String? Function(BuildContext, String?)? inputlonTextControllerValidator;
  // State field(s) for inputalt widget.
  FocusNode? inputaltFocusNode;
  TextEditingController? inputaltTextController;
  String? Function(BuildContext, String?)? inputaltTextControllerValidator;
  // State field(s) for inputpre widget.
  FocusNode? inputpreFocusNode;
  TextEditingController? inputpreTextController;
  String? Function(BuildContext, String?)? inputpreTextControllerValidator;
  // State field(s) for inpututc widget.
  FocusNode? inpututcFocusNode;
  TextEditingController? inpututcTextController;
  String? Function(BuildContext, String?)? inpututcTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    inputlatFocusNode?.dispose();
    inputlatTextController?.dispose();

    inputlonFocusNode?.dispose();
    inputlonTextController?.dispose();

    inputaltFocusNode?.dispose();
    inputaltTextController?.dispose();

    inputpreFocusNode?.dispose();
    inputpreTextController?.dispose();

    inpututcFocusNode?.dispose();
    inpututcTextController?.dispose();
  }
}
