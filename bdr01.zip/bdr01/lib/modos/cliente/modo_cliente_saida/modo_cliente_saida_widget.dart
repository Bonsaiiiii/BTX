import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/menu/options/options_widget.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'modo_cliente_saida_model.dart';
export 'modo_cliente_saida_model.dart';

class ModoClienteSaidaWidget extends StatefulWidget {
  const ModoClienteSaidaWidget({
    super.key,
    String? aa,
    String? preinputsaidaTenC1,
    String? cliente,
  })  : this.aa = aa ?? 'aa',
        this.preinputsaidaTenC1 = preinputsaidaTenC1 ?? 'tumbala',
        this.cliente = cliente ?? 'Cliente';

  final String aa;
  final String preinputsaidaTenC1;
  final String cliente;

  @override
  State<ModoClienteSaidaWidget> createState() => _ModoClienteSaidaWidgetState();
}

class _ModoClienteSaidaWidgetState extends State<ModoClienteSaidaWidget> {
  late ModoClienteSaidaModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ModoClienteSaidaModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<ApiCallResponse>(
      future: RequestCall.call(
        saidaTenC: '\$.portaSupC[0].saidaTenC',
        baudrateC: '\$.portaSupC[0].baudrateC',
        paridadeC: '\$.portaSupC[0].paridadeC',
        bitsParaC: '\$.portaSupC[0].bitsParaC',
        contrFluxC: '\$.portaSupC[0].contrFluxC',
        datbitC: '\$.portaSupC[0].datbitC',
        ssidC: '\$.wifiC[0].ssidC',
        senwiC: '\$.wifiC[0].senwiC',
        hostNtpC: '\$.ntripConfC[0].hostNtpC',
        portNtpC: '\$.ntripConfC[0].portNtpC',
        mtpntC: '\$.ntripConfC[0].mtpntC',
        userC: '\$.ntripConfC[0].userC',
        senC: '\$.ntripConfC[0].senC',
        sendLatLong: '\$.latLong[0].sendLatLong',
        lat: '\$.latLong[0].lat',
        lon: '\$.latLong[0].lon',
        alt: '\$.latLong[0].alt',
        pre: '\$.latLong[0].pre',
        utc: '\$.latLong[0].utc',
        modo: widget!.cliente,
      ),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: Colors.white,
            body: Center(
              child: SizedBox(
                width: 50.0,
                height: 50.0,
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(
                    FlutterFlowTheme.of(context).primary,
                  ),
                ),
              ),
            ),
          );
        }
        final modoClienteSaidaRequestResponse = snapshot.data!;

        return GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Scaffold(
            key: scaffoldKey,
            backgroundColor: Colors.white,
            body: SafeArea(
              top: true,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Container(
                      width: double.infinity,
                      height: 60.0,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(0.0),
                          bottomRight: Radius.circular(0.0),
                          topLeft: Radius.circular(0.0),
                          topRight: Radius.circular(0.0),
                        ),
                        border: Border.all(
                          color: Color(0xFFD5D3E3),
                          width: 2.0,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Container(
                            width: 150.0,
                            height: 100.0,
                            decoration: BoxDecoration(),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Align(
                                  alignment: AlignmentDirectional(-1.0, 0.0),
                                  child: FFButtonWidget(
                                    onPressed: () async {
                                      context.safePop();
                                    },
                                    text: '',
                                    icon: Icon(
                                      Icons.arrow_back_rounded,
                                      color: Colors.black,
                                      size: 23.0,
                                    ),
                                    options: FFButtonOptions(
                                      width: 32.0,
                                      height: 30.0,
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0.0, 0.0, 0.0, 0.0),
                                      iconPadding:
                                          EdgeInsetsDirectional.fromSTEB(
                                              0.0, 0.0, 0.0, 0.0),
                                      color: Colors.white,
                                      textStyle: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .override(
                                            fontFamily: 'Inter Tight',
                                            color: Colors.white,
                                            letterSpacing: 0.0,
                                          ),
                                      elevation: 0.0,
                                      borderRadius: BorderRadius.circular(8.0),
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: AlignmentDirectional(-1.0, 0.0),
                                  child: FFButtonWidget(
                                    onPressed: () async {
                                      context.pushNamed('HomePage');
                                    },
                                    text: '',
                                    icon: Icon(
                                      Icons.home_rounded,
                                      color: Colors.black,
                                      size: 23.0,
                                    ),
                                    options: FFButtonOptions(
                                      width: 32.0,
                                      height: 30.0,
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0.0, 0.0, 0.0, 0.0),
                                      iconPadding:
                                          EdgeInsetsDirectional.fromSTEB(
                                              0.0, 0.0, 0.0, 0.0),
                                      color: Colors.white,
                                      textStyle: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .override(
                                            fontFamily: 'Inter Tight',
                                            color: Colors.white,
                                            letterSpacing: 0.0,
                                          ),
                                      elevation: 0.0,
                                      borderRadius: BorderRadius.circular(8.0),
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: AlignmentDirectional(-1.0, 0.0),
                                  child: Text(
                                    FFLocalizations.of(context).getText(
                                      'l9t5du7l' /* BDR_01 */,
                                    ),
                                    style: FlutterFlowTheme.of(context)
                                        .titleLarge
                                        .override(
                                          fontFamily: 'Montserrat',
                                          color: Color(0xFF14181B),
                                          letterSpacing: 0.0,
                                        ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Align(
                            alignment: AlignmentDirectional(1.0, 0.0),
                            child: FFButtonWidget(
                              onPressed: () async {
                                await showModalBottomSheet(
                                  isScrollControlled: true,
                                  backgroundColor: Colors.transparent,
                                  enableDrag: false,
                                  context: context,
                                  builder: (context) {
                                    return GestureDetector(
                                      onTap: () =>
                                          FocusScope.of(context).unfocus(),
                                      child: Padding(
                                        padding:
                                            MediaQuery.viewInsetsOf(context),
                                        child: OptionsWidget(),
                                      ),
                                    );
                                  },
                                ).then((value) => safeSetState(() {}));
                              },
                              text: '',
                              icon: Icon(
                                Icons.menu_sharp,
                                color: Colors.black,
                                size: 23.0,
                              ),
                              options: FFButtonOptions(
                                width: 32.0,
                                height: 30.0,
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 0.0, 0.0, 0.0),
                                iconPadding: EdgeInsets.all(0.0),
                                color: Colors.white,
                                textStyle: FlutterFlowTheme.of(context)
                                    .titleSmall
                                    .override(
                                      fontFamily: 'Inter Tight',
                                      color: Colors.white,
                                      letterSpacing: 0.0,
                                    ),
                                elevation: 0.0,
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                            ),
                          ),
                        ].divide(SizedBox(width: 200.0)),
                      ),
                    ),
                    Container(
                      width: double.infinity,
                      height: 604.0,
                      decoration: BoxDecoration(),
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Text(
                            FFLocalizations.of(context).getText(
                              '6jznvzaq' /* Configurações Cliente */,
                            ),
                            style: FlutterFlowTheme.of(context)
                                .headlineLarge
                                .override(
                                  fontFamily: 'Montserrat',
                                  color: Color(0xFF14181B),
                                  letterSpacing: 0.0,
                                ),
                          ),
                          Align(
                            alignment: AlignmentDirectional(0.0, 0.0),
                            child: Text(
                              FFLocalizations.of(context).getText(
                                'xi0ccxgp' /* Upper Port Settings (Serial) */,
                              ),
                              style: FlutterFlowTheme.of(context)
                                  .bodyLarge
                                  .override(
                                    fontFamily: 'Inter',
                                    color: Color(0xFF14181B),
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ),
                          Container(
                            width: 360.0,
                            height: 402.0,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(12.0),
                              border: Border.all(
                                color: Color(0xFF36454F),
                              ),
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Container(
                                  width: 639.0,
                                  height: 55.0,
                                  decoration: BoxDecoration(),
                                  child: Align(
                                    alignment: AlignmentDirectional(0.0, 0.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Align(
                                          alignment:
                                              AlignmentDirectional(0.0, -1.0),
                                          child: Container(
                                            width: 125.0,
                                            height: 52.0,
                                            decoration: BoxDecoration(),
                                            alignment:
                                                AlignmentDirectional(0.0, -1.0),
                                            child: Align(
                                              alignment: AlignmentDirectional(
                                                  0.0, 0.0),
                                              child: Text(
                                                FFLocalizations.of(context)
                                                    .getText(
                                                  'k6nsjp9z' /* Output Voltage:
(Powers the G... */
                                                  ,
                                                ),
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily: 'Inter',
                                                          color:
                                                              Color(0xFF14181B),
                                                          letterSpacing: 0.0,
                                                        ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment:
                                              AlignmentDirectional(0.0, -1.0),
                                          child: FlutterFlowDropDown<String>(
                                            controller: _model
                                                    .inputsaidaTenCValueController ??=
                                                FormFieldController<String>(
                                              _model.inputsaidaTenCValue ??=
                                                  RequestCall.saidaTenC(
                                                modoClienteSaidaRequestResponse
                                                    .jsonBody,
                                              ).toString(),
                                            ),
                                            options: [
                                              FFLocalizations.of(context)
                                                  .getText(
                                                'xlitqobk' /* 5V */,
                                              ),
                                              FFLocalizations.of(context)
                                                  .getText(
                                                'y8lvx72t' /* 9V */,
                                              ),
                                              FFLocalizations.of(context)
                                                  .getText(
                                                'a8twqog3' /* 12V */,
                                              ),
                                              FFLocalizations.of(context)
                                                  .getText(
                                                'v064kslm' /* 15V */,
                                              ),
                                              FFLocalizations.of(context)
                                                  .getText(
                                                '61v3xhs7' /* 20V */,
                                              )
                                            ],
                                            onChanged: (val) => safeSetState(
                                                () => _model
                                                    .inputsaidaTenCValue = val),
                                            width: 200.0,
                                            height: 40.0,
                                            textStyle:
                                                FlutterFlowTheme.of(context)
                                                    .bodyMedium
                                                    .override(
                                                      fontFamily: 'Inter',
                                                      letterSpacing: 0.0,
                                                    ),
                                            hintText: RequestCall.saidaTenC(
                                              modoClienteSaidaRequestResponse
                                                  .jsonBody,
                                            ).toString(),
                                            icon: Icon(
                                              Icons.keyboard_arrow_down_rounded,
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .secondaryText,
                                              size: 24.0,
                                            ),
                                            fillColor:
                                                FlutterFlowTheme.of(context)
                                                    .secondaryBackground,
                                            elevation: 2.0,
                                            borderColor: Colors.transparent,
                                            borderWidth: 0.0,
                                            borderRadius: 8.0,
                                            margin:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    12.0, 0.0, 12.0, 0.0),
                                            hidesUnderline: true,
                                            isOverButton: false,
                                            isSearchable: false,
                                            isMultiSelect: false,
                                          ),
                                        ),
                                      ]
                                          .divide(SizedBox(width: 5.0))
                                          .addToEnd(SizedBox(width: 20.0)),
                                    ),
                                  ),
                                ),
                                Container(
                                  width: 639.0,
                                  height: 55.0,
                                  decoration: BoxDecoration(),
                                  child: Align(
                                    alignment: AlignmentDirectional(0.0, 0.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Align(
                                          alignment:
                                              AlignmentDirectional(0.0, -1.0),
                                          child: Container(
                                            width: 100.0,
                                            height: 40.0,
                                            decoration: BoxDecoration(),
                                            alignment:
                                                AlignmentDirectional(0.0, -1.0),
                                            child: Align(
                                              alignment: AlignmentDirectional(
                                                  0.0, 0.0),
                                              child: Text(
                                                FFLocalizations.of(context)
                                                    .getText(
                                                  'stsl8s4k' /* Baudrate: */,
                                                ),
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily: 'Inter',
                                                          color:
                                                              Color(0xFF14181B),
                                                          letterSpacing: 0.0,
                                                        ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment:
                                              AlignmentDirectional(0.0, -1.0),
                                          child: FlutterFlowDropDown<String>(
                                            controller: _model
                                                    .inputbaudrateCValueController ??=
                                                FormFieldController<String>(
                                              _model.inputbaudrateCValue ??=
                                                  RequestCall.baudrateC(
                                                modoClienteSaidaRequestResponse
                                                    .jsonBody,
                                              ).toString(),
                                            ),
                                            options: [
                                              FFLocalizations.of(context)
                                                  .getText(
                                                'go1i2gbd' /* 9600 */,
                                              ),
                                              FFLocalizations.of(context)
                                                  .getText(
                                                'vj1x0xfs' /* 19200 */,
                                              ),
                                              FFLocalizations.of(context)
                                                  .getText(
                                                'w0w736e1' /* 38400 */,
                                              ),
                                              FFLocalizations.of(context)
                                                  .getText(
                                                'c4oqtgh4' /* 57600 */,
                                              ),
                                              FFLocalizations.of(context)
                                                  .getText(
                                                '3z0qxg7e' /* 115200 */,
                                              )
                                            ],
                                            onChanged: (val) => safeSetState(
                                                () => _model
                                                    .inputbaudrateCValue = val),
                                            width: 200.0,
                                            height: 40.0,
                                            textStyle:
                                                FlutterFlowTheme.of(context)
                                                    .bodyMedium
                                                    .override(
                                                      fontFamily: 'Inter',
                                                      letterSpacing: 0.0,
                                                    ),
                                            hintText: RequestCall.baudrateC(
                                              modoClienteSaidaRequestResponse
                                                  .jsonBody,
                                            ).toString(),
                                            icon: Icon(
                                              Icons.keyboard_arrow_down_rounded,
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .secondaryText,
                                              size: 24.0,
                                            ),
                                            fillColor:
                                                FlutterFlowTheme.of(context)
                                                    .secondaryBackground,
                                            elevation: 2.0,
                                            borderColor: Colors.transparent,
                                            borderWidth: 0.0,
                                            borderRadius: 8.0,
                                            margin:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    12.0, 0.0, 12.0, 0.0),
                                            hidesUnderline: true,
                                            isOverButton: false,
                                            isSearchable: false,
                                            isMultiSelect: false,
                                          ),
                                        ),
                                      ]
                                          .divide(SizedBox(width: 10.0))
                                          .addToStart(SizedBox(width: 20.0))
                                          .addToEnd(SizedBox(width: 20.0)),
                                    ),
                                  ),
                                ),
                                Container(
                                  width: 639.0,
                                  height: 55.0,
                                  decoration: BoxDecoration(),
                                  child: Align(
                                    alignment: AlignmentDirectional(0.0, -1.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Align(
                                          alignment:
                                              AlignmentDirectional(0.0, -1.0),
                                          child: Container(
                                            width: 100.0,
                                            height: 40.0,
                                            decoration: BoxDecoration(),
                                            alignment:
                                                AlignmentDirectional(0.0, -1.0),
                                            child: Align(
                                              alignment: AlignmentDirectional(
                                                  0.0, 0.0),
                                              child: Text(
                                                FFLocalizations.of(context)
                                                    .getText(
                                                  '251j2dfu' /* Paridade: */,
                                                ),
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily: 'Inter',
                                                          color:
                                                              Color(0xFF14181B),
                                                          letterSpacing: 0.0,
                                                        ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment:
                                              AlignmentDirectional(0.0, -1.0),
                                          child: FlutterFlowDropDown<String>(
                                            controller: _model
                                                    .inputparidadeCValueController ??=
                                                FormFieldController<String>(
                                              _model.inputparidadeCValue ??=
                                                  RequestCall.paridadeC(
                                                modoClienteSaidaRequestResponse
                                                    .jsonBody,
                                              ).toString(),
                                            ),
                                            options: [
                                              FFLocalizations.of(context)
                                                  .getText(
                                                'kl7mb0kb' /* None */,
                                              ),
                                              FFLocalizations.of(context)
                                                  .getText(
                                                '55bkp6wh' /* Even */,
                                              ),
                                              FFLocalizations.of(context)
                                                  .getText(
                                                'r7lfrkf6' /* Odd */,
                                              ),
                                              '',
                                              ''
                                            ],
                                            onChanged: (val) => safeSetState(
                                                () => _model
                                                    .inputparidadeCValue = val),
                                            width: 200.0,
                                            height: 40.0,
                                            textStyle:
                                                FlutterFlowTheme.of(context)
                                                    .bodyMedium
                                                    .override(
                                                      fontFamily: 'Inter',
                                                      letterSpacing: 0.0,
                                                    ),
                                            hintText: RequestCall.paridadeC(
                                              modoClienteSaidaRequestResponse
                                                  .jsonBody,
                                            ).toString(),
                                            icon: Icon(
                                              Icons.keyboard_arrow_down_rounded,
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .secondaryText,
                                              size: 24.0,
                                            ),
                                            fillColor:
                                                FlutterFlowTheme.of(context)
                                                    .secondaryBackground,
                                            elevation: 2.0,
                                            borderColor: Colors.transparent,
                                            borderWidth: 0.0,
                                            borderRadius: 8.0,
                                            margin:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    12.0, 0.0, 12.0, 0.0),
                                            hidesUnderline: true,
                                            isOverButton: false,
                                            isSearchable: false,
                                            isMultiSelect: false,
                                          ),
                                        ),
                                      ]
                                          .divide(SizedBox(width: 10.0))
                                          .addToStart(SizedBox(width: 20.0))
                                          .addToEnd(SizedBox(width: 20.0)),
                                    ),
                                  ),
                                ),
                                Container(
                                  width: 639.0,
                                  height: 55.0,
                                  decoration: BoxDecoration(),
                                  child: Align(
                                    alignment: AlignmentDirectional(0.0, 0.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Align(
                                          alignment:
                                              AlignmentDirectional(0.0, -1.0),
                                          child: Container(
                                            width: 100.0,
                                            height: 40.0,
                                            decoration: BoxDecoration(),
                                            alignment:
                                                AlignmentDirectional(0.0, -1.0),
                                            child: Align(
                                              alignment: AlignmentDirectional(
                                                  0.0, 0.0),
                                              child: Text(
                                                FFLocalizations.of(context)
                                                    .getText(
                                                  'dbqws6r5' /* Bits de Parada: */,
                                                ),
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily: 'Inter',
                                                          color:
                                                              Color(0xFF14181B),
                                                          letterSpacing: 0.0,
                                                        ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment:
                                              AlignmentDirectional(0.0, -1.0),
                                          child: FlutterFlowDropDown<String>(
                                            controller: _model
                                                    .inputbitsParaCValueController ??=
                                                FormFieldController<String>(
                                              _model.inputbitsParaCValue ??=
                                                  RequestCall.bitsParaC(
                                                modoClienteSaidaRequestResponse
                                                    .jsonBody,
                                              ).toString(),
                                            ),
                                            options: [
                                              FFLocalizations.of(context)
                                                  .getText(
                                                'oatweo1i' /* 1 */,
                                              ),
                                              FFLocalizations.of(context)
                                                  .getText(
                                                'pds3mgpg' /* 1.5 */,
                                              ),
                                              FFLocalizations.of(context)
                                                  .getText(
                                                'fis95yyk' /* 2 */,
                                              ),
                                              FFLocalizations.of(context)
                                                  .getText(
                                                'houvtv56' /* 3 */,
                                              )
                                            ],
                                            onChanged: (val) => safeSetState(
                                                () => _model
                                                    .inputbitsParaCValue = val),
                                            width: 200.0,
                                            height: 40.0,
                                            textStyle:
                                                FlutterFlowTheme.of(context)
                                                    .bodyMedium
                                                    .override(
                                                      fontFamily: 'Inter',
                                                      letterSpacing: 0.0,
                                                    ),
                                            hintText: RequestCall.bitsParaC(
                                              modoClienteSaidaRequestResponse
                                                  .jsonBody,
                                            ).toString(),
                                            icon: Icon(
                                              Icons.keyboard_arrow_down_rounded,
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .secondaryText,
                                              size: 24.0,
                                            ),
                                            fillColor:
                                                FlutterFlowTheme.of(context)
                                                    .secondaryBackground,
                                            elevation: 2.0,
                                            borderColor: Colors.transparent,
                                            borderWidth: 0.0,
                                            borderRadius: 8.0,
                                            margin:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    12.0, 0.0, 12.0, 0.0),
                                            hidesUnderline: true,
                                            isOverButton: false,
                                            isSearchable: false,
                                            isMultiSelect: false,
                                          ),
                                        ),
                                      ]
                                          .divide(SizedBox(width: 10.0))
                                          .addToStart(SizedBox(width: 20.0))
                                          .addToEnd(SizedBox(width: 20.0)),
                                    ),
                                  ),
                                ),
                                Container(
                                  width: 639.0,
                                  height: 55.0,
                                  decoration: BoxDecoration(),
                                  child: Align(
                                    alignment: AlignmentDirectional(0.0, 0.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Align(
                                          alignment:
                                              AlignmentDirectional(0.0, -1.0),
                                          child: Container(
                                            width: 100.0,
                                            height: 40.0,
                                            decoration: BoxDecoration(),
                                            alignment:
                                                AlignmentDirectional(0.0, -1.0),
                                            child: Align(
                                              alignment: AlignmentDirectional(
                                                  0.0, 0.0),
                                              child: Text(
                                                FFLocalizations.of(context)
                                                    .getText(
                                                  'otvgrjvq' /* Flux Control: */,
                                                ),
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily: 'Inter',
                                                          color:
                                                              Color(0xFF14181B),
                                                          letterSpacing: 0.0,
                                                        ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment:
                                              AlignmentDirectional(0.0, -1.0),
                                          child: FlutterFlowDropDown<String>(
                                            controller: _model
                                                    .inputcontrFluxCValueController ??=
                                                FormFieldController<String>(
                                              _model.inputcontrFluxCValue ??=
                                                  RequestCall.contrFluxC(
                                                modoClienteSaidaRequestResponse
                                                    .jsonBody,
                                              ).toString(),
                                            ),
                                            options: [
                                              FFLocalizations.of(context)
                                                  .getText(
                                                '9oe7jwxb' /* Option 1 */,
                                              ),
                                              FFLocalizations.of(context)
                                                  .getText(
                                                'nsbzcv1y' /* Option 2 */,
                                              ),
                                              FFLocalizations.of(context)
                                                  .getText(
                                                '6zwur787' /* Option 3 */,
                                              )
                                            ],
                                            onChanged: (val) => safeSetState(
                                                () => _model
                                                        .inputcontrFluxCValue =
                                                    val),
                                            width: 200.0,
                                            height: 40.0,
                                            textStyle:
                                                FlutterFlowTheme.of(context)
                                                    .bodyMedium
                                                    .override(
                                                      fontFamily: 'Inter',
                                                      letterSpacing: 0.0,
                                                    ),
                                            hintText: RequestCall.contrFluxC(
                                              modoClienteSaidaRequestResponse
                                                  .jsonBody,
                                            ).toString(),
                                            icon: Icon(
                                              Icons.keyboard_arrow_down_rounded,
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .secondaryText,
                                              size: 24.0,
                                            ),
                                            fillColor:
                                                FlutterFlowTheme.of(context)
                                                    .secondaryBackground,
                                            elevation: 2.0,
                                            borderColor: Colors.transparent,
                                            borderWidth: 0.0,
                                            borderRadius: 8.0,
                                            margin:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    12.0, 0.0, 12.0, 0.0),
                                            hidesUnderline: true,
                                            isOverButton: false,
                                            isSearchable: false,
                                            isMultiSelect: false,
                                          ),
                                        ),
                                      ]
                                          .divide(SizedBox(width: 10.0))
                                          .addToStart(SizedBox(width: 20.0))
                                          .addToEnd(SizedBox(width: 20.0)),
                                    ),
                                  ),
                                ),
                                Container(
                                  width: 639.0,
                                  height: 55.0,
                                  decoration: BoxDecoration(),
                                  child: Align(
                                    alignment: AlignmentDirectional(0.0, 0.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Align(
                                          alignment:
                                              AlignmentDirectional(0.0, -1.0),
                                          child: Container(
                                            width: 100.0,
                                            height: 40.0,
                                            decoration: BoxDecoration(),
                                            alignment:
                                                AlignmentDirectional(0.0, -1.0),
                                            child: Align(
                                              alignment: AlignmentDirectional(
                                                  0.0, 0.0),
                                              child: Text(
                                                FFLocalizations.of(context)
                                                    .getText(
                                                  'c9t9o141' /* Databits: */,
                                                ),
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily: 'Inter',
                                                          color:
                                                              Color(0xFF14181B),
                                                          letterSpacing: 0.0,
                                                        ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment:
                                              AlignmentDirectional(0.0, -1.0),
                                          child: FlutterFlowDropDown<String>(
                                            controller: _model
                                                    .inputdatbitCValueController ??=
                                                FormFieldController<String>(
                                              _model.inputdatbitCValue ??=
                                                  RequestCall.datbitC(
                                                modoClienteSaidaRequestResponse
                                                    .jsonBody,
                                              ).toString(),
                                            ),
                                            options: [
                                              FFLocalizations.of(context)
                                                  .getText(
                                                'rdprecgc' /* 5 */,
                                              ),
                                              FFLocalizations.of(context)
                                                  .getText(
                                                'gprtm9qj' /* 6 */,
                                              ),
                                              FFLocalizations.of(context)
                                                  .getText(
                                                'h9qv7lyz' /* 7 */,
                                              ),
                                              FFLocalizations.of(context)
                                                  .getText(
                                                '9jrna0p7' /* 8 */,
                                              )
                                            ],
                                            onChanged: (val) => safeSetState(
                                                () => _model.inputdatbitCValue =
                                                    val),
                                            width: 200.0,
                                            height: 40.0,
                                            textStyle:
                                                FlutterFlowTheme.of(context)
                                                    .bodyMedium
                                                    .override(
                                                      fontFamily: 'Inter',
                                                      letterSpacing: 0.0,
                                                    ),
                                            hintText: RequestCall.datbitC(
                                              modoClienteSaidaRequestResponse
                                                  .jsonBody,
                                            ).toString(),
                                            icon: Icon(
                                              Icons.keyboard_arrow_down_rounded,
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .secondaryText,
                                              size: 24.0,
                                            ),
                                            fillColor:
                                                FlutterFlowTheme.of(context)
                                                    .secondaryBackground,
                                            elevation: 2.0,
                                            borderColor: Colors.transparent,
                                            borderWidth: 0.0,
                                            borderRadius: 8.0,
                                            margin:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    12.0, 0.0, 12.0, 0.0),
                                            hidesUnderline: true,
                                            isOverButton: false,
                                            isSearchable: false,
                                            isMultiSelect: false,
                                          ),
                                        ),
                                      ]
                                          .divide(SizedBox(width: 10.0))
                                          .addToStart(SizedBox(width: 20.0))
                                          .addToEnd(SizedBox(width: 20.0)),
                                    ),
                                  ),
                                ),
                              ]
                                  .divide(SizedBox(height: 10.0))
                                  .around(SizedBox(height: 10.0)),
                            ),
                          ),
                          FFButtonWidget(
                            onPressed: () {
                              print('Button pressed ...');
                            },
                            text: FFLocalizations.of(context).getText(
                              '9lw7pn82' /* Test Configuration */,
                            ),
                            options: FFButtonOptions(
                              height: 40.0,
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  16.0, 0.0, 16.0, 0.0),
                              iconPadding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 0.0),
                              color: Color(0xFFE0E3E7),
                              textStyle: FlutterFlowTheme.of(context)
                                  .titleSmall
                                  .override(
                                    fontFamily: 'Montserrat',
                                    color: Color(0xFF14181B),
                                    letterSpacing: 0.0,
                                  ),
                              elevation: 0.0,
                              borderSide: BorderSide(
                                color: Color(0xFFEBEAF4),
                                width: 2.0,
                              ),
                              borderRadius: BorderRadius.circular(8.0),
                            ),
                          ),
                          FFButtonWidget(
                            onPressed: () async {
                              context.pushNamed('ModoClienteSalvar');
                            },
                            text: FFLocalizations.of(context).getText(
                              'n03mxxuh' /* Next page */,
                            ),
                            options: FFButtonOptions(
                              height: 40.0,
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  16.0, 0.0, 16.0, 0.0),
                              iconPadding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 0.0),
                              color: Color(0xFFE0E3E7),
                              textStyle: FlutterFlowTheme.of(context)
                                  .titleSmall
                                  .override(
                                    fontFamily: 'Montserrat',
                                    color: Color(0xFF14181B),
                                    letterSpacing: 0.0,
                                  ),
                              elevation: 0.0,
                              borderSide: BorderSide(
                                color: Color(0xFFEBEAF4),
                                width: 2.0,
                              ),
                              borderRadius: BorderRadius.circular(8.0),
                            ),
                          ),
                        ].divide(SizedBox(height: 10.0)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
