import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/menu/options/options_widget.dart';
import 'modo_cliente_saida_widget.dart' show ModoClienteSaidaWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ModoClienteSaidaModel extends FlutterFlowModel<ModoClienteSaidaWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for inputsaidaTenC widget.
  String? inputsaidaTenCValue;
  FormFieldController<String>? inputsaidaTenCValueController;
  // State field(s) for inputbaudrateC widget.
  String? inputbaudrateCValue;
  FormFieldController<String>? inputbaudrateCValueController;
  // State field(s) for inputparidadeC widget.
  String? inputparidadeCValue;
  FormFieldController<String>? inputparidadeCValueController;
  // State field(s) for inputbitsParaC widget.
  String? inputbitsParaCValue;
  FormFieldController<String>? inputbitsParaCValueController;
  // State field(s) for inputcontrFluxC widget.
  String? inputcontrFluxCValue;
  FormFieldController<String>? inputcontrFluxCValueController;
  // State field(s) for inputdatbitC widget.
  String? inputdatbitCValue;
  FormFieldController<String>? inputdatbitCValueController;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
