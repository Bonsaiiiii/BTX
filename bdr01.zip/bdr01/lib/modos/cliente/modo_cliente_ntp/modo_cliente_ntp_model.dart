import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/menu/options/options_widget.dart';
import '/modos/cliente/buscar_loc/buscar_loc_widget.dart';
import 'modo_cliente_ntp_widget.dart' show ModoClienteNtpWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ModoClienteNtpModel extends FlutterFlowModel<ModoClienteNtpWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for inputhostNtpC widget.
  FocusNode? inputhostNtpCFocusNode;
  TextEditingController? inputhostNtpCTextController;
  String? Function(BuildContext, String?)? inputhostNtpCTextControllerValidator;
  // State field(s) for inputportNtpC widget.
  FocusNode? inputportNtpCFocusNode;
  TextEditingController? inputportNtpCTextController;
  String? Function(BuildContext, String?)? inputportNtpCTextControllerValidator;
  // State field(s) for inputmtpntC widget.
  FocusNode? inputmtpntCFocusNode;
  TextEditingController? inputmtpntCTextController;
  String? Function(BuildContext, String?)? inputmtpntCTextControllerValidator;
  // State field(s) for inputuserC widget.
  FocusNode? inputuserCFocusNode;
  TextEditingController? inputuserCTextController;
  String? Function(BuildContext, String?)? inputuserCTextControllerValidator;
  // State field(s) for inputsenC widget.
  FocusNode? inputsenCFocusNode;
  TextEditingController? inputsenCTextController;
  String? Function(BuildContext, String?)? inputsenCTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    inputhostNtpCFocusNode?.dispose();
    inputhostNtpCTextController?.dispose();

    inputportNtpCFocusNode?.dispose();
    inputportNtpCTextController?.dispose();

    inputmtpntCFocusNode?.dispose();
    inputmtpntCTextController?.dispose();

    inputuserCFocusNode?.dispose();
    inputuserCTextController?.dispose();

    inputsenCFocusNode?.dispose();
    inputsenCTextController?.dispose();
  }
}
