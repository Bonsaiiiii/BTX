import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/menu/options/options_widget.dart';
import 'modo_local_wifi_widget.dart' show ModoLocalWifiWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ModoLocalWifiModel extends FlutterFlowModel<ModoLocalWifiWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for inputssidL widget.
  FocusNode? inputssidLFocusNode;
  TextEditingController? inputssidLTextController;
  String? Function(BuildContext, String?)? inputssidLTextControllerValidator;
  // State field(s) for inputsenwiL widget.
  FocusNode? inputsenwiLFocusNode;
  TextEditingController? inputsenwiLTextController;
  String? Function(BuildContext, String?)? inputsenwiLTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    inputssidLFocusNode?.dispose();
    inputssidLTextController?.dispose();

    inputsenwiLFocusNode?.dispose();
    inputsenwiLTextController?.dispose();
  }
}
