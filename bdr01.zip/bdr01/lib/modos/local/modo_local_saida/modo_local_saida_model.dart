import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/menu/options/options_widget.dart';
import 'modo_local_saida_widget.dart' show ModoLocalSaidaWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ModoLocalSaidaModel extends FlutterFlowModel<ModoLocalSaidaWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for inputSaidaTenL widget.
  String? inputSaidaTenLValue;
  FormFieldController<String>? inputSaidaTenLValueController;
  // State field(s) for inputbaudrateL widget.
  String? inputbaudrateLValue;
  FormFieldController<String>? inputbaudrateLValueController;
  // State field(s) for inputparidadeL widget.
  String? inputparidadeLValue;
  FormFieldController<String>? inputparidadeLValueController;
  // State field(s) for inputbitsParaL widget.
  String? inputbitsParaLValue;
  FormFieldController<String>? inputbitsParaLValueController;
  // State field(s) for inputcontrFluxL widget.
  String? inputcontrFluxLValue;
  FormFieldController<String>? inputcontrFluxLValueController;
  // State field(s) for inputdatbitL widget.
  String? inputdatbitLValue;
  FormFieldController<String>? inputdatbitLValueController;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
