import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/menu/options/options_widget.dart';
import 'modo_local_widget.dart' show ModoLocalWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ModoLocalModel extends FlutterFlowModel<ModoLocalWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for inputSaidaTenL widget.
  String? inputSaidaTenLValue;
  FormFieldController<String>? inputSaidaTenLValueController;
  // State field(s) for inputbaudrateL widget.
  String? inputbaudrateLValue;
  FormFieldController<String>? inputbaudrateLValueController;
  // State field(s) for inputparidadeL widget.
  String? inputparidadeLValue;
  FormFieldController<String>? inputparidadeLValueController;
  // State field(s) for inputbitsParaL widget.
  String? inputbitsParaLValue;
  FormFieldController<String>? inputbitsParaLValueController;
  // State field(s) for inputcontrFluxL widget.
  String? inputcontrFluxLValue;
  FormFieldController<String>? inputcontrFluxLValueController;
  // State field(s) for inputdatbitL widget.
  String? inputdatbitLValue;
  FormFieldController<String>? inputdatbitLValueController;
  // State field(s) for inputssidL widget.
  FocusNode? inputssidLFocusNode;
  TextEditingController? inputssidLTextController;
  String? Function(BuildContext, String?)? inputssidLTextControllerValidator;
  // State field(s) for inputsenwiL widget.
  FocusNode? inputsenwiLFocusNode;
  TextEditingController? inputsenwiLTextController;
  String? Function(BuildContext, String?)? inputsenwiLTextControllerValidator;
  // State field(s) for inputhostNtpL widget.
  FocusNode? inputhostNtpLFocusNode;
  TextEditingController? inputhostNtpLTextController;
  String? Function(BuildContext, String?)? inputhostNtpLTextControllerValidator;
  // State field(s) for inputportNtpL widget.
  FocusNode? inputportNtpLFocusNode;
  TextEditingController? inputportNtpLTextController;
  String? Function(BuildContext, String?)? inputportNtpLTextControllerValidator;
  // State field(s) for inputmtpntL widget.
  FocusNode? inputmtpntLFocusNode;
  TextEditingController? inputmtpntLTextController;
  String? Function(BuildContext, String?)? inputmtpntLTextControllerValidator;
  // State field(s) for inputuserL widget.
  FocusNode? inputuserLFocusNode;
  TextEditingController? inputuserLTextController;
  String? Function(BuildContext, String?)? inputuserLTextControllerValidator;
  // State field(s) for inputsenL widget.
  FocusNode? inputsenLFocusNode;
  TextEditingController? inputsenLTextController;
  String? Function(BuildContext, String?)? inputsenLTextControllerValidator;
  // Stores action output result for [Backend Call - API (SendLocal)] action in Button widget.
  ApiCallResponse? sendLocal;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    inputssidLFocusNode?.dispose();
    inputssidLTextController?.dispose();

    inputsenwiLFocusNode?.dispose();
    inputsenwiLTextController?.dispose();

    inputhostNtpLFocusNode?.dispose();
    inputhostNtpLTextController?.dispose();

    inputportNtpLFocusNode?.dispose();
    inputportNtpLTextController?.dispose();

    inputmtpntLFocusNode?.dispose();
    inputmtpntLTextController?.dispose();

    inputuserLFocusNode?.dispose();
    inputuserLTextController?.dispose();

    inputsenLFocusNode?.dispose();
    inputsenLTextController?.dispose();
  }
}
