import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/menu/options/options_widget.dart';
import 'modo_local_ntp_widget.dart' show ModoLocalNtpWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ModoLocalNtpModel extends FlutterFlowModel<ModoLocalNtpWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for inputhostNtpL widget.
  FocusNode? inputhostNtpLFocusNode;
  TextEditingController? inputhostNtpLTextController;
  String? Function(BuildContext, String?)? inputhostNtpLTextControllerValidator;
  // State field(s) for inputportNtpL widget.
  FocusNode? inputportNtpLFocusNode;
  TextEditingController? inputportNtpLTextController;
  String? Function(BuildContext, String?)? inputportNtpLTextControllerValidator;
  // State field(s) for inputmtpntL widget.
  FocusNode? inputmtpntLFocusNode;
  TextEditingController? inputmtpntLTextController;
  String? Function(BuildContext, String?)? inputmtpntLTextControllerValidator;
  // State field(s) for inputuserL widget.
  FocusNode? inputuserLFocusNode;
  TextEditingController? inputuserLTextController;
  String? Function(BuildContext, String?)? inputuserLTextControllerValidator;
  // State field(s) for inputsenL widget.
  FocusNode? inputsenLFocusNode;
  TextEditingController? inputsenLTextController;
  String? Function(BuildContext, String?)? inputsenLTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    inputhostNtpLFocusNode?.dispose();
    inputhostNtpLTextController?.dispose();

    inputportNtpLFocusNode?.dispose();
    inputportNtpLTextController?.dispose();

    inputmtpntLFocusNode?.dispose();
    inputmtpntLTextController?.dispose();

    inputuserLFocusNode?.dispose();
    inputuserLTextController?.dispose();

    inputsenLFocusNode?.dispose();
    inputsenLTextController?.dispose();
  }
}
