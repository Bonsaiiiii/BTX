import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/menu/options/options_widget.dart';
import 'modo_source_ntp_widget.dart' show ModoSourceNtpWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ModoSourceNtpModel extends FlutterFlowModel<ModoSourceNtpWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for inputhostNtpS widget.
  FocusNode? inputhostNtpSFocusNode;
  TextEditingController? inputhostNtpSTextController;
  String? Function(BuildContext, String?)? inputhostNtpSTextControllerValidator;
  // State field(s) for inputportNtpS widget.
  FocusNode? inputportNtpSFocusNode;
  TextEditingController? inputportNtpSTextController;
  String? Function(BuildContext, String?)? inputportNtpSTextControllerValidator;
  // State field(s) for inputmtpntS widget.
  FocusNode? inputmtpntSFocusNode;
  TextEditingController? inputmtpntSTextController;
  String? Function(BuildContext, String?)? inputmtpntSTextControllerValidator;
  // State field(s) for inputsendRev2 widget.
  String? inputsendRev2Value;
  FormFieldController<String>? inputsendRev2ValueController;
  // State field(s) for inputuserS widget.
  FocusNode? inputuserSFocusNode;
  TextEditingController? inputuserSTextController;
  String? Function(BuildContext, String?)? inputuserSTextControllerValidator;
  // State field(s) for inputsenS widget.
  FocusNode? inputsenSFocusNode;
  TextEditingController? inputsenSTextController;
  String? Function(BuildContext, String?)? inputsenSTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    inputhostNtpSFocusNode?.dispose();
    inputhostNtpSTextController?.dispose();

    inputportNtpSFocusNode?.dispose();
    inputportNtpSTextController?.dispose();

    inputmtpntSFocusNode?.dispose();
    inputmtpntSTextController?.dispose();

    inputuserSFocusNode?.dispose();
    inputuserSTextController?.dispose();

    inputsenSFocusNode?.dispose();
    inputsenSTextController?.dispose();
  }
}
