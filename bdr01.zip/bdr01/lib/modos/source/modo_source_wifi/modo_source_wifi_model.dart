import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/menu/options/options_widget.dart';
import 'modo_source_wifi_widget.dart' show ModoSourceWifiWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ModoSourceWifiModel extends FlutterFlowModel<ModoSourceWifiWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for inputssidS widget.
  FocusNode? inputssidSFocusNode;
  TextEditingController? inputssidSTextController;
  String? Function(BuildContext, String?)? inputssidSTextControllerValidator;
  // State field(s) for inputsenwiS widget.
  FocusNode? inputsenwiSFocusNode;
  TextEditingController? inputsenwiSTextController;
  String? Function(BuildContext, String?)? inputsenwiSTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    inputssidSFocusNode?.dispose();
    inputssidSTextController?.dispose();

    inputsenwiSFocusNode?.dispose();
    inputsenwiSTextController?.dispose();
  }
}
