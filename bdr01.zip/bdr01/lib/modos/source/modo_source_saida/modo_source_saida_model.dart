import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/menu/options/options_widget.dart';
import 'modo_source_saida_widget.dart' show ModoSourceSaidaWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ModoSourceSaidaModel extends FlutterFlowModel<ModoSourceSaidaWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for inputsaidaTenS widget.
  String? inputsaidaTenSValue;
  FormFieldController<String>? inputsaidaTenSValueController;
  // State field(s) for inputbaudrateS widget.
  String? inputbaudrateSValue;
  FormFieldController<String>? inputbaudrateSValueController;
  // State field(s) for inputparidadeS widget.
  String? inputparidadeSValue;
  FormFieldController<String>? inputparidadeSValueController;
  // State field(s) for inputbitsParaS widget.
  String? inputbitsParaSValue;
  FormFieldController<String>? inputbitsParaSValueController;
  // State field(s) for inputcontrFluxS widget.
  String? inputcontrFluxSValue;
  FormFieldController<String>? inputcontrFluxSValueController;
  // State field(s) for inputdatbitS widget.
  String? inputdatbitSValue;
  FormFieldController<String>? inputdatbitSValueController;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
