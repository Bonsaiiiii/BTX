import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:bdr01copy/backend/Profile/profile_database.dart';
import 'package:bdr01copy/backend/Profile/extensions.dart';
import 'package:bdr01copy/backend/Profile/task.dart';
import 'package:path/path.dart';

class TaskListTile extends StatefulWidget {
  const TaskListTile({
    super.key,
    required this.task,
  });

  final Profile task;

  @override
  State<TaskListTile> createState() => _TaskListTileState();
}

class _TaskListTileState extends State<TaskListTile> {
  bool isCompleted = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      margin: const EdgeInsets.all(8.0),
      child: Padding(
        padding: const EdgeInsets.symmetric(
          vertical: 8.0,
        ),
        child: CupertinoListTile(
          leading: Transform.scale(
            scale: 1.5,
            child: Container(
              width: 10,
              height: 10,
              decoration: const BoxDecoration(
                color: Colors.black,
                shape: BoxShape.circle,
              ),
            ),
          ),

          title: Text(
            widget.task.title,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          subtitle: Text(
            style: TextStyle(color: Colors.black),
            widget.task.mode,
            maxLines: 3,
          ),
        ),
      ),
    );
  }
}
