import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:bdr01copy/backend/Profile/profile_database.dart';
import 'package:bdr01copy/backend/Profile/extensions.dart';
import 'package:bdr01copy/backend/Profile/task.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';

final _formKey = GlobalKey<FormState>();

class AddTaskScreen3 extends StatefulWidget {
  const AddTaskScreen3({
    super.key,
    this.profile,
  });

  final Profile? profile;

  @override
  State<AddTaskScreen3> createState() => _AddTaskScreenState3();
}

class _AddTaskScreenState3 extends State<AddTaskScreen3> {
  final saidaTenSkey = GlobalKey<FormFieldState>();
  String? _selectedsaidaTenS;
  String? _selectedbaudrateS;
  String? _selectedparidadeS;
  String? _selectedbitsParaS;
  String? _selectedcontrFluxS;
  String? _selecteddatbitS;
  String? _selectedsendRev2;
  late final TextEditingController _titleController;
  late final TextEditingController _modeController;

  late final TextEditingController _saidaTenLController;
  late final TextEditingController _baudrateLController;
  late final TextEditingController _paridadeLController;
  late final TextEditingController _bitsParaLController;
  late final TextEditingController _contrFluxLController;
  late final TextEditingController _datbitLController;
  late final TextEditingController _ssidLController;
  late final TextEditingController _senwiLController;
  late final TextEditingController _hostNtpLController;
  late final TextEditingController _portNtpLController;
  late final TextEditingController _mtpntLController;
  late final TextEditingController _userLController;
  late final TextEditingController _senLController;

  late final TextEditingController _saidaTenCController;
  late final TextEditingController _baudrateCController;
  late final TextEditingController _paridadeCController;
  late final TextEditingController _bitsParaCController;
  late final TextEditingController _contrFluxCController;
  late final TextEditingController _datbitCController;
  late final TextEditingController _ssidCController;
  late final TextEditingController _senwiCController;
  late final TextEditingController _hostNtpCController;
  late final TextEditingController _portNtpCController;
  late final TextEditingController _mtpntCController;
  late final TextEditingController _userCController;
  late final TextEditingController _senCController;
  late final TextEditingController _sendLatLongController;
  late final TextEditingController _latController;
  late final TextEditingController _lonController;
  late final TextEditingController _altController;
  late final TextEditingController _preController;
  late final TextEditingController _utcController;

  late final TextEditingController _saidaTenSController;
  late final TextEditingController _baudrateSController;
  late final TextEditingController _paridadeSController;
  late final TextEditingController _bitsParaSController;
  late final TextEditingController _contrFluxSController;
  late final TextEditingController _datbitSController;
  late final TextEditingController _ssidSController;
  late final TextEditingController _senwiSController;
  late final TextEditingController _hostNtpSController;
  late final TextEditingController _portNtpSController;
  late final TextEditingController _mtpntSController;
  late final TextEditingController _sendRev2Controller;
  late final TextEditingController _userSController;
  late final TextEditingController _senSController;

  @override
  void initState() {
    _selectedsaidaTenS = '5V';
    _selectedbaudrateS = '115200';
    _selectedparidadeS = 'None';
    _selectedbitsParaS = '1';
    _selectedcontrFluxS = 'None';
    _selecteddatbitS = '8';
    _selectedsendRev2 = 'Y';
    _titleController = TextEditingController();
    _modeController = TextEditingController();

    _saidaTenLController = TextEditingController();
    _baudrateLController = TextEditingController();
    _paridadeLController = TextEditingController();
    _bitsParaLController = TextEditingController();
    _contrFluxLController = TextEditingController();
    _datbitLController = TextEditingController();
    _ssidLController = TextEditingController();
    _senwiLController = TextEditingController();
    _hostNtpLController = TextEditingController();
    _portNtpLController = TextEditingController();
    _mtpntLController = TextEditingController();
    _userLController = TextEditingController();
    _senLController = TextEditingController();

    _saidaTenCController = TextEditingController();
    _baudrateCController = TextEditingController();
    _paridadeCController = TextEditingController();
    _bitsParaCController = TextEditingController();
    _contrFluxCController = TextEditingController();
    _datbitCController = TextEditingController();
    _ssidCController = TextEditingController();
    _senwiCController = TextEditingController();
    _hostNtpCController = TextEditingController();
    _portNtpCController = TextEditingController();
    _mtpntCController = TextEditingController();
    _userCController = TextEditingController();
    _senCController = TextEditingController();
    _sendLatLongController = TextEditingController();
    _latController = TextEditingController();
    _lonController = TextEditingController();
    _altController = TextEditingController();
    _preController = TextEditingController();
    _utcController = TextEditingController();

    _saidaTenSController = TextEditingController();
    _baudrateSController = TextEditingController();
    _paridadeSController = TextEditingController();
    _bitsParaSController = TextEditingController();
    _contrFluxSController = TextEditingController();
    _datbitSController = TextEditingController();
    _ssidSController = TextEditingController();
    _senwiSController = TextEditingController();
    _hostNtpSController = TextEditingController();
    _portNtpSController = TextEditingController();
    _mtpntSController = TextEditingController();
    _sendRev2Controller = TextEditingController();
    _userSController = TextEditingController();
    _senSController = TextEditingController();
    if (widget.profile != null) {
      _titleController.text = widget.profile!.title;
      _modeController.text = widget.profile!.mode;

      _selectedsaidaTenS = widget.profile!.saidaTenS;
      _selectedbaudrateS = widget.profile!.baudrateS;
      _selectedparidadeS = widget.profile!.paridadeS;
      _selectedbitsParaS = widget.profile!.bitsParaS;
      _selectedcontrFluxS = widget.profile!.contrFluxS;
      _selecteddatbitS = widget.profile!.datbitS;
      _selectedsendRev2 = widget.profile!.sendRev2;
      _saidaTenLController.text = widget.profile!.saidaTenL;
      _baudrateLController.text = widget.profile!.baudrateL;
      _paridadeLController.text = widget.profile!.paridadeL;
      _bitsParaLController.text = widget.profile!.bitsParaL;
      _contrFluxLController.text = widget.profile!.contrFluxL;
      _datbitLController.text = widget.profile!.datbitL;
      _ssidLController.text = widget.profile!.ssidL;
      _senwiLController.text = widget.profile!.senwiL;
      _hostNtpLController.text = widget.profile!.hostNtpL;
      _portNtpLController.text = widget.profile!.portNtpL;
      _mtpntLController.text = widget.profile!.mtpntL;
      _userLController.text = widget.profile!.userL;
      _senLController.text = widget.profile!.senL;

      _saidaTenCController.text = widget.profile!.saidaTenC;
      _baudrateCController.text = widget.profile!.baudrateC;
      _paridadeCController.text = widget.profile!.paridadeC;
      _bitsParaCController.text = widget.profile!.bitsParaC;
      _contrFluxCController.text = widget.profile!.contrFluxC;
      _datbitCController.text = widget.profile!.datbitC;
      _ssidCController.text = widget.profile!.ssidC;
      _senwiCController.text = widget.profile!.senwiC;
      _hostNtpCController.text = widget.profile!.hostNtpC;
      _portNtpCController.text = widget.profile!.portNtpC;
      _mtpntCController.text = widget.profile!.mtpntC;
      _userCController.text = widget.profile!.userC;
      _senCController.text = widget.profile!.senC;
      _sendLatLongController.text = widget.profile!.sendLatLong;
      _latController.text = widget.profile!.lat;
      _lonController.text = widget.profile!.lon;
      _altController.text = widget.profile!.alt;
      _preController.text = widget.profile!.pre;
      _utcController.text = widget.profile!.utc;

      _saidaTenSController.text = widget.profile!.saidaTenS;
      _baudrateSController.text = widget.profile!.baudrateS;
      _paridadeSController.text = widget.profile!.paridadeS;
      _bitsParaSController.text = widget.profile!.bitsParaS;
      _contrFluxSController.text = widget.profile!.contrFluxS;
      _datbitSController.text = widget.profile!.datbitS;
      _ssidSController.text = widget.profile!.ssidS;
      _senwiSController.text = widget.profile!.senwiS;
      _hostNtpSController.text = widget.profile!.hostNtpS;
      _portNtpSController.text = widget.profile!.portNtpS;
      _mtpntSController.text = widget.profile!.mtpntS;
      _sendRev2Controller.text = widget.profile!.sendRev2;
      _userSController.text = widget.profile!.userS;
      _senSController.text = widget.profile!.senS;
    }
    super.initState();
  }

  @override
  void dispose() {
    _titleController.dispose();
    _modeController.dispose();

    _saidaTenLController.dispose();
    _baudrateLController.dispose();
    _paridadeLController.dispose();
    _bitsParaLController.dispose();
    _contrFluxLController.dispose();
    _datbitLController.dispose();
    _ssidLController.dispose();
    _senwiLController.dispose();
    _hostNtpLController.dispose();
    _portNtpLController.dispose();
    _mtpntLController.dispose();
    _userLController.dispose();
    _senLController.dispose();

    _saidaTenCController.dispose();
    _baudrateCController.dispose();
    _paridadeCController.dispose();
    _bitsParaCController.dispose();
    _contrFluxCController.dispose();
    _datbitCController.dispose();
    _ssidCController.dispose();
    _senwiCController.dispose();
    _hostNtpCController.dispose();
    _portNtpCController.dispose();
    _mtpntCController.dispose();
    _userCController.dispose();
    _senCController.dispose();
    _sendLatLongController.dispose();
    _latController.dispose();
    _lonController.dispose();
    _altController.dispose();
    _preController.dispose();
    _utcController.dispose();

    _saidaTenSController.dispose();
    _baudrateSController.dispose();
    _paridadeSController.dispose();
    _bitsParaSController.dispose();
    _contrFluxSController.dispose();
    _datbitSController.dispose();
    _ssidSController.dispose();
    _senwiSController.dispose();
    _hostNtpSController.dispose();
    _portNtpSController.dispose();
    _mtpntSController.dispose();
    _sendRev2Controller.dispose();
    _userSController.dispose();
    _senSController.dispose();
    super.dispose();
  }

  Future<void> addTask() async {
    final profile = Profile(
      title: _titleController.text,
      mode: _modeController.text,

      saidaTenL: _saidaTenLController.text,
      baudrateL: _baudrateLController.text,
      paridadeL: _paridadeLController.text,
      bitsParaL: _bitsParaLController.text,
      contrFluxL: _contrFluxLController.text,
      datbitL: _datbitLController.text,
      ssidL: _ssidLController.text,
      senwiL: _senwiLController.text,
      hostNtpL: _hostNtpLController.text,
      portNtpL: _portNtpLController.text,
      mtpntL: _mtpntLController.text,
      userL: _userLController.text,
      senL: _senLController.text,

      saidaTenC: _saidaTenCController.text,
      baudrateC: _baudrateCController.text,
      paridadeC: _paridadeCController.text,
      bitsParaC: _bitsParaCController.text,
      contrFluxC: _contrFluxCController.text,
      datbitC: _datbitCController.text,
      ssidC: _ssidCController.text,
      senwiC: _senwiCController.text,
      hostNtpC: _hostNtpCController.text,
      portNtpC: _portNtpCController.text,
      mtpntC: _mtpntCController.text,
      userC: _userCController.text,
      senC: _senCController.text,
      sendLatLong: _sendLatLongController.text,
      lat: _latController.text,
      lon: _lonController.text,
      alt: _altController.text,
      pre: _preController.text,
      utc: _utcController.text,

      saidaTenS: _selectedsaidaTenS!,
      baudrateS: _selectedbaudrateS!,
      paridadeS: _selectedparidadeS!,
      bitsParaS: _selectedbitsParaS!,
      contrFluxS: _selectedcontrFluxS!,
      datbitS: _selecteddatbitS!,
      ssidS: _ssidSController.text,
      senwiS: _senwiSController.text,
      hostNtpS: _hostNtpSController.text,
      portNtpS: _portNtpSController.text,
      mtpntS: _mtpntSController.text,
      sendRev2: _selectedsendRev2!,
      userS: _userSController.text,
      senS: _senSController.text,
    );

    await TasksDatabase.instance.createTask(profile);
  }

  Future<void> updateTask() async {
    final profile = widget.profile!.copy(
      title: _titleController.text,
      mode: _modeController.text,
      saidaTenS: _selectedsaidaTenS!,
      baudrateS: _selectedbaudrateS!,
      paridadeS: _selectedparidadeS!,
      bitsParaS: _selectedbitsParaS!,
      contrFluxS: _selectedcontrFluxS!,
      datbitS: _selecteddatbitS!,
      ssidS: _ssidSController.text,
      senwiS: _senwiSController.text,
      hostNtpS: _hostNtpSController.text,
      portNtpS: _portNtpSController.text,
      mtpntS: _mtpntSController.text,
      sendRev2: _selectedsendRev2!,
      userS: _userSController.text,
      senS: _senSController.text,
    );

    await TasksDatabase.instance.updateTask(profile);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Profile'),
        actions: [
          IconButton(
            onPressed: () async {
              await TasksDatabase.instance.deleteTask(widget.profile!.id!);

              Navigator.of(context).pop();
            },
            icon: const Icon(
              Icons.delete,
              color: Colors.red,
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(
          horizontal: 16.0,
          vertical: 12.0,
        ),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Visibility(
                visible: false,
              child: TextFormField(
                controller: _modeController..text = 'Source',
                decoration: const InputDecoration(
                  hintText: 'Title',
                ),
                readOnly: true,
              ),
              ),
              const SizedBox(height: 20),
              const Text(
                  style: TextStyle(color: Color(0xFFFFFFFF),
                    fontSize: 18.0, letterSpacing: 0.0,),
                  'Selecione o nome do perfil: '
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _titleController,
                decoration: const InputDecoration(
                  hintText: 'Nome do Perfil',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Insira um nome para o Perfil';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              const Divider(
                thickness: 5,
                color: Colors.white,
              ),
              const SizedBox(height: 20),
              const Text(
                  style: TextStyle(color: Color(0xFFFFFFFF),
                    fontSize: 18.0, letterSpacing: 0.0,),
                  'Selecione abaixo as configurações da entrada Serial:  '
              ),
              const SizedBox(height: 20),
              DropdownButtonFormField<String>(
                key: saidaTenSkey,
                value: _selectedsaidaTenS,
                decoration: const InputDecoration(
                  hintText: 'Select a Output',
                ),
                items: const [
                  DropdownMenuItem(
                    value: '5V',
                    child: Text('5V'),
                  ),
                  DropdownMenuItem(
                    value: '9V',
                    child: Text('9V'),
                  ),
                  DropdownMenuItem(
                    value: '12V',
                    child: Text('12V'),
                  ),
                  DropdownMenuItem(
                    value: '15V',
                    child: Text('15V'),
                  ),
                  DropdownMenuItem(
                    value: '20V',
                    child: Text('20V'),
                  ),
                ],
                onChanged: (value) {
                  setState(() {
                    _selectedsaidaTenS = value; // Update the selected title
                  });
                },
                validator: (value) {
                  if (value == null) {
                    return 'Please select a title';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              DropdownButtonFormField<String>(
                value: _selectedbaudrateS,
                decoration: const InputDecoration(
                  hintText: 'Select a baudrate',
                ),
                items: const [
                  DropdownMenuItem(
                    value: '9600',
                    child: Text('9600'),
                  ),
                  DropdownMenuItem(
                    value: '19200',
                    child: Text('19200'),
                  ),
                  DropdownMenuItem(
                    value: '38400',
                    child: Text('38400'),
                  ),
                  DropdownMenuItem(
                    value: '57600',
                    child: Text('57600'),
                  ),
                  DropdownMenuItem(
                    value: '115200',
                    child: Text('115200'),
                  ),
                ],
                onChanged: (value) {
                  setState(() {
                    _selectedbaudrateS = value; // Update the selected title
                  });
                },
                validator: (value) {
                  if (value == null) {
                    return 'Please select a title';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              DropdownButtonFormField<String>(
                value: _selectedparidadeS,
                decoration: const InputDecoration(
                  hintText: 'Select a parity',
                ),
                items: const [
                  DropdownMenuItem(
                    value: 'None',
                    child: Text('None'),
                  ),
                ],
                onChanged: (value) {
                  setState(() {
                    _selectedparidadeS = value; // Update the selected title
                  });
                },
                validator: (value) {
                  if (value == null) {
                    return 'Please select a title';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              DropdownButtonFormField<String>(
                value: _selectedbitsParaS,
                decoration: const InputDecoration(
                  hintText: 'Select a Stop Bit',
                ),
                items: const [
                  DropdownMenuItem(
                    value: '1',
                    child: Text('1'),
                  ),
                  DropdownMenuItem(
                    value: '1.5',
                    child: Text('1.5'),
                  ),
                  DropdownMenuItem(
                    value: '2',
                    child: Text('2'),
                  ),
                  DropdownMenuItem(
                    value: '3',
                    child: Text('3'),
                  ),
                ],
                onChanged: (value) {
                  setState(() {
                    _selectedbitsParaS = value; // Update the selected title
                  });
                },
                validator: (value) {
                  if (value == null) {
                    return 'Please select a title';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              DropdownButtonFormField<String>(
                value: _selectedcontrFluxS,
                decoration: const InputDecoration(
                  hintText: 'Select a Counter Flux',
                ),
                items: const [
                  DropdownMenuItem(
                    value: 'None',
                    child: Text('None'),
                  ),
                ],
                onChanged: (value) {
                  setState(() {
                    _selectedcontrFluxS = value; // Update the selected title
                  });
                },
                validator: (value) {
                  if (value == null) {
                    return 'Please select a title';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              DropdownButtonFormField<String>(
                value: _selecteddatbitS,
                decoration: const InputDecoration(
                  hintText: 'Select a dataBit',
                ),
                items: const [
                  DropdownMenuItem(
                    value: '5',
                    child: Text('5'),
                  ),
                  DropdownMenuItem(
                    value: '6',
                    child: Text('6'),
                  ),
                  DropdownMenuItem(
                    value: '7',
                    child: Text('7'),
                  ),
                  DropdownMenuItem(
                    value: '8',
                    child: Text('8'),
                  ),
                ],
                onChanged: (value) {
                  setState(() {
                    _selecteddatbitS = value; // Update the selected title
                  });
                },
                validator: (value) {
                  if (value == null) {
                    return 'Please select a title';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              const Divider(
                thickness: 5,
                color: Colors.white,
              ),
              const SizedBox(height: 20),
              const Text(
                  style: TextStyle(color: Color(0xFFFFFFFF),
                    fontSize: 18.0, letterSpacing: 0.0,),
                  'Selecione as credenciais para a rede Wifi que você deseja se conectar: '
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _ssidSController,
                decoration: const InputDecoration(
                  hintText: 'Nome da Rede',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Insira o nome da Rede';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _senwiSController,
                decoration: const InputDecoration(
                  hintText: 'Senha da Rede',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Insira a senha da Rede';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              const Divider(
                thickness: 5,
                color: Colors.white,
              ),
              const SizedBox(height: 20),
              const Text(
                  style: TextStyle(color: Color(0xFFFFFFFF),
                    fontSize: 18.0, letterSpacing: 0.0,),
                  'Selecione as configurações de NTRIP: '
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _hostNtpSController,
                decoration: const InputDecoration(
                  hintText: 'Host NTRIP',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Insira um Host NTRIP';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _portNtpSController,
                decoration: const InputDecoration(
                  hintText: 'Porta NTRIP',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Insira uma porta NTRIP';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _mtpntSController,
                decoration: const InputDecoration(
                  hintText: 'MountPoint',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Insira um MountPoint';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              DropdownButtonFormField<String>(
                value: _selectedsendRev2,
                decoration: const InputDecoration(
                  hintText: 'Selecione se os dados de login NTRIP será utilizado ou não',
                ),
                items: const [
                  DropdownMenuItem(
                    value: 'Y',
                    child: Text('Sim'),
                  ),
                  DropdownMenuItem(
                    value: 'N',
                    child: Text('Não'),
                  ),
                ],
                onChanged: (value) {
                  setState(() {
                    _selectedsendRev2 = value; // Update the selected title
                  });
                },
                validator: (value) {
                  if (value == null) {
                    return 'Please select a title';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _userSController,
                decoration: const InputDecoration(
                  hintText: 'Usuário NTRIP',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Insira um Usuário NTRIP';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _senSController,
                decoration: const InputDecoration(
                  hintText: 'Senha NTRIP',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Insira uma senha NTRIP';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                style: ButtonStyle(backgroundColor: WidgetStateProperty.all(Colors.white),
                  foregroundColor: WidgetStateProperty.all(Colors.black),
                ),
                onPressed: addUpdateTask,
                child: Text(widget.profile != null ? 'Atualizar Perfil' : 'Adicionar Perfil'),
              ),
              ElevatedButton(
                style: ButtonStyle(backgroundColor: WidgetStateProperty.all(Colors.white),
                  foregroundColor: WidgetStateProperty.all(Colors.black),
                ),
                onPressed: sendForm,
                child: Text('Enviar Dados'),
              ),
              ElevatedButton(
                style: ButtonStyle(backgroundColor: WidgetStateProperty.all(Colors.white),
                  foregroundColor: WidgetStateProperty.all(Colors.black),
                ),
                onPressed: saveForm,
                child: Text('Salvar Dados'),
              ),
              ElevatedButton(
                style: ButtonStyle(backgroundColor: WidgetStateProperty.all(Colors.white),
                  foregroundColor: WidgetStateProperty.all(Colors.black),
                ),
                onPressed: loadForm,
                child: Text('Carregar Dados'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> addUpdateTask() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      final isUpdating = widget.profile != null;

      if (isUpdating) {
        await updateTask();
      } else {
        await addTask();
      }

      Navigator.of(context).pop();
    }
  }
  Future<void> sendForm() async {
    final response = await http.post(
      Uri.parse('http://192.168.0.1/sourcebdr'),
      // Replace with your API endpoint
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: {
        'Perfil': _titleController.text,
        'saidaTenS': _saidaTenSController.text,
        'baudrateS': _baudrateSController.text,
        'paridadeS': _paridadeSController.text,
        'bitsParaS': _bitsParaSController.text,
        'contrFluxS': _contrFluxSController.text,
        'datbitS': _datbitSController.text,
        'ssidS': _ssidSController.text,
        'senwiS': _senwiSController.text,
        'hostNtpS': _hostNtpSController.text,
        'portNtpS': _portNtpSController.text,
        'mtpntS': _mtpntSController.text,
        'sendRev2': _sendRev2Controller.text,
        'userS': _userSController.text,
        'senS': _senSController.text,
        'Modo': 'Source',
      },
    );
    if (response.statusCode == 200) {
      // Successfully submitted
      print('Form submitted successfully');
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Data Sent'),
            content: Text('Your data has been successfully sent.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(); // Close the dialog
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );
    } else {
      // Handle error
      print('Failed to submit form: ${response.body}');
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Warning'),
            content: Text('Failed to send data'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(); // Close the dialog
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );
    }
  }

  Future<void> saveForm() async {
    var status = await Permission.storage.request();
    if (status.isDenied) {
      print('permission denied');
    }
    final directory = Directory('/storage/emulated/0/Download');
    final filePath = '${directory.path}/${_titleController.text}.txt';

    String formData =
    '''Perfil: ${_titleController.text}
      saidaTenS: ${_saidaTenSController.text}
      baudrateS: ${_baudrateSController.text}
      paridadeS: ${_paridadeSController.text}
      bitsParaS: ${_bitsParaSController.text}
      contrFluxS: ${_contrFluxSController.text}
      datbitS: ${_datbitSController.text}
      ssidS: ${_ssidSController.text}
      senwiS: ${_senwiSController.text}
      hostNtpS: ${_hostNtpSController.text}
      portNtpS: ${_portNtpSController.text}
      mtpntS: ${_mtpntSController.text}
      sendRev2: ${_sendRev2Controller.text}
      userS: ${_userSController.text}
      senS: ${_senSController.text}
      Modo: 'Source''';

    try {
      final file = File(filePath);
      await file.writeAsString(formData);
      print (formData);
      print('Form data saved to $filePath');

      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Data Saved'),
            content: Text('Your data has been successfully saved to a local file.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(); // Close the dialog
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );
    } catch (e) {
      print('Error saving file: $e');

      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Error'),
            content: Text('Failed to save the data. Please try again.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(); // Close the dialog
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );
    }
  }

  Future<void> loadForm() async {
    final directory = Directory('/storage/emulated/0/Download');
    final filePath = '${directory.path}/${_titleController.text}.txt';

    try {
      final file = File(filePath);
      if (await file.exists()) {
        String fileContent = await file.readAsString();
        print('File content loaded: $fileContent');

        final lines = fileContent.split('\n');
        for (var line in lines) {
          if (line.contains('Perfil:')) {
            _titleController.text = line.replaceFirst('Perfil: ', '').trim();
          } else if (line.contains('saidaTenS:')) {
            _selectedsaidaTenS = line.replaceFirst('saidaTenS: ', '').trim();
            saidaTenSkey.currentState?.didChange(line.replaceFirst('saidaTenS: ', '').trim());
          } else if (line.contains('baudrateS:')) {
            _selectedbaudrateS = line.replaceFirst('baudrateS: ', '').trim();
          } else if (line.contains('paridadeS:')) {
            _selectedparidadeS = line.replaceFirst('paridadeS: ', '').trim();
          } else if (line.contains('bitsParaS:')) {
            _selectedbitsParaS = line.replaceFirst('bitsParaS: ', '').trim();
          } else if (line.contains('contrFluxS:')) {
            _selectedcontrFluxS = line.replaceFirst('contrFluxS: ', '').trim();
          } else if (line.contains('datbitS:')) {
            _selecteddatbitS = line.replaceFirst('datbitS: ', '').trim();
          } else if (line.contains('ssidS:')) {
            _ssidSController.text = line.replaceFirst('ssidS: ', '').trim();
          } else if (line.contains('senwiS:')) {
            _senwiSController.text = line.replaceFirst('senwiS: ', '').trim();
          } else if (line.contains('hostNtpS:')) {
            _hostNtpSController.text = line.replaceFirst('hostNtpS: ', '').trim();
          } else if (line.contains('portNtpS:')) {
            _portNtpSController.text = line.replaceFirst('portNtpS: ', '').trim();
          } else if (line.contains('mtpntS:')) {
            _mtpntSController.text = line.replaceFirst('mtpntS: ', '').trim();
          } else if (line.contains('sendRev2:')) {
            _selectedsendRev2 = line.replaceFirst('sendRev2: ', '').trim();
          } else if (line.contains('userS:')) {
            _userSController.text = line.replaceFirst('userS: ', '').trim();
          } else if (line.contains('senS:')) {
            _senSController.text = line.replaceFirst('senS: ', '').trim();
          } else if (line.contains('Modo:')) {
          }
        }

        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('Data Loaded'),
              content: Text('The data has been successfully loaded from the file.'),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop(); // Close the dialog
                  },
                  child: Text('OK'),
                ),
              ],
            );
          },
        );
      } else {
        print('File not found at $filePath');
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('File Not Found'),
              content: Text('The file could not be found. Please check the file path.'),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop(); // Close the dialog
                  },
                  child: Text('OK'),
                ),
              ],
            );
          },
        );
      }
    } catch (e) {
      print('Error loading file: $e');
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Error'),
            content: Text('Failed to load the data. Please try again.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(); // Close the dialog
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );
    }
  }
}
