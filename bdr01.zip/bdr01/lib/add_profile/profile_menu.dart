import 'package:bdr01copy/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:bdr01copy/backend/Profile/profile_database.dart';
import 'package:bdr01copy/backend/Profile/task.dart';
import 'package:bdr01copy/add_profile/add_task.dart';
import 'package:bdr01copy/widget/task_list_tile.dart';

import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_widgets.dart';
import '../menu/options/options_widget.dart';
import 'add_task2.dart';
import 'add_task3.dart';

class ProfileMenu extends StatefulWidget {
  const ProfileMenu({super.key});

  @override
  State<ProfileMenu> createState() => _ProfileMenuState();
}

class _ProfileMenuState extends State<ProfileMenu> {
  bool isLoading = false;
  List<Profile> profile = [];

  Future<void> getAllTasks() async {
    setState(() => isLoading = true);

    profile = await TasksDatabase.instance.readAllTasks();

    setState(() => isLoading = false);
  }

  @override
  void initState() {
    super.initState();
    getAllTasks();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(100),
        child: SafeArea(
          child: Container(
            width: double.infinity,
            height: 60.0,
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(
                color: Color(0xFFD5D3E3),
                width: 2.0,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Container(
                  width: 150.0,
                  height: 100.0,
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Align(
                        alignment: AlignmentDirectional(-1.0, 0.0),
                        child: FFButtonWidget(
                          onPressed: () async {
                            context.safePop();
                          },
                          text: '',
                          icon: Icon(
                            Icons.arrow_back_rounded,
                            color: Colors.black,
                            size: 23.0,
                          ),
                          options: FFButtonOptions(
                            width: 32.0,
                            height: 30.0,
                            padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                            iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                            color: Colors.white,
                            textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                              fontFamily: 'Inter Tight',
                              color: Colors.white,
                              letterSpacing: 0.0,
                            ),
                            elevation: 0.0,
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                        ),
                      ),
                      Align(
                        alignment: AlignmentDirectional(-1.0, 0.0),
                        child: FFButtonWidget(
                          onPressed: () async {
                            context.pushNamed('HomePage');
                          },
                          text: '',
                          icon: Icon(
                            Icons.home_rounded,
                            color: Colors.black,
                            size: 23.0,
                          ),
                          options: FFButtonOptions(
                            width: 32.0,
                            height: 30.0,
                            padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                            iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                            color: Colors.white,
                            textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                              fontFamily: 'Inter Tight',
                              color: Colors.white,
                              letterSpacing: 0.0,
                            ),
                            elevation: 0.0,
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                        ),
                      ),
                      Align(
                        alignment: AlignmentDirectional(-1.0, 0.0),
                        child: Text(
                          FFLocalizations.of(context).getText(
                            'zhfq8r8e' /* BDR_01 */,
                          ),
                          style: FlutterFlowTheme.of(context).titleLarge.override(
                            fontFamily: 'Montserrat',
                            color: Color(0xFF14181B),
                            letterSpacing: 0.0,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Align(
                  alignment: AlignmentDirectional(1.0, 0.0),
                  child: FFButtonWidget(
                    onPressed: () async {
                      await showModalBottomSheet(
                        isScrollControlled: true,
                        backgroundColor: Colors.transparent,
                        enableDrag: false,
                        context: context,
                        builder: (context) {
                          return GestureDetector(
                            onTap: () => FocusScope.of(context).unfocus(),
                            child: Padding(
                              padding: MediaQuery.viewInsetsOf(context),
                              child: OptionsWidget(),
                            ),
                          );
                        },
                      ).then((value) => safeSetState(() {}));
                    },
                    text: '',
                    icon: Icon(
                      Icons.menu_sharp,
                      color: Colors.black,
                      size: 23.0,
                    ),
                    options: FFButtonOptions(
                      width: 32.0,
                      height: 30.0,
                      padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                      iconPadding: EdgeInsets.all(0.0),
                      color: Colors.white,
                      textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                        fontFamily: 'Inter Tight',
                        color: Colors.white,
                        letterSpacing: 0.0,
                      ),
                      elevation: 0.0,
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                ),
              ].divide(SizedBox(width: 200.0)),
            ),
          ),
        ),
      ),
      body: isLoading
          ? const Center(
        child: CircularProgressIndicator(),
      )
          : _buildTasksList(),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
            showDialog(
              context: context,
              builder: (context) {
                return AlertDialog(
                  backgroundColor: Colors.white,
                  title: Center(
                    child: Text(
                      'Options',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                  ),
                  content: SingleChildScrollView(
                    child: ListBody(
                      children: [
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                          ),
                          onPressed: () async {
                            await Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => const AddTaskScreen(),
                              ),
                            );
                            getAllTasks();
                            print('Local option selected');
                            Navigator.pop(context);
                          },
                          child: Text(
                              'Local',
                            style: TextStyle(color: Colors.black),
                          ),
                        ),
                        SizedBox(height: 10),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                          ),
                          onPressed: () async {
                            await Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => const AddTaskScreen2(),
                              ),
                            );
                            getAllTasks();
                            print('Cliente option selected');
                            Navigator.pop(context);
                          },
                          child: Text(
                              'Cliente',
                            style: TextStyle(color: Colors.black),
                          ),
                        ),
                        SizedBox(height: 10),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                          ),
                          onPressed: () async {
                            await Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => const AddTaskScreen3(),
                              ),
                            );
                            getAllTasks();
                            print('Source option selected');
                            Navigator.pop(context);
                          },
                          child: Text(
                            'Source',
                            style: TextStyle(color: Colors.black),
                          ),
                        ),
                        SizedBox(height: 10),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                          ),
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: Text(
                              'Close',
                              style: TextStyle(color: Colors.black),
                            ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        child: const Icon(Icons.add),
      ),
    );
  }


  Widget _buildTasksList() {
    return ListView.builder(
      itemCount: profile.length,
      itemBuilder: (context, index) {
        final task = profile[index];

        return GestureDetector(
          onTap: () async {

            if (task.mode == 'Local') { // Use '==' for comparison
              await Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => AddTaskScreen(
                    profile: task,
                  ),
                ),
              );
            }
            else if (task.mode == 'Cliente') {
              await Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => AddTaskScreen2(
                    profile: task,
                  ),
                ),
              );
            }
            else if (task.mode == 'Source') {
              await Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => AddTaskScreen3(
                    profile: task,
                  ),
                ),
              );
            }

            getAllTasks();
          },
          child: TaskListTile(task: task),
        );
      },
    );
  }
}


