import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:bdr01copy/backend/Profile/profile_database.dart';
import 'package:bdr01copy/backend/Profile/extensions.dart';
import 'package:bdr01copy/backend/Profile/task.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import '/custom_code/actions/index.dart' as actions;

final _formKey = GlobalKey<FormState>();

class AddTaskScreen2 extends StatefulWidget {
  const AddTaskScreen2({
    super.key,
    this.profile,
  });

  final Profile? profile;

  @override
  State<AddTaskScreen2> createState() => _AddTaskScreenState2();
}

class _AddTaskScreenState2 extends State<AddTaskScreen2> {
  final saidaTenCkey = GlobalKey<FormFieldState>();
  String? _selectedsaidaTenC;
  String? _selectedbaudrateC;
  String? _selectedparidadeC;
  String? _selectedbitsParaC;
  String? _selectedcontrFluxC;
  String? _selecteddatbitC;
  String? _selectedsendLatLong;
  late final TextEditingController _titleController;
  late final TextEditingController _modeController;

  late final TextEditingController _saidaTenLController;
  late final TextEditingController _baudrateLController;
  late final TextEditingController _paridadeLController;
  late final TextEditingController _bitsParaLController;
  late final TextEditingController _contrFluxLController;
  late final TextEditingController _datbitLController;
  late final TextEditingController _ssidLController;
  late final TextEditingController _senwiLController;
  late final TextEditingController _hostNtpLController;
  late final TextEditingController _portNtpLController;
  late final TextEditingController _mtpntLController;
  late final TextEditingController _userLController;
  late final TextEditingController _senLController;

  late final TextEditingController _saidaTenCController;
  late final TextEditingController _baudrateCController;
  late final TextEditingController _paridadeCController;
  late final TextEditingController _bitsParaCController;
  late final TextEditingController _contrFluxCController;
  late final TextEditingController _datbitCController;
  late final TextEditingController _ssidCController;
  late final TextEditingController _senwiCController;
  late final TextEditingController _hostNtpCController;
  late final TextEditingController _portNtpCController;
  late final TextEditingController _mtpntCController;
  late final TextEditingController _userCController;
  late final TextEditingController _senCController;
  late final TextEditingController _sendLatLongController;
  late final TextEditingController _latController;
  late final TextEditingController _lonController;
  late final TextEditingController _altController;
  late final TextEditingController _preController;
  late final TextEditingController _utcController;

  late final TextEditingController _saidaTenSController;
  late final TextEditingController _baudrateSController;
  late final TextEditingController _paridadeSController;
  late final TextEditingController _bitsParaSController;
  late final TextEditingController _contrFluxSController;
  late final TextEditingController _datbitSController;
  late final TextEditingController _ssidSController;
  late final TextEditingController _senwiSController;
  late final TextEditingController _hostNtpSController;
  late final TextEditingController _portNtpSController;
  late final TextEditingController _mtpntSController;
  late final TextEditingController _sendRev2Controller;
  late final TextEditingController _userSController;
  late final TextEditingController _senSController;

  @override
  void initState() {
    _selectedsaidaTenC = '5V';
    _selectedbaudrateC = '115200';
    _selectedparidadeC = 'None';
    _selectedbitsParaC = '1';
    _selectedcontrFluxC = 'None';
    _selecteddatbitC = '8';
    _selectedsendLatLong = 'Y';
    _titleController = TextEditingController();
    _modeController = TextEditingController();

    _saidaTenLController = TextEditingController();
    _baudrateLController = TextEditingController();
    _paridadeLController = TextEditingController();
    _bitsParaLController = TextEditingController();
    _contrFluxLController = TextEditingController();
    _datbitLController = TextEditingController();
    _ssidLController = TextEditingController();
    _senwiLController = TextEditingController();
    _hostNtpLController = TextEditingController();
    _portNtpLController = TextEditingController();
    _mtpntLController = TextEditingController();
    _userLController = TextEditingController();
    _senLController = TextEditingController();

    _saidaTenCController = TextEditingController();
    _baudrateCController = TextEditingController();
    _paridadeCController = TextEditingController();
    _bitsParaCController = TextEditingController();
    _contrFluxCController = TextEditingController();
    _datbitCController = TextEditingController();
    _ssidCController = TextEditingController();
    _senwiCController = TextEditingController();
    _hostNtpCController = TextEditingController();
    _portNtpCController = TextEditingController();
    _mtpntCController = TextEditingController();
    _userCController = TextEditingController();
    _senCController = TextEditingController();
    _sendLatLongController = TextEditingController();
    _latController = TextEditingController();
    _lonController = TextEditingController();
    _altController = TextEditingController();
    _preController = TextEditingController();
    _utcController = TextEditingController();

    _saidaTenSController = TextEditingController();
    _baudrateSController = TextEditingController();
    _paridadeSController = TextEditingController();
    _bitsParaSController = TextEditingController();
    _contrFluxSController = TextEditingController();
    _datbitSController = TextEditingController();
    _ssidSController = TextEditingController();
    _senwiSController = TextEditingController();
    _hostNtpSController = TextEditingController();
    _portNtpSController = TextEditingController();
    _mtpntSController = TextEditingController();
    _sendRev2Controller = TextEditingController();
    _userSController = TextEditingController();
    _senSController = TextEditingController();
    if (widget.profile != null) {
      _titleController.text = widget.profile!.title;
      _modeController.text = widget.profile!.mode;

      _selectedsaidaTenC = widget.profile!.saidaTenC;
      _selectedbaudrateC = widget.profile!.baudrateC;
      _selectedparidadeC = widget.profile!.paridadeC;
      _selectedbitsParaC = widget.profile!.bitsParaC;
      _selectedcontrFluxC = widget.profile!.contrFluxC;
      _selecteddatbitC = widget.profile!.datbitC;
      _selectedsendLatLong = widget.profile!.sendLatLong;
      _saidaTenLController.text = widget.profile!.saidaTenL;
      _baudrateLController.text = widget.profile!.baudrateL;
      _paridadeLController.text = widget.profile!.paridadeL;
      _bitsParaLController.text = widget.profile!.bitsParaL;
      _contrFluxLController.text = widget.profile!.contrFluxL;
      _datbitLController.text = widget.profile!.datbitL;
      _ssidLController.text = widget.profile!.ssidL;
      _senwiLController.text = widget.profile!.senwiL;
      _hostNtpLController.text = widget.profile!.hostNtpL;
      _portNtpLController.text = widget.profile!.portNtpL;
      _mtpntLController.text = widget.profile!.mtpntL;
      _userLController.text = widget.profile!.userL;
      _senLController.text = widget.profile!.senL;

      _saidaTenCController.text = widget.profile!.saidaTenC;
      _baudrateCController.text = widget.profile!.baudrateC;
      _paridadeCController.text = widget.profile!.paridadeC;
      _bitsParaCController.text = widget.profile!.bitsParaC;
      _contrFluxCController.text = widget.profile!.contrFluxC;
      _datbitCController.text = widget.profile!.datbitC;
      _ssidCController.text = widget.profile!.ssidC;
      _senwiCController.text = widget.profile!.senwiC;
      _hostNtpCController.text = widget.profile!.hostNtpC;
      _portNtpCController.text = widget.profile!.portNtpC;
      _mtpntCController.text = widget.profile!.mtpntC;
      _userCController.text = widget.profile!.userC;
      _senCController.text = widget.profile!.senC;
      _sendLatLongController.text = widget.profile!.sendLatLong;
      _latController.text = widget.profile!.lat;
      _lonController.text = widget.profile!.lon;
      _altController.text = widget.profile!.alt;
      _preController.text = widget.profile!.pre;
      _utcController.text = widget.profile!.utc;

      _saidaTenSController.text = widget.profile!.saidaTenS;
      _baudrateSController.text = widget.profile!.baudrateS;
      _paridadeSController.text = widget.profile!.paridadeS;
      _bitsParaSController.text = widget.profile!.bitsParaS;
      _contrFluxSController.text = widget.profile!.contrFluxS;
      _datbitSController.text = widget.profile!.datbitS;
      _ssidSController.text = widget.profile!.ssidS;
      _senwiSController.text = widget.profile!.senwiS;
      _hostNtpSController.text = widget.profile!.hostNtpS;
      _portNtpSController.text = widget.profile!.portNtpS;
      _mtpntSController.text = widget.profile!.mtpntS;
      _sendRev2Controller.text = widget.profile!.userL;
      _userSController.text = widget.profile!.userS;
      _senSController.text = widget.profile!.senS;
    }
    super.initState();
  }

  @override
  void dispose() {
    _titleController.dispose();
    _saidaTenLController.dispose();
    _modeController.dispose();
    _baudrateLController.dispose();
    _paridadeLController.dispose();
    _bitsParaLController.dispose();
    _contrFluxLController.dispose();
    _datbitLController.dispose();
    _ssidLController.dispose();
    _senwiLController.dispose();
    _hostNtpLController.dispose();
    _portNtpLController.dispose();
    _mtpntLController.dispose();
    _userLController.dispose();
    _senLController.dispose();

    _saidaTenCController.dispose();
    _baudrateCController.dispose();
    _paridadeCController.dispose();
    _bitsParaCController.dispose();
    _contrFluxCController.dispose();
    _datbitCController.dispose();
    _ssidCController.dispose();
    _senwiCController.dispose();
    _hostNtpCController.dispose();
    _portNtpCController.dispose();
    _mtpntCController.dispose();
    _userCController.dispose();
    _senCController.dispose();
    _sendLatLongController.dispose();
    _latController.dispose();
    _lonController.dispose();
    _altController.dispose();
    _preController.dispose();
    _utcController.dispose();

    _saidaTenSController.dispose();
    _baudrateSController.dispose();
    _paridadeSController.dispose();
    _bitsParaSController.dispose();
    _contrFluxSController.dispose();
    _datbitSController.dispose();
    _ssidSController.dispose();
    _senwiSController.dispose();
    _hostNtpSController.dispose();
    _portNtpSController.dispose();
    _mtpntSController.dispose();
    _sendRev2Controller.dispose();
    _userSController.dispose();
    _senSController.dispose();
    super.dispose();
  }

  void updateLatitude(String latitude) {
    setState(() {
      _latController.text = latitude;
    });
  }

  void updateLongitude(String longitude) {
    setState(() {
      _lonController.text = longitude;
    });
  }

  void updateAltitude(String altitude) {
    setState(() {
      _altController.text = altitude;
    });
  }

  void updatePrecisao(String precisao) {
    setState(() {
      _preController.text = precisao;
    });
  }

  void updateUtcTime(String utcTime) {
    setState(() {
      _utcController.text = utcTime;
    });
  }

  Future<void> addTask() async {
    final profile = Profile(
      title: _titleController.text,
      mode: _modeController.text,

      saidaTenL: _saidaTenLController.text,
      baudrateL: _baudrateLController.text,
      paridadeL: _paridadeLController.text,
      bitsParaL: _bitsParaLController.text,
      contrFluxL: _contrFluxLController.text,
      datbitL: _datbitLController.text,
      ssidL: _ssidLController.text,
      senwiL: _senwiLController.text,
      hostNtpL: _hostNtpLController.text,
      portNtpL: _portNtpLController.text,
      mtpntL: _mtpntLController.text,
      userL: _userLController.text,
      senL: _senLController.text,

      saidaTenC: _selectedsaidaTenC!,
      baudrateC: _selectedbaudrateC!,
      paridadeC: _selectedparidadeC!,
      bitsParaC: _selectedbitsParaC!,
      contrFluxC: _selectedcontrFluxC!,
      datbitC: _selecteddatbitC!,
      ssidC: _ssidCController.text,
      senwiC: _senwiCController.text,
      hostNtpC: _hostNtpCController.text,
      portNtpC: _portNtpCController.text,
      mtpntC: _mtpntCController.text,
      userC: _userCController.text,
      senC: _senCController.text,
      sendLatLong: _selectedsendLatLong!,
      lat: _latController.text,
      lon: _lonController.text,
      alt: _altController.text,
      pre: _preController.text,
      utc: _utcController.text,

      saidaTenS: _saidaTenSController.text,
      baudrateS: _baudrateSController.text,
      paridadeS: _paridadeSController.text,
      bitsParaS: _bitsParaSController.text,
      contrFluxS: _contrFluxSController.text,
      datbitS: _datbitSController.text,
      ssidS: _ssidSController.text,
      senwiS: _senwiSController.text,
      hostNtpS: _hostNtpSController.text,
      portNtpS: _portNtpSController.text,
      mtpntS: _mtpntSController.text,
      sendRev2: _sendRev2Controller.text,
      userS: _userSController.text,
      senS: _senSController.text,
    );

    await TasksDatabase.instance.createTask(profile);
  }

  Future<void> updateTask() async {
    final profile = widget.profile!.copy(
      title: _titleController.text,
      mode: _modeController.text,

      saidaTenC: _selectedsaidaTenC!,
      baudrateC: _selectedbaudrateC!,
      paridadeC: _selectedparidadeC!,
      bitsParaC: _selectedbitsParaC!,
      contrFluxC: _selectedcontrFluxC!,
      datbitC: _selecteddatbitC!,
      ssidC: _ssidCController.text,
      senwiC: _senwiCController.text,
      hostNtpC: _hostNtpCController.text,
      portNtpC: _portNtpCController.text,
      mtpntC: _mtpntCController.text,
      userC: _userCController.text,
      senC: _senCController.text,
      sendLatLong: _selectedsendLatLong!,
      lat: _latController.text,
      lon: _lonController.text,
      alt: _altController.text,
      pre: _preController.text,
      utc: _utcController.text,
    );

    await TasksDatabase.instance.updateTask(profile);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Adicionar Perfil Cliente'),
        actions: [
          IconButton(
            onPressed: () async {
              await TasksDatabase.instance.deleteTask(widget.profile!.id!);

              Navigator.of(context).pop();
            },
            icon: const Icon(
              Icons.delete,
              color: Colors.red,
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(
          horizontal: 16.0,
          vertical: 12.0,
        ),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Visibility(
                visible: false,
                child: TextFormField(
                  controller: _modeController..text = 'Cliente',
                  decoration: const InputDecoration(
                    hintText: 'Title',
                  ),
                  readOnly: true,
                ),
              ),
              const Text(
                  style: TextStyle(color: Color(0xFFFFFFFF),
                    fontSize: 18.0, letterSpacing: 0.0,),
                  'Selecione o nome do perfil: '
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _titleController,
                decoration: const InputDecoration(
                  hintText: 'Nome do Perfil',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Insira um nome para o Perfil';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              const Divider(
                thickness: 5,
                color: Colors.white,
              ),
              const SizedBox(height: 20),
              const Text(
                  style: TextStyle(color: Color(0xFFFFFFFF),
                    fontSize: 18.0, letterSpacing: 0.0,),
                  'Selecione abaixo as configurações da entrada Serial:  '
              ),
              const SizedBox(height: 20),
              DropdownButtonFormField<String>(
                key: saidaTenCkey,
                value: _selectedsaidaTenC,
                decoration: const InputDecoration(
                  hintText: 'Select a Output',
                ),
                items: const [
                  DropdownMenuItem(
                    value: '5V',
                    child: Text('5V'),
                  ),
                  DropdownMenuItem(
                    value: '9V',
                    child: Text('9V'),
                  ),
                  DropdownMenuItem(
                    value: '12V',
                    child: Text('12V'),
                  ),
                  DropdownMenuItem(
                    value: '15V',
                    child: Text('15V'),
                  ),
                  DropdownMenuItem(
                    value: '20V',
                    child: Text('20V'),
                  ),
                ],
                onChanged: (value) {
                  setState(() {
                    _selectedsaidaTenC = value; // Update the selected title
                  });
                },
                validator: (value) {
                  if (value == null) {
                    return 'Please select a title';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              DropdownButtonFormField<String>(
                value: _selectedbaudrateC,
                decoration: const InputDecoration(
                  hintText: 'Select a baudrate',
                ),
                items: const [
                  DropdownMenuItem(
                    value: '9600',
                    child: Text('9600'),
                  ),
                  DropdownMenuItem(
                    value: '19200',
                    child: Text('19200'),
                  ),
                  DropdownMenuItem(
                    value: '38400',
                    child: Text('38400'),
                  ),
                  DropdownMenuItem(
                    value: '57600',
                    child: Text('57600'),
                  ),
                  DropdownMenuItem(
                    value: '115200',
                    child: Text('115200'),
                  ),
                ],
                onChanged: (value) {
                  setState(() {
                    _selectedbaudrateC = value; // Update the selected title
                  });
                },
                validator: (value) {
                  if (value == null) {
                    return 'Please select a title';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              DropdownButtonFormField<String>(
                value: _selectedparidadeC,
                decoration: const InputDecoration(
                  hintText: 'Select a parity',
                ),
                items: const [
                  DropdownMenuItem(
                    value: 'None',
                    child: Text('None'),
                  ),
                ],
                onChanged: (value) {
                  setState(() {
                    _selectedparidadeC = value; // Update the selected title
                  });
                },
                validator: (value) {
                  if (value == null) {
                    return 'Please select a title';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              DropdownButtonFormField<String>(
                value: _selectedbitsParaC,
                decoration: const InputDecoration(
                  hintText: 'Select a Stop Bit',
                ),
                items: const [
                  DropdownMenuItem(
                    value: '1',
                    child: Text('1'),
                  ),
                  DropdownMenuItem(
                    value: '1.5',
                    child: Text('1.5'),
                  ),
                  DropdownMenuItem(
                    value: '2',
                    child: Text('2'),
                  ),
                  DropdownMenuItem(
                    value: '3',
                    child: Text('3'),
                  ),
                ],
                onChanged: (value) {
                  setState(() {
                    _selectedbitsParaC = value; // Update the selected title
                  });
                },
                validator: (value) {
                  if (value == null) {
                    return 'Please select a title';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              DropdownButtonFormField<String>(
                value: _selectedcontrFluxC,
                decoration: const InputDecoration(
                  hintText: 'Select a Counter Flux',
                ),
                items: const [
                  DropdownMenuItem(
                    value: 'None',
                    child: Text('None'),
                  ),
                ],
                onChanged: (value) {
                  setState(() {
                    _selectedcontrFluxC = value; // Update the selected title
                  });
                },
                validator: (value) {
                  if (value == null) {
                    return 'Please select a title';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              DropdownButtonFormField<String>(
                value: _selecteddatbitC,
                decoration: const InputDecoration(
                  hintText: 'Select a dataBit',
                ),
                items: const [
                  DropdownMenuItem(
                    value: '5',
                    child: Text('5'),
                  ),
                  DropdownMenuItem(
                    value: '6',
                    child: Text('6'),
                  ),
                  DropdownMenuItem(
                    value: '7',
                    child: Text('7'),
                  ),
                  DropdownMenuItem(
                    value: '8',
                    child: Text('8'),
                  ),
                ],
                onChanged: (value) {
                  setState(() {
                    _selecteddatbitC = value; // Update the selected title
                  });
                },
                validator: (value) {
                  if (value == null) {
                    return 'Please select a title';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              const Divider(
                thickness: 5,
                color: Colors.white,
              ),
              const SizedBox(height: 20),
              const Text(
                  style: TextStyle(color: Color(0xFFFFFFFF),
                    fontSize: 18.0, letterSpacing: 0.0,),
                  'Selecione as credenciais para a rede Wifi que você deseja se conectar: '
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _ssidCController,
                decoration: const InputDecoration(
                  hintText: 'Nome da Rede',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Insira o nome da Rede';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _senwiCController,
                decoration: const InputDecoration(
                  hintText: 'Senha da Rede',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Insira a Senha da Rede';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              const Divider(
                thickness: 5,
                color: Colors.white,
              ),
              const SizedBox(height: 20),
              const Text(
                  style: TextStyle(color: Color(0xFFFFFFFF),
                    fontSize: 18.0, letterSpacing: 0.0,),
                  'Selecione as configurações de NTRIP: '
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _hostNtpCController,
                decoration: const InputDecoration(
                  hintText: 'Host NTRIP',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Insira um Host NTRIP';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _portNtpCController,
                decoration: const InputDecoration(
                  hintText: 'Porta NTRIP',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Insira uma Porta NTRIP';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _mtpntCController,
                decoration: const InputDecoration(
                  hintText: 'MountPoint',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Insira um MountPoint';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _userCController,
                decoration: const InputDecoration(
                  hintText: 'Usuário NTRIP',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Insira um usuário NTRIP';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _senCController,
                decoration: const InputDecoration(
                  hintText: 'Senha NTRIP',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Insira a senha NTRIP';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              const Divider(
                thickness: 5,
                color: Colors.white,
              ),
              const SizedBox(height: 20),
              const Text(
                  style: TextStyle(color: Color(0xFFFFFFFF),
                    fontSize: 18.0, letterSpacing: 0.0,),
                  'Digite as configurações de localização ou as consiga automaticamente com o botão abaixo: '
              ),
              const SizedBox(height: 20),
              DropdownButtonFormField<String>(
                value: _selectedsendLatLong,
                decoration: const InputDecoration(
                  hintText: 'Selecione se a Localização será utilizada ou não',
                ),
                items: const [
                  DropdownMenuItem(
                    value: 'Y',
                    child: Text('Sim'),
                  ),
                  DropdownMenuItem(
                    value: 'N',
                    child: Text('Não'),
                  ),
                ],
                onChanged: (value) {
                  setState(() {
                    _selectedsendLatLong = value; // Update the selected title
                  });
                },
                validator: (value) {
                  if (value == null) {
                    return 'Please select a title';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _latController,
                decoration: const InputDecoration(
                  hintText: 'Latitude',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Insira um valor de Latitude';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _lonController,
                decoration: const InputDecoration(
                  hintText: 'Longitude',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Insira um valor de Longitude';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _altController,
                decoration: const InputDecoration(
                  hintText: 'Altitude',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Insira um valor de Altitude';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _preController,
                decoration: const InputDecoration(
                  hintText: 'Precisão',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Insira um valor de Precisão';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _utcController,
                decoration: const InputDecoration(
                  hintText: 'Tempo em UTC',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Insira o Tempo em UTC';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () async {
                  await actions.getLocation(updateLatitude, updateLongitude, updateAltitude, updatePrecisao);
                  actions.utcTime(updateUtcTime);
                },
                style: ButtonStyle(backgroundColor: WidgetStateProperty.all(Colors.white),
                  foregroundColor: WidgetStateProperty.all(Colors.black),
                ),
                child: Text('Buscar Localização'),
              ),
              ElevatedButton(
                style: ButtonStyle(backgroundColor: WidgetStateProperty.all(Colors.white),
                                   foregroundColor: WidgetStateProperty.all(Colors.black),
                ),
                onPressed: addUpdateTask,
                child: Text(widget.profile != null ? 'Atualizar Perfil' : 'Adicionar Perfil'),
              ),
                ElevatedButton(
                  style: ButtonStyle(backgroundColor: WidgetStateProperty.all(Colors.white),
                                     foregroundColor: WidgetStateProperty.all(Colors.black),
                  ),
                  onPressed: sendForm,
                  child: Text('Enviar Dados'),
              ),
              ElevatedButton(
                style: ButtonStyle(backgroundColor: WidgetStateProperty.all(Colors.white),
                  foregroundColor: WidgetStateProperty.all(Colors.black),
                ),
                onPressed: saveForm,
                child: Text('Salvar Dados'),
              ),
              ElevatedButton(
                style: ButtonStyle(backgroundColor: WidgetStateProperty.all(Colors.white),
                  foregroundColor: WidgetStateProperty.all(Colors.black),
                ),
                onPressed: loadForm,
                child: Text('Carregar Dados'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> addUpdateTask() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      final isUpdating = widget.profile != null;

      if (isUpdating) {
        await updateTask();
      } else {
        await addTask();
      }

      Navigator.of(context).pop();
    }
  }
  Future<void> sendForm() async {
    final response = await http.post(
      Uri.parse('http://192.168.0.1/clientebdr'),
      // Replace with your API endpoint
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: {
        'Perfil': _titleController.text,
        'saidaTenC': _saidaTenCController.text,
        'baudrateC': _baudrateCController.text,
        'paridadeC': _paridadeCController.text,
        'bitsParaC': _bitsParaCController.text,
        'contrFluxC': _contrFluxCController.text,
        'datbitC': _datbitCController.text,
        'ssidC': _ssidCController.text,
        'senwiC': _senwiCController.text,
        'hostNtpC': _hostNtpCController.text,
        'portNtpC': _portNtpCController.text,
        'mtpntC': _mtpntCController.text,
        'userC': _userCController.text,
        'senC': _senCController.text,
        'sendLatLong': _sendLatLongController.text,
        'lat': _latController.text,
        'lon': _lonController.text,
        'alt': _altController.text,
        'pre': _preController.text,
        'utc': _utcController.text,
        'Modo': 'Cliente',
      },
    );
    if (response.statusCode == 200) {
      // Successfully submitted
      print('Form submitted successfully');
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Data Sent'),
            content: Text('Your data has been successfully sent.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(); // Close the dialog
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );
    } else {
      // Handle error
      print('Failed to submit form: ${response.body}');
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Warning'),
            content: Text('Failed to send data'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(); // Close the dialog
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );
    }
  }

  Future<void> saveForm() async {
    var status = await Permission.storage.request();
    if (status.isDenied) {
      print('permission denied');
    }
    final directory = Directory('/storage/emulated/0/Download');
    final filePath = '${directory.path}/${_titleController.text}.txt';

    String formData =
    '''Perfil: ${_titleController.text}
      saidaTenC: ${_saidaTenCController.text}
      baudrateC: ${_baudrateCController.text}
      paridadeC: ${_paridadeCController.text}
      bitsParaC: ${_bitsParaCController.text}
      contrFluxC: ${_contrFluxCController.text}
      datbitC: ${_datbitCController.text}
      ssidC: ${_ssidCController.text}
      senwiC: ${_senwiCController.text}
      hostNtpC: ${_hostNtpCController.text}
      portNtpC: ${_portNtpCController.text}
      mtpntC: ${_mtpntCController.text}
      userC: ${_userCController.text}
      senC: ${_senCController.text}
      sendLatLong: ${_sendLatLongController.text}
      lat: ${_latController.text}
      lon: ${_lonController.text}
      alt: ${_altController.text}
      pre: ${_preController.text}
      utc: ${_utcController.text}
      Modo: 'Cliente''';

    try {
      final file = File(filePath);
      await file.writeAsString(formData);
      print (formData);
      print('Form data saved to $filePath');

      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Data Saved'),
            content: Text('Your data has been successfully saved to a local file.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(); // Close the dialog
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );
    } catch (e) {
      print('Error saving file: $e');

      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Error'),
            content: Text('Failed to save the data. Please try again.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(); // Close the dialog
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );
    }
  }

  Future<void> loadForm() async {
    final directory = Directory('/storage/emulated/0/Download');
    final filePath = '${directory.path}/${_titleController.text}.txt';

    try {
      final file = File(filePath);
      if (await file.exists()) {
        String fileContent = await file.readAsString();
        print('File content loaded: $fileContent');

        final lines = fileContent.split('\n');
        for (var line in lines) {
          if (line.contains('Perfil:')) {
            _titleController.text = line.replaceFirst('Perfil: ', '').trim();
          } else if (line.contains('saidaTenC:')) {
            _selectedsaidaTenC = line.replaceFirst('saidaTenC: ', '').trim();
            saidaTenCkey.currentState?.didChange(line.replaceFirst('saidaTenC: ', '').trim());
          } else if (line.contains('baudrateC:')) {
            _selectedbaudrateC = line.replaceFirst('baudrateC: ', '').trim();
          } else if (line.contains('paridadeC:')) {
            _selectedparidadeC = line.replaceFirst('paridadeC: ', '').trim();
          } else if (line.contains('bitsParaC:')) {
            _selectedbitsParaC = line.replaceFirst('bitsParaC: ', '').trim();
          } else if (line.contains('contrFluxC:')) {
            _selectedcontrFluxC = line.replaceFirst('contrFluxC: ', '').trim();
          } else if (line.contains('datbitC:')) {
            _selecteddatbitC = line.replaceFirst('datbitC: ', '').trim();
          } else if (line.contains('ssidC:')) {
            _ssidCController.text = line.replaceFirst('ssidC: ', '').trim();
          } else if (line.contains('senwiC:')) {
            _senwiCController.text = line.replaceFirst('senwiC: ', '').trim();
          } else if (line.contains('hostNtpC:')) {
            _hostNtpCController.text = line.replaceFirst('hostNtpC: ', '').trim();
          } else if (line.contains('portNtpC:')) {
            _portNtpCController.text = line.replaceFirst('portNtpC: ', '').trim();
          } else if (line.contains('mtpntC:')) {
            _mtpntCController.text = line.replaceFirst('mtpntC: ', '').trim();
          } else if (line.contains('userC:')) {
            _userCController.text = line.replaceFirst('userC: ', '').trim();
          } else if (line.contains('senC:')) {
            _senCController.text = line.replaceFirst('senC: ', '').trim();
          } else if (line.contains('sendLatLong:')) {
            _selectedsendLatLong = line.replaceFirst('sendLatLong: ', '').trim();
          } else if (line.contains('lat:')) {
            _latController.text = line.replaceFirst('lat: ', '').trim();
          } else if (line.contains('lon:')) {
            _lonController.text = line.replaceFirst('lon: ', '').trim();
          } else if (line.contains('alt:')) {
            _altController.text = line.replaceFirst('alt: ', '').trim();
          } else if (line.contains('pre:')) {
            _preController.text = line.replaceFirst('pre: ', '').trim();
          } else if (line.contains('utc:')) {
            _utcController.text = line.replaceFirst('utc: ', '').trim();
          } else if (line.contains('Modo:')) {
          }
        }

        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('Data Loaded'),
              content: Text('The data has been successfully loaded from the file.'),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop(); // Close the dialog
                  },
                  child: Text('OK'),
                ),
              ],
            );
          },
        );
      } else {
        print('File not found at $filePath');
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('File Not Found'),
              content: Text('The file could not be found. Please check the file path.'),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop(); // Close the dialog
                  },
                  child: Text('OK'),
                ),
              ],
            );
          },
        );
      }
    } catch (e) {
      print('Error loading file: $e');
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Error'),
            content: Text('Failed to load the data. Please try again.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(); // Close the dialog
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );
    }
  }
}
