import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'options_widget.dart' show OptionsWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class OptionsModel extends FlutterFlowModel<OptionsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
