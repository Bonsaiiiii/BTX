import 'dart:async';

import '../../backend/api_requests/api_calls.dart';
import '../../backend/api_requests/api_manager.dart';
import '/flutter_flow/flutter_flow_language_selector.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/menu/options/options_widget.dart';
import '/custom_code/actions/index.dart' as actions;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'connection_page_model.dart';
export 'connection_page_model.dart';
import 'package:bdr01copy/backend/connectivity/globals.dart' as globals;

class ConnectionPageWidget extends StatefulWidget {
  const ConnectionPageWidget({super.key});

  @override
  State<ConnectionPageWidget> createState() => _ConnectionPageWidgetState();
}

class _ConnectionPageWidgetState extends State<ConnectionPageWidget> {
  late ConnectionPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  void checkConnectivity() {
        setState(() {
              print('tried going to home');
              context.pop();
        });
    }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await changePage();
    });
    _model = createModel(context, () => ConnectionPageModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  Future<void> changePage() async {
    if (globals.check_internet == true) {
      if (globals.bdr_avail == true) {
        print(globals.bdr_avail);
        print('bdr_avail true');
        checkConnectivity();
        globals.check_internet = false;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        for (int i = 0; i < 2;) {
          print('going home');
          await changePage();
          await Future.delayed(const Duration(seconds: 1));
          if (globals.bdr_avail) {
            i++;
          }
        }
      });

          return GestureDetector(
            onTap: () => FocusScope.of(context).unfocus(),
            child: Scaffold(
              key: scaffoldKey,
              backgroundColor: Colors.white,
              body: SafeArea(
                top: true,
                child: Align(
                  alignment: AlignmentDirectional(0.0, -1.0),
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Align(
                          alignment: AlignmentDirectional(0.0, -1.0),
                          child: Container(
                            width: double.infinity,
                            height: 60.0,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.only(
                                bottomLeft: Radius.circular(0.0),
                                bottomRight: Radius.circular(0.0),
                                topLeft: Radius.circular(0.0),
                                topRight: Radius.circular(0.0),
                              ),
                              border: Border.all(
                                color: Color(0xFFD5D3E3),
                                width: 2.0,
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  width: 130.0,
                                  height: 100.0,
                                  decoration: BoxDecoration(),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(
                                            8.0),
                                        child: Image.asset(
                                          'assets/images/logot.png',
                                          width: 40.0,
                                          height: 35.0,
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      Align(
                                        alignment: AlignmentDirectional(
                                            -1.0, 0.0),
                                        child: Text(
                                          FFLocalizations.of(context).getText(
                                            'nuveu9sq' /* BDR_01 */,
                                          ),
                                          style: FlutterFlowTheme
                                              .of(context)
                                              .titleLarge
                                              .override(
                                            fontFamily: 'Montserrat',
                                            color: Color(0xFF14181B),
                                            letterSpacing: 0.0,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Align(
                                  alignment: AlignmentDirectional(1.0, 0.0),
                                  child: FFButtonWidget(
                                    onPressed: () async {
                                      await showModalBottomSheet(
                                        isScrollControlled: true,
                                        backgroundColor: Colors.transparent,
                                        enableDrag: false,
                                        context: context,
                                        builder: (context) {
                                          return GestureDetector(
                                            onTap: () =>
                                                FocusScope.of(context)
                                                    .unfocus(),
                                            child: Padding(
                                              padding:
                                              MediaQuery.viewInsetsOf(context),
                                              child: OptionsWidget(),
                                            ),
                                          );
                                        },
                                      ).then((value) => safeSetState(() {}));
                                    },
                                    text: '',
                                    icon: Icon(
                                      Icons.menu_sharp,
                                      color: Colors.black,
                                      size: 23.0,
                                    ),
                                    options: FFButtonOptions(
                                      width: 32.0,
                                      height: 30.0,
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0.0, 0.0, 0.0, 0.0),
                                      iconPadding: EdgeInsets.all(0.0),
                                      color: Colors.white,
                                      textStyle: FlutterFlowTheme
                                          .of(context)
                                          .titleSmall
                                          .override(
                                        fontFamily: 'Inter Tight',
                                        color: Colors.white,
                                        letterSpacing: 0.0,
                                      ),
                                      elevation: 0.0,
                                      borderRadius: BorderRadius.circular(8.0),
                                    ),
                                  ),
                                ),
                              ].divide(SizedBox(width: 220.0)),
                            ),
                          ),
                        ),
                        Container(
                          width: double.infinity,
                          height: 40.0,
                          decoration: BoxDecoration(),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              FFButtonWidget(
                                onPressed: () async {
                                  await actions.settingsWiFi();
                                },
                                text: FFLocalizations.of(context).getText(
                                  'm0bhwnfw' /* Find  a WiFi */,
                                ),
                                options: FFButtonOptions(
                                  width: MediaQuery
                                      .sizeOf(context)
                                      .width * 0.5,
                                  height: 40.0,
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      16.0, 0.0, 16.0, 0.0),
                                  iconPadding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 0.0, 0.0, 0.0),
                                  color: Color(0xFFE0E3E7),
                                  textStyle: FlutterFlowTheme
                                      .of(context)
                                      .titleSmall
                                      .override(
                                    fontFamily: 'Montserrat',
                                    color: Color(0xFF14181B),
                                    letterSpacing: 0.0,
                                  ),
                                  elevation: 0.0,
                                  borderSide: BorderSide(
                                    color: Color(0xFFD5D3E3),
                                    width: 2.0,
                                  ),
                                  borderRadius: BorderRadius.only(
                                    bottomLeft: Radius.circular(10.0),
                                    bottomRight: Radius.circular(0.0),
                                    topLeft: Radius.circular(0.0),
                                    topRight: Radius.circular(0.0),
                                  ),
                                ),
                              ),
                              FFButtonWidget(
                                onPressed: () async {
                                  await actions.settingsRoaming();
                                },
                                text: FFLocalizations.of(context).getText(
                                  'jypoxzqk' /* Disable Roaming */,
                                ),
                                options: FFButtonOptions(
                                  width: MediaQuery
                                      .sizeOf(context)
                                      .width * 0.5,
                                  height: 40.0,
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      16.0, 0.0, 16.0, 0.0),
                                  iconPadding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 0.0, 0.0, 0.0),
                                  color: Color(0xFFE0E3E7),
                                  textStyle: FlutterFlowTheme
                                      .of(context)
                                      .titleSmall
                                      .override(
                                    fontFamily: 'Montserrat',
                                    color: Color(0xFF14181B),
                                    letterSpacing: 0.0,
                                  ),
                                  elevation: 0.0,
                                  borderSide: BorderSide(
                                    color: Color(0xFFD5D3E3),
                                    width: 2.0,
                                  ),
                                  borderRadius: BorderRadius.only(
                                    bottomLeft: Radius.circular(0.0),
                                    bottomRight: Radius.circular(10.0),
                                    topLeft: Radius.circular(0.0),
                                    topRight: Radius.circular(0.0),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 0.0),
                          child: Container(
                            width: 250.0,
                            height: 40.0,
                            decoration: BoxDecoration(
                              color: Color(0xFF14181B),
                              borderRadius: BorderRadius.circular(20.0),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                FFButtonWidget(
                                  onPressed: () {
                                    print('Button pressed ...');
                                  },
                                  text: FFLocalizations.of(context).getText(
                                    'k4m23tax' /*
 */
                                    ,
                                  ),
                                  icon: Icon(
                                    Icons.language_rounded,
                                    size: 30.0,
                                  ),
                                  options: FFButtonOptions(
                                    width: 50.0,
                                    height: 40.0,
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        16.0, 0.0, 16.0, 0.0),
                                    iconPadding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 0.0, 0.0, 0.0),
                                    color: Color(0xFF14181B),
                                    textStyle: FlutterFlowTheme
                                        .of(context)
                                        .titleSmall
                                        .override(
                                      fontFamily: 'Inter Tight',
                                      color: Colors.white,
                                      letterSpacing: 0.0,
                                    ),
                                    elevation: 0.0,
                                    borderRadius: BorderRadius.circular(20.0),
                                  ),
                                ),
                                FlutterFlowLanguageSelector(
                                  width: 200.0,
                                  height: 40.0,
                                  backgroundColor: FlutterFlowTheme
                                      .of(context)
                                      .secondaryBackground,
                                  borderColor: Colors.transparent,
                                  dropdownIconColor:
                                  FlutterFlowTheme
                                      .of(context)
                                      .secondaryText,
                                  borderRadius: 20.0,
                                  textStyle: FlutterFlowTheme
                                      .of(context)
                                      .bodyMedium
                                      .override(
                                    fontFamily: 'Inter',
                                    letterSpacing: 0.0,
                                  ),
                                  hideFlags: true,
                                  flagSize: 24.0,
                                  flagTextGap: 8.0,
                                  currentLanguage:
                                  FFLocalizations
                                      .of(context)
                                      .languageCode,
                                  languages: FFLocalizations.languages(),
                                  onChanged: (lang) =>
                                      setAppLanguage(context, lang),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Padding(
                          padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 0.0),
                          child: Text(
                            FFLocalizations.of(context).getText(
                              'wg3gee0f' /* For correct operation
of the ... */
                              ,
                            ),
                            textAlign: TextAlign.center,
                            style: FlutterFlowTheme
                                .of(context)
                                .bodyMedium
                                .override(
                              fontFamily: 'Montserrat',
                              color: Color(0xFF14181B),
                              fontSize: 20.0,
                              letterSpacing: 0.0,
                            ),
                          ),
                        ),
                      ].addToEnd(SizedBox(height: 20.0)),
                    ),
                  ),
                ),
              ),
            ),
          );
  }
}
