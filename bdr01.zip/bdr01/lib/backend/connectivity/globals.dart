library my_prj.globals;

bool check_connectivity = false;
bool bdr_avail = false;
bool check_internet = false;
bool reloadMain = true;