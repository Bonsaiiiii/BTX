import 'package:flutter/foundation.dart' show immutable;
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import 'package:bdr01copy/backend/Profile/task.dart';

@immutable
class TasksDatabase {
  static const String _databaseName = 'tasks.db';
  static const int _databaseVersion = 1;

  // Create a singleton
  const TasksDatabase._privateConstructor();
  static const TasksDatabase instance = TasksDatabase._privateConstructor();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;

    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String dbPath = await getDatabasesPath();
    final String path = join(dbPath, _databaseName);
    return await openDatabase(
      path,
      version: _databaseVersion,
      onCreate: _createDB,
    );
  }

  //! Create Database method
  Future _createDB(
      Database db,
      int version,
      ) async {
    const idType = 'INTEGER PRIMARY KEY AUTOINCREMENT';
    const textType = 'TEXT NOT NULL';
    await db.execute('''
      CREATE TABLE IF NOT EXISTS $profileTable (
        ${TasksFields.id} $idType,
        ${TasksFields.title} $textType,
        ${TasksFields.mode} $textType,
        ${TasksFields.saidaTenL} $textType,
        ${TasksFields.baudrateL} $textType,
        ${TasksFields.paridadeL} $textType,
        ${TasksFields.bitsParaL} $textType,
        ${TasksFields.contrFluxL} $textType,
        ${TasksFields.datbitL} $textType,
        ${TasksFields.ssidL} $textType,
        ${TasksFields.senwiL} $textType,
        ${TasksFields.hostNtpL} $textType,
        ${TasksFields.portNtpL} $textType,
        ${TasksFields.mtpntL} $textType,
        ${TasksFields.userL} $textType,
        ${TasksFields.senL} $textType,
        ${TasksFields.saidaTenC} $textType,
        ${TasksFields.baudrateC} $textType,
        ${TasksFields.paridadeC} $textType,
        ${TasksFields.bitsParaC} $textType,
        ${TasksFields.contrFluxC} $textType,
        ${TasksFields.datbitC} $textType,
        ${TasksFields.ssidC} $textType,
        ${TasksFields.senwiC} $textType,
        ${TasksFields.hostNtpC} $textType,
        ${TasksFields.portNtpC} $textType,
        ${TasksFields.mtpntC} $textType,
        ${TasksFields.userC} $textType,
        ${TasksFields.senC} $textType,
        ${TasksFields.sendLatLong} $textType,
        ${TasksFields.lat} $textType,
        ${TasksFields.lon} $textType,
        ${TasksFields.alt} $textType,
        ${TasksFields.pre} $textType,
        ${TasksFields.utc} $textType,
        ${TasksFields.saidaTenS} $textType,
        ${TasksFields.baudrateS} $textType,
        ${TasksFields.paridadeS} $textType,
        ${TasksFields.bitsParaS} $textType,
        ${TasksFields.contrFluxS} $textType,
        ${TasksFields.datbitS} $textType,
        ${TasksFields.ssidS} $textType,
        ${TasksFields.senwiS} $textType,
        ${TasksFields.hostNtpS} $textType,
        ${TasksFields.portNtpS} $textType,
        ${TasksFields.mtpntS} $textType,
        ${TasksFields.sendRev2} $textType,
        ${TasksFields.userS} $textType,
        ${TasksFields.senS} $textType
      )
      ''');
  }

  //! C --> CRUD = Create
  Future<Profile> createTask(Profile profile) async {
    final db = await instance.database;
    final id = await db.insert(
      profileTable,
      profile.toMap(),
    );

    return profile.copy(id: id);
  }

  //! R -- CURD = Read
  Future<Profile> readTask(int id) async {
    final db = await instance.database;

    final taskData = await db.query(
      profileTable,
      columns: TasksFields.values,
      where: '${TasksFields.id} = ?',
      whereArgs: [id],
    );

    if (taskData.isNotEmpty) {
      return Profile.fromMap(taskData.first);
    } else {
      throw Exception('Could not find a task with the given ID');
    }
  }

  // Get All Tasks
  Future<List<Profile>> readAllTasks() async {
    final db = await instance.database;

    final result =
    await db.query(profileTable, orderBy: '${TasksFields.title} ASC');

    return result.map((taskData) => Profile.fromMap(taskData)).toList();
  }

  //! U --> CRUD = Update
  Future<int> updateTask(Profile profile) async {
    final db = await instance.database;

    return await db.update(
      profileTable,
      profile.toMap(),
      where: '${TasksFields.id} = ?',
      whereArgs: [profile.id],
    );
  }

  Future<int> markTaskAsCompleted({
    required int id,
    required bool isCompleted,
  }) async {
    final db = await instance.database;

    return await db.update(
      profileTable,
      {
      },
      where: '${TasksFields.id} = ?',
      whereArgs: [id],
    );
  }

  //! D --> CRUD = Delete
  Future<int> deleteTask(int id) async {
    final db = await instance.database;

    return await db.delete(
      profileTable,
      where: '${TasksFields.id} = ?',
      whereArgs: [id],
    );
  }

  Future close() async {
    final db = await instance.database;

    db.close();
  }
}
