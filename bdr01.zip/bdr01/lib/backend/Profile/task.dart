import 'package:flutter/foundation.dart' show immutable;

const String profileTable = 'profile';

class TasksFields {
  static final List<String> values = [
    id,
    title,
    mode,
    saidaTenL,
    baudrateL,
    paridadeL,
    bitsParaL,
    contrFluxL,
    datbitL,
    ssidL,
    senwiL,
    hostNtpL,
    portNtpL,
    mtpntL,
    userL,
    senL,
    saidaTenC,
    baudrateC,
    paridadeC,
    bitsParaC,
    contrFluxC,
    datbitC,
    ssidC,
    senwiC,
    hostNtpC,
    portNtpC,
    mtpntC,
    userC,
    senC,
    sendLatLong,
    lat,
    lon,
    alt,
    pre,
    utc,
    saidaTenS,
    baudrateS,
    paridadeS,
    bitsParaS,
    contrFluxS,
    datbitS,
    ssidS,
    senwiS,
    hostNtpS,
    portNtpS,
    mtpntS,
    sendRev2,
    userS,
    senS,
  ];

  // Column names for task tables
  static const id = 'id';
  static const title = 'title';
  static const mode = 'mode';
  static const saidaTenL = 'saidaTenL';
  static const baudrateL = 'baudrateL';
  static const paridadeL = 'paridadeL';
  static const bitsParaL = 'bitsParaL';
  static const contrFluxL = 'contrFluxL';
  static const datbitL = 'datbitL';
  static const ssidL = 'ssidL';
  static const senwiL = 'senwiL';
  static const hostNtpL = 'hostNtpL';
  static const portNtpL = 'portNtpL';
  static const mtpntL = 'mtpntL';
  static const userL = 'userL';
  static const senL = 'senL';
  static const saidaTenC = 'saidaTenC';
  static const baudrateC = 'baudrateC';
  static const paridadeC = 'paridadeC';
  static const bitsParaC = 'bitsParaC';
  static const contrFluxC = 'contrFluxC';
  static const datbitC = 'datbitC';
  static const ssidC = 'ssidC';
  static const senwiC = 'senwiC';
  static const hostNtpC = 'hostNtpC';
  static const portNtpC = 'portNtpC';
  static const mtpntC = 'mtpntC';
  static const userC = 'userC';
  static const senC = 'senC';
  static const sendLatLong = 'sendLatLong';
  static const lat = 'lat';
  static const lon = 'lon';
  static const alt = 'alt';
  static const pre = 'pre';
  static const utc = 'utc';
  static const saidaTenS = 'saidaTenS';
  static const baudrateS = 'baudrateS';
  static const paridadeS = 'paridadeS';
  static const bitsParaS = 'bitsParaS';
  static const contrFluxS = 'contrFluxS';
  static const datbitS = 'datbitS';
  static const ssidS = 'ssidS';
  static const senwiS = 'senwiS';
  static const hostNtpS = 'hostNtpS';
  static const portNtpS = 'portNtpS';
  static const mtpntS = 'mtpntS';
  static const sendRev2 = 'sendRev2';
  static const userS = 'userS';
  static const senS = 'senS';
}

@immutable
class Profile {
  final int? id;
  final String title;
  final String mode;
  final String saidaTenL;
  final String baudrateL;
  final String paridadeL;
  final String bitsParaL;
  final String contrFluxL;
  final String datbitL;
  final String ssidL;
  final String senwiL;
  final String hostNtpL;
  final String portNtpL;
  final String mtpntL;
  final String userL;
  final String senL;
  final String saidaTenC;
  final String baudrateC;
  final String paridadeC;
  final String bitsParaC;
  final String contrFluxC;
  final String datbitC;
  final String ssidC;
  final String senwiC;
  final String hostNtpC;
  final String portNtpC;
  final String mtpntC;
  final String userC;
  final String senC;
  final String sendLatLong;
  final String lat;
  final String lon;
  final String alt;
  final String pre;
  final String utc;
  final String saidaTenS;
  final String baudrateS;
  final String paridadeS;
  final String bitsParaS;
  final String contrFluxS;
  final String datbitS;
  final String ssidS;
  final String senwiS;
  final String hostNtpS;
  final String portNtpS;
  final String mtpntS;
  final String sendRev2;
  final String userS;
  final String senS;

  const Profile({
    this.id,
    required this.title,
    required this.saidaTenL,
    required this.mode,
    required this.baudrateL,
    required this.paridadeL,
    required this.bitsParaL,
    required this.contrFluxL,
    required this.datbitL,
    required this.ssidL,
    required this.senwiL,
    required this.hostNtpL,
    required this.portNtpL,
    required this.mtpntL,
    required this.userL,
    required this.senL,
    required this.saidaTenC,
    required this.baudrateC,
    required this.paridadeC,
    required this.bitsParaC,
    required this.contrFluxC,
    required this.datbitC,
    required this.ssidC,
    required this.senwiC,
    required this.hostNtpC,
    required this.portNtpC,
    required this.mtpntC,
    required this.userC,
    required this.senC,
    required this.sendLatLong,
    required this.lat,
    required this.lon,
    required this.alt,
    required this.pre,
    required this.utc,
    required this.saidaTenS,
    required this.baudrateS,
    required this.paridadeS,
    required this.bitsParaS,
    required this.contrFluxS,
    required this.datbitS,
    required this.ssidS,
    required this.senwiS,
    required this.hostNtpS,
    required this.portNtpS,
    required this.mtpntS,
    required this.sendRev2,
    required this.userS,
    required this.senS,
  });

  Profile copy({
    int? id,
    String? title,
    String? mode,
    String? saidaTenL,
    String? baudrateL,
    String? paridadeL,
    String? bitsParaL,
    String? contrFluxL,
    String? datbitL,
    String? ssidL,
    String? senwiL,
    String? hostNtpL,
    String? portNtpL,
    String? mtpntL,
    String? userL,
    String? senL,
    String? saidaTenC,
    String? baudrateC,
    String? paridadeC,
    String? bitsParaC,
    String? contrFluxC,
    String? datbitC,
    String? ssidC,
    String? senwiC,
    String? hostNtpC,
    String? portNtpC,
    String? mtpntC,
    String? userC,
    String? senC,
    String? sendLatLong,
    String? lat,
    String? lon,
    String? pre,
    String? alt,
    String? utc,
    String? saidaTenS,
    String? baudrateS,
    String? paridadeS,
    String? bitsParaS,
    String? contrFluxS,
    String? datbitS,
    String? ssidS,
    String? senwiS,
    String? hostNtpS,
    String? portNtpS,
    String? mtpntS,
    String? sendRev2,
    String? userS,
    String? senS,
  }) =>
      Profile(
        id: id ?? this.id,
        title: title ?? this.title,
        mode: mode ?? this.mode,
        saidaTenL: saidaTenL ?? this.saidaTenL,
        baudrateL: baudrateL ?? this.baudrateL,
        paridadeL: paridadeL ?? this.paridadeL,
        bitsParaL: bitsParaL ?? this.bitsParaL,
        contrFluxL: contrFluxL ?? this.contrFluxL,
        datbitL: datbitL ?? this.datbitL,
        ssidL: ssidL ?? this.ssidL,
        senwiL: senwiL ?? this.senwiL,
        hostNtpL: hostNtpL ?? this.hostNtpL,
        portNtpL: portNtpL ?? this.portNtpL,
        mtpntL: mtpntL ?? this.mtpntL,
        userL: userL ?? this.userL,
        senL: senL ?? this.senL,
        saidaTenC: saidaTenC ?? this.saidaTenC,
        baudrateC: baudrateC ?? this.baudrateC,
        paridadeC: paridadeC ?? this.paridadeC,
        bitsParaC: bitsParaC ?? this.bitsParaC,
        contrFluxC: contrFluxC ?? this.contrFluxC,
        datbitC: datbitC ?? this.datbitC,
        ssidC: ssidC ?? this.ssidC,
        senwiC: senwiC ?? this.senwiC,
        hostNtpC: hostNtpC ?? this.hostNtpC,
        portNtpC: portNtpC ?? this.portNtpC,
        mtpntC: mtpntC ?? this.mtpntC,
        userC: userC ?? this.userC,
        senC: senC ?? this.senC,
        sendLatLong: sendLatLong ?? this.sendLatLong,
        lat: lat ?? this.lat,
        lon: lon ?? this.lon,
        alt: alt ?? this.alt,
        pre: pre ?? this.pre,
        utc: utc ?? this.utc,
        saidaTenS: saidaTenS ?? this.saidaTenS,
        baudrateS: baudrateS ?? this.baudrateS,
        paridadeS: paridadeS ?? this.paridadeS,
        bitsParaS: bitsParaS ?? this.bitsParaS,
        contrFluxS: contrFluxS ?? this.contrFluxS,
        datbitS: datbitS ?? this.datbitS,
        ssidS: ssidS ?? this.ssidS,
        senwiS: senwiS ?? this.senwiS,
        hostNtpS: hostNtpS ?? this.hostNtpS,
        portNtpS: portNtpS ?? this.portNtpS,
        mtpntS: mtpntS ?? this.mtpntS,
        sendRev2: sendRev2 ?? this.sendRev2,
        userS: userS ?? this.userS,
        senS: senS ?? this.senS,
      );

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      TasksFields.id: id,
      TasksFields.title: title,
      TasksFields.mode: mode,
      TasksFields.saidaTenL: saidaTenL,
      TasksFields.baudrateL: baudrateL,
      TasksFields.paridadeL: paridadeL,
      TasksFields.bitsParaL: bitsParaL,
      TasksFields.contrFluxL: contrFluxL,
      TasksFields.datbitL: datbitL,
      TasksFields.ssidL: ssidL,
      TasksFields.senwiL: senwiL,
      TasksFields.hostNtpL: hostNtpL,
      TasksFields.portNtpL: portNtpL,
      TasksFields.mtpntL: mtpntL,
      TasksFields.userL: userL,
      TasksFields.senL: senL,
      TasksFields.saidaTenC: saidaTenC,
      TasksFields.baudrateC: baudrateC,
      TasksFields.paridadeC: paridadeC,
      TasksFields.bitsParaC: bitsParaC,
      TasksFields.contrFluxC: contrFluxC,
      TasksFields.datbitC: datbitC,
      TasksFields.ssidC: ssidC,
      TasksFields.senwiC: senwiC,
      TasksFields.hostNtpC: hostNtpC,
      TasksFields.portNtpC: portNtpC,
      TasksFields.mtpntC: mtpntC,
      TasksFields.userC: userC,
      TasksFields.senC: senC,
      TasksFields.sendLatLong: sendLatLong,
      TasksFields.lat: lat,
      TasksFields.lon: lon,
      TasksFields.alt: alt,
      TasksFields.pre: pre,
      TasksFields.utc: utc,
      TasksFields.saidaTenS: saidaTenS,
      TasksFields.baudrateS: baudrateS,
      TasksFields.paridadeS: paridadeS,
      TasksFields.bitsParaS: bitsParaS,
      TasksFields.contrFluxS: contrFluxS,
      TasksFields.datbitS: datbitS,
      TasksFields.ssidS: ssidS,
      TasksFields.senwiS: senwiS,
      TasksFields.hostNtpS: hostNtpS,
      TasksFields.portNtpS: portNtpS,
      TasksFields.mtpntS: mtpntS,
      TasksFields.sendRev2: sendRev2,
      TasksFields.userS: userS,
      TasksFields.senS: senS,
    };
  }

  factory Profile.fromMap(Map<String, dynamic> map) {
    return Profile(
      id: map[TasksFields.id] != null ? map[TasksFields.id] as int : null,
      title: map[TasksFields.title] as String,
      mode: map[TasksFields.mode] as String,
      saidaTenL: map[TasksFields.saidaTenL] as String,
      baudrateL: map[TasksFields.baudrateL] as String,
      paridadeL: map[TasksFields.paridadeL] as String,
      bitsParaL: map[TasksFields.bitsParaL] as String,
      contrFluxL: map[TasksFields.contrFluxL] as String,
      datbitL: map[TasksFields.datbitL] as String,
      ssidL: map[TasksFields.ssidL] as String,
      senwiL: map[TasksFields.senwiL] as String,
      hostNtpL: map[TasksFields.hostNtpL] as String,
      portNtpL: map[TasksFields.portNtpL] as String,
      mtpntL: map[TasksFields.mtpntL] as String,
      userL: map[TasksFields.userL] as String,
      senL: map[TasksFields.senL] as String,
      saidaTenC: map[TasksFields.saidaTenC] as String,
      baudrateC: map[TasksFields.baudrateC] as String,
      paridadeC: map[TasksFields.paridadeC] as String,
      bitsParaC: map[TasksFields.bitsParaC] as String,
      contrFluxC: map[TasksFields.contrFluxC] as String,
      datbitC: map[TasksFields.datbitC] as String,
      ssidC: map[TasksFields.ssidC] as String,
      senwiC: map[TasksFields.senwiC] as String,
      hostNtpC: map[TasksFields.hostNtpC] as String,
      portNtpC: map[TasksFields.portNtpC] as String,
      mtpntC: map[TasksFields.mtpntC] as String,
      userC: map[TasksFields.userC] as String,
      senC: map[TasksFields.senC] as String,
      sendLatLong: map[TasksFields.sendLatLong] as String,
      lat: map[TasksFields.lat] as String,
      lon: map[TasksFields.lon] as String,
      alt: map[TasksFields.alt] as String,
      pre: map[TasksFields.pre] as String,
      utc: map[TasksFields.utc] as String,
      saidaTenS: map[TasksFields.saidaTenS] as String,
      baudrateS: map[TasksFields.baudrateS] as String,
      paridadeS: map[TasksFields.paridadeS] as String,
      bitsParaS: map[TasksFields.bitsParaS] as String,
      contrFluxS: map[TasksFields.contrFluxS] as String,
      datbitS: map[TasksFields.datbitS] as String,
      ssidS: map[TasksFields.ssidS] as String,
      senwiS: map[TasksFields.senwiS] as String,
      hostNtpS: map[TasksFields.hostNtpS] as String,
      portNtpS: map[TasksFields.portNtpS] as String,
      mtpntS: map[TasksFields.mtpntS] as String,
      sendRev2: map[TasksFields.sendRev2] as String,
      userS: map[TasksFields.userS] as String,
      senS: map[TasksFields.senS] as String,
    );
  }
}
