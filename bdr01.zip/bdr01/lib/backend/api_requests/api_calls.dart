import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

class RequestCall {
  static Future<ApiCallResponse> call({
    String? saidaTenL = '\$.portaSupL[0].saidaTenL',
    String? baudrateL = '\$.portaSupL[0].baudrateL',
    String? paridadeL = '\$.portaSupL[0].paridadeL',
    String? bitsParaL = '\$.portaSupL[0].bitsParaL',
    String? contrFluxL = '\$.portaSupL[0].contrFluxL',
    String? datbitL = '\$.portaSupL[0].datbitL',
    String? ssidL = '\$.wifiL[0].ssidL',
    String? senwiL = '\$.wifiL[0].senwiL',
    String? hostNtpL = '\$.ntripConfL[0].hostNtpL',
    String? portNtpL = '\$.ntripConfL[0].portNtpL',
    String? mtpntL = '\$.ntripConfL[0].mtpntL',
    String? userL = '\$.ntripConfL[0].userL',
    String? senL = '\$.ntripConfL[0].senL',
    String? saidaTenC = '\$.portaSupC[0].saidaTenC',
    String? baudrateC = '\$.portaSupC[0].baudrateC',
    String? paridadeC = '\$.portaSupC[0].paridadeC',
    String? bitsParaC = '\$.portaSupC[0].bitsParaC',
    String? contrFluxC = '\$.portaSupC[0].contrFluxC',
    String? datbitC = '\$.portaSupC[0].datbitC',
    String? ssidC = '\$.wifiC[0].ssidC',
    String? senwiC = '\$.wifiC[0].senwiC',
    String? hostNtpC = '\$.ntripConfC[0].hostNtpC',
    String? portNtpC = '\$.ntripConfC[0].portNtpC',
    String? mtpntC = '\$.ntripConfC[0].mtpntC',
    String? userC = '\$.ntripConfC[0].userC',
    String? senC = '\$.ntripConfC[0].senC',
    String? sendLatLong = 'latLong[0].sendLatLong',
    String? lat = 'latLong[0].lat',
    String? lon = 'latLong[0].lon',
    String? alt = 'latLong[0].alt',
    String? pre = 'latLong[0].pre',
    String? utc = 'latLong[0].utc',
    String? saidaTenS = '\$.portaSupS[0].saidaTenS',
    String? baudrateS = '\$.portaSupS[0].baudrateS',
    String? paridadeS = '\$.portaSupS[0].paridadeS',
    String? bitsParaS = '\$.portaSupS[0].bitsParaS',
    String? contrFluxS = '\$.portaSupS[0].contrFluxS',
    String? datbitS = '\$.portaSupS[0].datbitS',
    String? ssidS = '\$.wifiS[0].ssidS',
    String? senwiS = '\$.wifiS[0].senwiS',
    String? hostNtpS = '\$.ntripConfS[0].hostNtpS',
    String? portNtpS = '\$.ntripConfS[0].portNtpS',
    String? mtpntS = '\$.ntripConfS[0].mtpntS',
    String? sendRev2 = '\$.ntripConfS[0].sendRev2',
    String? userS = '\$.ntripConfS[0].userS',
    String? senS = '\$.ntripConfS[0].senS',
    String? modo = '\$.avancado[0].Modo',
    String? perfil = '\$.avancado[0].Perfil',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Request',
      apiUrl: 'http://192.168.0.1/bdrjson.json',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  static dynamic saidaTenL(dynamic response) => getJsonField(
        response,
        r'''$.portaSupL[0].saidaTenL''',
      );
  static dynamic baudrateL(dynamic response) => getJsonField(
        response,
        r'''$.portaSupL[0].baudrateL''',
      );
  static dynamic paridadeL(dynamic response) => getJsonField(
        response,
        r'''$.portaSupL[0].paridadeL''',
      );
  static dynamic bitsParaL(dynamic response) => getJsonField(
        response,
        r'''$.portaSupL[0].bitsParaL''',
      );
  static dynamic contrFluxL(dynamic response) => getJsonField(
        response,
        r'''$.portaSupL[0].contrFluxL''',
      );
  static dynamic datbitL(dynamic response) => getJsonField(
        response,
        r'''$.portaSupL[0].datbitL''',
      );
  static dynamic ssidL(dynamic response) => getJsonField(
        response,
        r'''$.wifiL[0].ssidL''',
      );
  static dynamic senwiL(dynamic response) => getJsonField(
        response,
        r'''$.wifiL[0].senwiL''',
      );
  static dynamic hostNtpL(dynamic response) => getJsonField(
        response,
        r'''$.ntripConfL[0].hostNtpL''',
      );
  static dynamic portNtpL(dynamic response) => getJsonField(
        response,
        r'''$.ntripConfL[0].portNtpL''',
      );
  static dynamic mtpntL(dynamic response) => getJsonField(
        response,
        r'''$.ntripConfL[0].mtpntL''',
      );
  static dynamic userL(dynamic response) => getJsonField(
        response,
        r'''$.ntripConfL[0].userL''',
      );
  static dynamic senL(dynamic response) => getJsonField(
        response,
        r'''$.ntripConfL[0].senL''',
      );
  static dynamic saidaTenC(dynamic response) => getJsonField(
        response,
        r'''$.portaSupC[0].saidaTenC''',
      );
  static dynamic baudrateC(dynamic response) => getJsonField(
        response,
        r'''$.portaSupC[0].baudrateC''',
      );
  static dynamic paridadeC(dynamic response) => getJsonField(
        response,
        r'''$.portaSupC[0].paridadeC''',
      );
  static dynamic bitsParaC(dynamic response) => getJsonField(
        response,
        r'''$.portaSupC[0].bitsParaC''',
      );
  static dynamic contrFluxC(dynamic response) => getJsonField(
        response,
        r'''$.portaSupC[0].contrFluxC''',
      );
  static dynamic ssidC(dynamic response) => getJsonField(
        response,
        r'''$.wifiC[0].ssidC''',
      );
  static dynamic senwiC(dynamic response) => getJsonField(
        response,
        r'''$.wifiC[0].senwiC''',
      );
  static dynamic hostNtpC(dynamic response) => getJsonField(
        response,
        r'''$.ntripConfC[0].hostNtpC''',
      );
  static dynamic portNtpC(dynamic response) => getJsonField(
        response,
        r'''$.ntripConfC[0].portNtpC''',
      );
  static dynamic mtpntC(dynamic response) => getJsonField(
        response,
        r'''$.ntripConfC[0].mtpntC''',
      );
  static dynamic userC(dynamic response) => getJsonField(
        response,
        r'''$.ntripConfC[0].userC''',
      );
  static dynamic senC(dynamic response) => getJsonField(
        response,
        r'''$.ntripConfC[0].senC''',
      );
  static dynamic sendLatLong(dynamic response) => getJsonField(
        response,
        r'''$.latLong[0].sendLatLong''',
      );
  static dynamic lat(dynamic response) => getJsonField(
        response,
        r'''$.latLong[0].lat''',
      );
  static dynamic lon(dynamic response) => getJsonField(
        response,
        r'''$.latLong[0].lon''',
      );
  static dynamic alt(dynamic response) => getJsonField(
        response,
        r'''$.latLong[0].alt''',
      );
  static dynamic pre(dynamic response) => getJsonField(
        response,
        r'''$.latLong[0].pre''',
      );
  static dynamic utc(dynamic response) => getJsonField(
        response,
        r'''$.latLong[0].utc''',
      );
  static dynamic datbitC(dynamic response) => getJsonField(
        response,
        r'''$.portaSupC[0].datbitC''',
      );
  static dynamic saidaTenS(dynamic response) => getJsonField(
        response,
        r'''$.portaSupS[0].saidaTenS''',
      );
  static dynamic baudrateS(dynamic response) => getJsonField(
        response,
        r'''$.portaSupS[0].baudrateS''',
      );
  static dynamic paridadeS(dynamic response) => getJsonField(
        response,
        r'''$.portaSupS[0].paridadeS''',
      );
  static dynamic bitsParaS(dynamic response) => getJsonField(
        response,
        r'''$.portaSupS[0].bitsParaS''',
      );
  static dynamic contrFluxS(dynamic response) => getJsonField(
        response,
        r'''$.portaSupS[0].contrFluxS''',
      );
  static dynamic datbitS(dynamic response) => getJsonField(
        response,
        r'''$.portaSupS[0].datbitS''',
      );
  static dynamic ssidS(dynamic response) => getJsonField(
        response,
        r'''$.wifiS[0].ssidS''',
      );
  static dynamic senwiS(dynamic response) => getJsonField(
        response,
        r'''$.wifiS[0].senwiS''',
      );
  static dynamic hostNtpS(dynamic response) => getJsonField(
        response,
        r'''$.ntripConfS[0].hostNtpS''',
      );
  static dynamic portNtpS(dynamic response) => getJsonField(
        response,
        r'''$.ntripConfS[0].portNtpS''',
      );
  static dynamic mtpntS(dynamic response) => getJsonField(
        response,
        r'''$.ntripConfS[0].mtpntS''',
      );
  static dynamic sendRev2(dynamic response) => getJsonField(
        response,
        r'''$.ntripConfS[0].sendRev2''',
      );
  static dynamic userS(dynamic response) => getJsonField(
        response,
        r'''$.ntripConfS[0].userS''',
      );
  static dynamic senS(dynamic response) => getJsonField(
        response,
        r'''$.ntripConfS[0].senS''',
      );
  static dynamic modo(dynamic response) => getJsonField(
        response,
        r'''$.avancado[0].Modo''',
      );
  static dynamic perfil(dynamic response) => getJsonField(
        response,
        r'''$.avancado[0].Perfil''',
      );
}

class SendLocalCall {
  static Future<ApiCallResponse> call({
    String? inputsaidaTenL = '',
    String? inputbaudrateL = '',
    String? inputparidadeL = '',
    String? inputbitsParaL = '',
    String? inputcontrFluxL = '',
    String? inputdatbitL = '',
    String? inputssidL = '',
    String? inputsenwiL = '',
    String? inputhostNtpL = '',
    String? inputportNtpL = '',
    String? inputmtpntL = '',
    String? inputuserL = '',
    String? inputsenL = '',
    String? modo = 'Local',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'SendLocal',
      apiUrl: 'http://192.168.0.1/localbdr',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      params: {
        'saidaTenL': inputsaidaTenL,
        'baudrateL': inputbaudrateL,
        'paridadeL': inputparidadeL,
        'bitsParaL': inputbitsParaL,
        'contrFluxL': inputcontrFluxL,
        'datbitL': inputdatbitL,
        'ssidL': inputssidL,
        'senwiL': inputsenwiL,
        'hostNtpL': inputhostNtpL,
        'portNtpL': inputportNtpL,
        'mtpntL': inputmtpntL,
        'userL': inputuserL,
        'senL': inputsenL,
        'Modo': modo,
      },
      bodyType: BodyType.X_WWW_FORM_URL_ENCODED,
      returnBody: true,
      encodeBodyUtf8: true,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  static dynamic? args(dynamic response) => getJsonField(
        response,
        r'''$.args''',
      );
  static String? data(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data''',
      ));
  static dynamic? files(dynamic response) => getJsonField(
        response,
        r'''$.files''',
      );
  static dynamic? form(dynamic response) => getJsonField(
        response,
        r'''$.form''',
      );
  static dynamic? headers(dynamic response) => getJsonField(
        response,
        r'''$.headers''',
      );
  static String? headersHost(dynamic response) =>
      castToType<String>(getJsonField(
        response,
        r'''$.headers.Host''',
      ));
  static dynamic? json(dynamic response) => getJsonField(
        response,
        r'''$.json''',
      );
  static String? origin(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.origin''',
      ));
}

class SendSourceCall {
  static Future<ApiCallResponse> call({
    String? inputsaidaTenS = '',
    String? inputbaudrateS = '',
    String? inputparidadeS = '',
    String? inputbitsParaS = '',
    String? inputcontrFluxS = '',
    String? inputdatbitS = '',
    String? inputssidS = '',
    String? inputsenwiS = '',
    String? inputhostNtpS = '',
    String? inputportNtpS = '',
    String? inputmtpntS = '',
    String? inputuserS = '',
    String? inputsenS = '',
    String? sendRev2 = '',
    String? modo = 'Source',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'SendSource',
      apiUrl: 'http://192.168.0.1/sourcebdr',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      params: {
        'saidaTenS': inputsaidaTenS,
        'baudrateS': inputbaudrateS,
        'paridadeS': inputparidadeS,
        'bitsParaS': inputbitsParaS,
        'contrFluxS': inputcontrFluxS,
        'datbitS': inputdatbitS,
        'ssidS': inputssidS,
        'senwiS': inputsenwiS,
        'hostNtpS': inputhostNtpS,
        'portNtpS': inputportNtpS,
        'mtpntS': inputmtpntS,
        'userS': inputuserS,
        'senS': inputsenS,
        'sendRev2': sendRev2,
        'Modo': modo,
      },
      bodyType: BodyType.X_WWW_FORM_URL_ENCODED,
      returnBody: true,
      encodeBodyUtf8: true,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  static dynamic? args(dynamic response) => getJsonField(
        response,
        r'''$.args''',
      );
  static String? data(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data''',
      ));
  static dynamic? files(dynamic response) => getJsonField(
        response,
        r'''$.files''',
      );
  static dynamic? form(dynamic response) => getJsonField(
        response,
        r'''$.form''',
      );
  static dynamic? headers(dynamic response) => getJsonField(
        response,
        r'''$.headers''',
      );
  static String? headersHost(dynamic response) =>
      castToType<String>(getJsonField(
        response,
        r'''$.headers.Host''',
      ));
  static dynamic? json(dynamic response) => getJsonField(
        response,
        r'''$.json''',
      );
  static String? origin(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.origin''',
      ));
}

class SendClienteCall {
  static Future<ApiCallResponse> call({
    String? inputsaidaTenC = '',
    String? inputbaudrateC = '',
    String? inputparidadeC = '',
    String? inputbitsParaC = '',
    String? inputcontrFluxC = '',
    String? inputdatbitC = '',
    String? inputssidC = '',
    String? inputsenwiC = '',
    String? inputhostNtpC = '',
    String? inputportNtpC = '',
    String? inputmtpntC = '',
    String? inputuserC = '',
    String? inputsenC = '',
    String? sendLatLong = '',
    String? lat = '',
    String? lon = '',
    String? alt = '',
    String? pre = '',
    String? utc = '',
    String? modo = 'Cliente',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'SendCliente',
      apiUrl: 'http://192.168.0.1/clientebdr',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      params: {
        'saidaTenC': inputsaidaTenC,
        'baudrateC': inputbaudrateC,
        'paridadeC': inputparidadeC,
        'bitsParaC': inputbitsParaC,
        'contrFluxC': inputcontrFluxC,
        'datbitC': inputdatbitC,
        'ssidC': inputssidC,
        'senwiC': inputsenwiC,
        'hostNtpC': inputhostNtpC,
        'portNtpC': inputportNtpC,
        'mtpntC': inputmtpntC,
        'userC': inputuserC,
        'senC': inputsenC,
        'sendLatLong': sendLatLong,
        'lat': lat,
        'lon': lon,
        'alt': alt,
        'pre': pre,
        'utc': utc,
        'Modo': modo,
      },
      bodyType: BodyType.X_WWW_FORM_URL_ENCODED,
      returnBody: true,
      encodeBodyUtf8: true,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  static dynamic? args(dynamic response) => getJsonField(
        response,
        r'''$.args''',
      );
  static String? data(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.data''',
      ));
  static dynamic? files(dynamic response) => getJsonField(
        response,
        r'''$.files''',
      );
  static dynamic? form(dynamic response) => getJsonField(
        response,
        r'''$.form''',
      );
  static dynamic? headers(dynamic response) => getJsonField(
        response,
        r'''$.headers''',
      );
  static String? headersHost(dynamic response) =>
      castToType<String>(getJsonField(
        response,
        r'''$.headers.Host''',
      ));
  static dynamic? json(dynamic response) => getJsonField(
        response,
        r'''$.json''',
      );
  static String? origin(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.origin''',
      ));
}

class ModoConfigCall {
  static Future<ApiCallResponse> call() async {
    return ApiManager.instance.makeApiCall(
      callName: 'ModoConfig',
      apiUrl: 'http://192.168.0.1/modoconfig',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class SendPerfilCall {
  static Future<ApiCallResponse> call({
    String? perfil = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'SendPerfil',
      apiUrl: 'http://192.168.0.1/perfil',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      params: {
        'perfil': perfil,
      },
      bodyType: BodyType.X_WWW_FORM_URL_ENCODED,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _toEncodable(dynamic item) {
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}
