// Automatic FlutterFlow imports
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'index.dart'; // Imports other custom actions

import 'package:app_settings/app_settings.dart';
import 'package:geolocator/geolocator.dart';

Future<void> getLocation(Function(String) updateLatitude, Function(String) updateLongitude, Function(String) updateAltitude, Function(String) updatePrecisao) async {
  try {
    Position position = await _determinePosition();
    print(
        'Latitude: ${position.latitude}, Longitude: ${position.longitude}, Altitude: ${position.altitude}, Precisão: ${position.accuracy}');
    updateLatitude(position.latitude.toString());
    updateLongitude(position.longitude.toString());
    updateAltitude(position.altitude.toString());
    updatePrecisao(position.accuracy.toString());
  } catch (e) {
    print('Error getting location: $e');
  }
}

Future<Position> _determinePosition() async {
  bool serviceEnabled;
  LocationPermission permission;

  serviceEnabled = await Geolocator.isLocationServiceEnabled();
  print('Location service enabled: $serviceEnabled');

  if (!serviceEnabled) {
    AppSettings.openAppSettings(type: AppSettingsType.location);
    return Future.error('Location services are disabled.');
  }

  permission = await Geolocator.checkPermission();
  print('Location permission status: $permission');

  if (permission == LocationPermission.denied) {
    permission = await Geolocator.requestPermission();
    print('Requesting permission: $permission');

    if (permission == LocationPermission.denied) {
      return Future.error('Location permissions are denied.');
    }
  }

  if (permission == LocationPermission.deniedForever) {
    return Future.error('Location permissions are permanently denied.');
  }

  return await Geolocator.getCurrentPosition();
}
