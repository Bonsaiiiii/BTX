package com.example.gps;


import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.Priority;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Objects;


public class MainActivity extends AppCompatActivity {


    private static final int REQUEST_LOCATION = 1;
    public FusedLocationProviderClient fusedLocationClient;
    LocationManager locationManager;
    //private TextView locationTextView;

    public String serializeLocation(double latitude, double longitude, double altitude, float precisao) {
        JSONObject loc = new JSONObject();
        try {
            loc.put("latitude", latitude);
            loc.put("longitude", longitude);
            loc.put("altitude", altitude);
            loc.put("precisao", precisao);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return loc.toString();
    }

    @SuppressLint({"MissingInflatedId", "SetTextI18n", "SetJavaScriptEnabled"})
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_main);

        WebView myWeb = findViewById(R.id.myWeb);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        myWeb.setWebViewClient(new WebViewClient() {
            @SuppressLint("MissingPermission")
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (Objects.requireNonNull(request.getUrl().getPath()).endsWith("/loc")) {
                    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        // Request fine location permission if not granted
                        if(checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED){
                            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
                            InputStream inputStream = new ByteArrayInputStream((GlobalVariables.locJson).getBytes());
                            return new WebResourceResponse("application/json", "UTF-8", inputStream);
                        }
                    }

                    fusedLocationClient.getLastLocation()
                            .addOnSuccessListener(MainActivity.this, location -> {


                                LocationCallback locationCallback = new LocationCallback() {
                                    @Override
                                    public void onLocationResult(@NonNull LocationResult locationResult) {
                                        super.onLocationResult(locationResult);
                                    }
                                };

                                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                                    return;
                                }
                                LocationRequest.Builder locationRequest = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000);
                                locationRequest.build();



                                fusedLocationClient.requestLocationUpdates(locationRequest.build(), locationCallback, Looper.getMainLooper());
                                locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                                // Got last known location. In some rare cases you might get null.
                                if (location != null) {
                                    double latitude = location.getLatitude();
                                    double longitude = location.getLongitude();
                                    double altitude = location.getAltitude();
                                    float precisao = location.getAccuracy();
                                    //locationTextView.setText("Latitude: " + latitude + ", Longitude: " + longitude + ", Precisão: " + precisao + ", Altitude:" + altitude);

                                    // Serialize location data
                                    GlobalVariables.locJson = serializeLocation(latitude, longitude, altitude, precisao);

                                    //locationTextView.setText(GlobalVariables.locJson);

                                } else {
                                    if(!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
                                        final AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                        builder.setMessage("Enable GPS").setCancelable(false).setPositiveButton("Yes", (dialog, which) -> startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))).setNegativeButton("No", (dialog, which) -> dialog.cancel());
                                        final AlertDialog alertDialog = builder.create();
                                        alertDialog.show();
                                    }
                                    else{
                                        if (ActivityCompat.checkSelfPermission(
                                                MainActivity.this,Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                                                MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                                            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
                                        } else {
                                            Toast.makeText(MainActivity.this, "Unable to find location.", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                }

                            });

                        InputStream inputStream = new ByteArrayInputStream((GlobalVariables.locJson).getBytes());
                        return new WebResourceResponse("application/json", "UTF-8", inputStream);

                }
                return super.shouldInterceptRequest(view, request);
            }


        });

        WebSettings webSettings = myWeb.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        myWeb.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);

        //myWeb.setWebViewClient(new WebViewClient());
        myWeb.loadUrl("http://172.217.28.1/");

        //String postData = "Hello from Android";
        Button showLocationButton = findViewById(R.id.showLocationButton);
        //locationTextView = findViewById(R.id.locationTextView); // Add a TextView to display location



        showLocationButton.setOnClickListener(v -> {
            LocationCallback locationCallback = new LocationCallback() {
                @Override
                public void onLocationResult(@NonNull LocationResult locationResult) {
                    super.onLocationResult(locationResult);
                }
            };
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            LocationRequest.Builder locationRequest = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000);
            locationRequest.build();

            fusedLocationClient.requestLocationUpdates(locationRequest.build(), locationCallback, Looper.getMainLooper());
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if(!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
                final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage("Enable GPS").setCancelable(false).setPositiveButton("Yes", (dialog, which) -> startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))).setNegativeButton("No", (dialog, which) -> dialog.cancel());
                final AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
            else{
                if (ActivityCompat.checkSelfPermission(
                        MainActivity.this,Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                        MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
                } else {

                    Location locationGPS = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                    if (locationGPS != null) {


                    } else {
                        Toast.makeText(this, "Unable to find location.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
           // myWeb.clearCache(true);
           // myWeb.reload();



        });
    }
}