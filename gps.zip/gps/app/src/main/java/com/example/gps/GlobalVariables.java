package com.example.gps;

public class GlobalVariables {
    public static String locJson = "";
}
